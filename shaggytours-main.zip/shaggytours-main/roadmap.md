# Catalog update
- [ ] Complete the Egypt-wide update: five region pages, services, eight-language copy, catalog schedules, policies/FAQ, and verification; do not publish.
- [ ] Prepare English-first language resources and shared numeric catalog.
- [ ] Sync 52 distinct tours and exact regional prices/days without duplicates.
- [ ] Connect region filters, tour pages, pricing table, policies and contact text.
- [ ] Verify catalog rules and public desktop/mobile flow; do not publish.

# Dedicated Hurghada page
- [ ] Add the shared Hurghada view, preserving regional catalog data and CMS visibility.
- [ ] Add complete Hurghada translations in eight locales and activate French.
- [ ] Add /hurghada, navbar/homepage links, localized SEO and language alternates.
- [ ] Verify prices, schedules, WhatsApp links and desktop/mobile Arabic layout; do not publish.