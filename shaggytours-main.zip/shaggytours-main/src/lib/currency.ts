export const CURRENCIES = [
  { code: "GBP", symbol: "£", label: "British Pound (£)" },
  { code: "EUR", symbol: "€", label: "Euro (€)" },
  { code: "USD", symbol: "$", label: "US Dollar ($)" },
  { code: "EGP", symbol: "EGP", label: "Egyptian Pound (EGP)" },
] as const;

export type CurrencyCode = (typeof CURRENCIES)[number]["code"];

export const currencySymbol = (code?: string | null): string =>
  CURRENCIES.find((c) => c.code === (code || "GBP"))?.symbol ?? code ?? "£";

export const formatPrice = (amount: number, code?: string | null): string => {
  const symbol = currencySymbol(code);
  const value = Number.isInteger(amount) ? amount : amount.toFixed(2);
  return symbol.length > 1 ? `${value} ${symbol}` : `${symbol}${value}`;
};
