/**
 * Optimizes Supabase storage image URLs by using the render/image transform endpoint.
 * Appends width/quality params to serve properly sized images.
 */
export function optimizeImageUrl(url: string, width: number, quality = 75): string {
  if (!url) return url;
  
  // Only transform Supabase storage URLs
  if (url.includes('supabase.co/storage/v1/object/public/')) {
    return url.replace(
      '/storage/v1/object/public/',
      '/storage/v1/render/image/public/'
    ) + `?width=${width}&quality=${quality}&resize=contain`;
  }
  
  return url;
}
