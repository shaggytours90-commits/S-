import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, textResult, errorResult } from "../supabase";

export default defineTool({
  name: "get_tour",
  title: "Get tour details",
  description:
    "Get the full details of one tour (description, highlights, itinerary, what's included / not included) by slug or id.",
  inputSchema: {
    slug_or_id: z.string().describe("The tour slug (preferred) or its uuid."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ slug_or_id }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    const supabase = supabaseForUser(ctx);
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(slug_or_id);
    const { data, error } = await supabase
      .from("tours")
      .select("*")
      .eq(isUuid ? "id" : "slug", slug_or_id)
      .maybeSingle();

    if (error) return errorResult(error.message);
    if (!data) return errorResult(`No tour found for "${slug_or_id}".`);
    return { ...textResult(data), structuredContent: { tour: data } };
  },
});
