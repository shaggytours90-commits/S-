import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, textResult, errorResult } from "../supabase";

export default defineTool({
  name: "list_contact_messages",
  title: "List contact messages",
  description: "List messages submitted through the website contact form (admin access required).",
  inputSchema: {
    unread_only: z.boolean().optional().describe("Only return messages that have not been marked as read."),
    limit: z.number().optional().describe("Max rows to return (default 50)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ unread_only, limit }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    let query = supabaseForUser(ctx)
      .from("contact_messages")
      .select("id, name, email, phone, message, read, created_at")
      .order("created_at", { ascending: false })
      .limit(Math.min(limit ?? 50, 200));

    if (unread_only) query = query.eq("read", false);

    const { data, error } = await query;
    if (error) return errorResult(error.message);
    if (!data?.length) {
      return textResult({ messages: [], note: "No messages returned. Contact messages are visible to admins only." });
    }
    return { ...textResult(data), structuredContent: { messages: data } };
  },
});
