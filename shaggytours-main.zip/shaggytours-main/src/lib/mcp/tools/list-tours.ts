import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, textResult, errorResult } from "../supabase";

export default defineTool({
  name: "list_tours",
  title: "List tours",
  description:
    "List Shaggy Tours excursions with prices (GBP), destination, duration and category. Optionally filter by destination, category or search text.",
  inputSchema: {
    search: z.string().optional().describe("Free text matched against the tour title."),
    destination: z.string().optional().describe("Filter by destination, e.g. Marsa Alam."),
    category: z.string().optional().describe("Filter by category, e.g. adventure."),
    include_hidden: z.boolean().optional().describe("Admins only: include inactive tours."),
    limit: z.number().optional().describe("Max rows to return (default 50)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ search, destination, category, include_hidden, limit }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    let query = supabaseForUser(ctx)
      .from("tours")
      .select(
        "id, slug, title, destination, region, price, original_price, duration, category, rating, reviews, featured, active, image_url",
      )
      .order("sort_order", { ascending: true })
      .limit(Math.min(limit ?? 50, 200));

    if (!include_hidden) query = query.eq("active", true);
    if (destination) query = query.ilike("destination", `%${destination}%`);
    if (category) query = query.ilike("category", `%${category}%`);
    if (search) query = query.ilike("title", `%${search}%`);

    const { data, error } = await query;
    if (error) return errorResult(error.message);
    return { ...textResult(data ?? []), structuredContent: { tours: data ?? [] } };
  },
});
