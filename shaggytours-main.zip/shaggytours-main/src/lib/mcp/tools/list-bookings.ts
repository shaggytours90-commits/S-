import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, textResult, errorResult } from "../supabase";

export default defineTool({
  name: "list_bookings",
  title: "List bookings",
  description:
    "List tour booking requests (admin access required). Optionally filter by status or upcoming tour date.",
  inputSchema: {
    status: z
      .enum(["pending", "confirmed", "cancelled", "completed"])
      .optional()
      .describe("Filter by booking status."),
    from_date: z.string().optional().describe("Only bookings with a tour date on or after this ISO date."),
    limit: z.number().optional().describe("Max rows to return (default 50)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ status, from_date, limit }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    let query = supabaseForUser(ctx)
      .from("bookings")
      .select("id, tour_title, name, email, whatsapp, hotel, room, date, people, message, status, created_at")
      .order("date", { ascending: true })
      .limit(Math.min(limit ?? 50, 200));

    if (status) query = query.eq("status", status);
    if (from_date) query = query.gte("date", from_date);

    const { data, error } = await query;
    if (error) return errorResult(error.message);
    if (!data?.length) {
      return textResult({ bookings: [], note: "No bookings returned. Bookings are visible to admins only." });
    }
    return { ...textResult(data), structuredContent: { bookings: data } };
  },
});
