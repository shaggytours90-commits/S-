import { defineTool } from "@lovable.dev/mcp-js";
import { supabaseForUser, textResult, errorResult } from "../supabase";

export default defineTool({
  name: "get_site_info",
  title: "Get site info",
  description:
    "Get Shaggy Tours public site information: contact details, WhatsApp number, social links and published FAQs.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async (_input, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    const supabase = supabaseForUser(ctx);

    const [settingsRes, faqsRes] = await Promise.all([
      supabase.from("site_settings").select("key, value"),
      supabase.from("faqs").select("question, answer").order("sort_order", { ascending: true }),
    ]);

    if (settingsRes.error) return errorResult(settingsRes.error.message);

    const settings: Record<string, string> = {};
    settingsRes.data?.forEach((row: { key: string; value: string }) => {
      settings[row.key] = row.value;
    });

    const payload = { settings, faqs: faqsRes.data ?? [] };
    return { ...textResult(payload), structuredContent: payload };
  },
});
