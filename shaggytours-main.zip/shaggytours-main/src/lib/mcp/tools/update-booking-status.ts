import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser, textResult, errorResult } from "../supabase";

export default defineTool({
  name: "update_booking_status",
  title: "Update booking status",
  description: "Change the status of a booking request (admin access required).",
  inputSchema: {
    booking_id: z.string().describe("The uuid of the booking."),
    status: z
      .enum(["pending", "confirmed", "cancelled", "completed"])
      .describe("The new booking status."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
  handler: async ({ booking_id, status }, ctx) => {
    if (!ctx.isAuthenticated()) return errorResult("Not authenticated");
    const { data, error } = await supabaseForUser(ctx)
      .from("bookings")
      .update({ status })
      .eq("id", booking_id)
      .select("id, tour_title, name, date, status");

    if (error) return errorResult(error.message);
    if (!data?.length) return errorResult("Booking not updated — not found or admin access required.");
    return { ...textResult(data[0]), structuredContent: { booking: data[0] } };
  },
});
