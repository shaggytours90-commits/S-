import { auth, defineMcp } from "@lovable.dev/mcp-js";
import listToursTool from "./tools/list-tours";
import getTourTool from "./tools/get-tour";
import listBookingsTool from "./tools/list-bookings";
import updateBookingStatusTool from "./tools/update-booking-status";
import listContactMessagesTool from "./tools/list-contact-messages";
import getSiteInfoTool from "./tools/get-site-info";

const projectRef = import.meta.env.VITE_SUPABASE_PROJECT_ID ?? "project-ref-unset";

export default defineMcp({
  name: "shaggy-tours-mcp",
  title: "Shaggy Tours",
  version: "0.1.0",
  instructions:
    "Tools for SHAGGY TOURS (Marsa Alam, Egypt). Use `list_tours` and `get_tour` to browse excursions and GBP prices, `get_site_info` for contact details and FAQs, and `list_bookings`, `update_booking_status` and `list_contact_messages` for admin operations (these require an admin account).",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [
    listToursTool,
    getTourTool,
    getSiteInfoTool,
    listBookingsTool,
    updateBookingStatusTool,
    listContactMessagesTool,
  ],
});
