import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";

import en from "./locales/en.json";
import ar from "./locales/ar.json";
import it from "./locales/it.json";
import pl from "./locales/pl.json";
import de from "./locales/de.json";
import fr from "./locales/fr.json";
import cs from "./locales/cs.json";
import ru from "./locales/ru.json";

export const SUPPORTED_LANGUAGES = [
  { code: "en", short: "EN", label: "English", flag: "🇬🇧", dir: "ltr" as const },
  { code: "it", short: "IT", label: "Italiano", flag: "🇮🇹", dir: "ltr" as const },
  { code: "pl", short: "PL", label: "Polski", flag: "🇵🇱", dir: "ltr" as const },
  { code: "ru", short: "RU", label: "Русский", flag: "🇷🇺", dir: "ltr" as const },
  { code: "cs", short: "CZ", label: "Čeština", flag: "🇨🇿", dir: "ltr" as const },
  { code: "de", short: "DE", label: "Deutsch", flag: "🇩🇪", dir: "ltr" as const },
  { code: "ar", short: "AR", label: "العربية", flag: "🇸🇦", dir: "rtl" as const },
];


i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: en },
      ar: { translation: ar },
      it: { translation: it },
      pl: { translation: pl },
      de: { translation: de },
      fr: { translation: fr },
      cs: { translation: cs },
      ru: { translation: ru },
    },
    fallbackLng: "en",
    supportedLngs: SUPPORTED_LANGUAGES.map((l) => l.code),
    interpolation: { escapeValue: false },
    detection: {
      order: ["localStorage"],
      caches: ["localStorage"],
      lookupLocalStorage: "i18nextLng",
    },
  });

const applyDir = (lng: string) => {
  const entry = SUPPORTED_LANGUAGES.find((l) => l.code === lng);
  const dir = entry?.dir ?? "ltr";
  document.documentElement.lang = lng;
  document.documentElement.dir = dir;
};

applyDir(i18n.language || "en");
i18n.on("languageChanged", applyDir);

export default i18n;
