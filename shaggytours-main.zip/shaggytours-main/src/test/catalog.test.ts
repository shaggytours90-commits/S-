import { describe, expect, it } from "vitest";
import { catalog, childPriceForAge, isRequestPrice, regionMatches } from "@/data/catalog";

describe("official regional catalog", () => {
  it("keeps all 52 tours separate", () => {
    expect(catalog).toHaveLength(52);
    expect(new Set(catalog.map(t => t.slug)).size).toBe(52);
    expect(catalog.filter(t => t.region === "hurghada")).toHaveLength(33);
    expect(catalog.filter(t => t.region === "marsa-alam")).toHaveLength(19);
  });
  it("keeps Luxor prices separate by region", () => {
    expect(catalog.find(t => t.slug === "hurghada-luxor-bus")?.adult).toBe(50);
    expect(catalog.find(t => t.slug === "luxor-day-trip")?.adult).toBe(110);
  });
  it("preserves every supplied half price and N/A exception", () => {
    for (const tour of catalog) {
      expect(tour.child_0_5).toBe(0);
      if (tour.child_6_10 != null && tour.adult != null) expect(tour.child_6_10).toBe(tour.adult / 2);
    }
    expect(catalog.find(t => t.slug === "hurghada-deals")?.adult).toBe(650);
    expect(catalog.find(t => t.slug === "hurghada-deals")?.child_6_10).toBeNull();
  });
  it("respects age boundaries", () => {
    expect(childPriceForAge(5,110,55)).toBe(0);
    expect(childPriceForAge(6,110,55)).toBe(55);
    expect(childPriceForAge(10,110,55)).toBe(55);
    expect(childPriceForAge(11,110,55)).toBe(110);
  });
  it("uses requests for unspecified adult prices", () => {
    expect(isRequestPrice(null)).toBe(true);
    expect(isRequestPrice(18)).toBe(false);
  });
  it("keeps exact stated days", () => {
    expect(catalog.find(t => t.slug === "hurghada-luxor-dendera")?.days).toEqual(["Sunday"]);
    expect(catalog.find(t => t.slug === "hamata-islands")?.days).toEqual(["Sunday","Tuesday","Thursday"]);
    expect(catalog.find(t => t.slug === "luxor-day-trip")?.days).toEqual([]);
  });
  it("filters by region", () => {
    expect(regionMatches("hurghada", "marsa-alam")).toBe(false);
    expect(regionMatches("hurghada", "all")).toBe(true);
  });
});
