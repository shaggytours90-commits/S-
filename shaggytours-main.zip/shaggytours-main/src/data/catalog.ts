import entries from "./catalog.json";

export const catalog = entries;
export const catalogBySlug = new Map(catalog.map((tour) => [tour.slug, tour]));
export const isRequestPrice = (price: number | null | undefined) => price == null || price === 0;
export const childPriceForAge = (age: number, adult: number | null, child: number | null) =>
  age <= 5 ? 0 : age <= 10 ? child : adult;
export const regionMatches = (region: string, selected: string) => selected === "all" || region === selected;