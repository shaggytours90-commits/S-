import tourLuxor from "@/assets/tour-luxor.jpg";
import tourAswan from "@/assets/tour-aswan.jpg";
import tourDolphin from "@/assets/tour-dolphin.jpg";
import tourHamata from "@/assets/tour-hamata.jpg";
import tourMubarak from "@/assets/tour-mubarak.jpg";
import tourSharmLuli from "@/assets/tour-sharm-luli.jpg";
import tourAbuDabbab from "@/assets/tour-abu-dabbab.jpg";
import tourSuperSafari from "@/assets/tour-super-safari.jpg";
import tourQuad from "@/assets/tour-quad.jpg";
import tourCity from "@/assets/tour-city.jpg";

export interface Tour {
  id: string;
  title: string;
  destination: string;
  region: string;
  image: string;
  price: number;
  originalPrice?: number;
  duration: string;
  durationDays: number;
  rating: number;
  reviews: number;
  description: string;
  highlights: string[];
  itinerary: { day: number; title: string; description: string }[];
  included: string[];
  notIncluded: string[];
  featured?: boolean;
  category: "adventure" | "luxury" | "cultural" | "beach" | "nature" | "city";
  bestSeason: string;
}

export const destinations = [
  { name: "Luxor & Valley of Kings", image: tourLuxor, tours: 1, region: "Red Sea" },
  { name: "Abu Simbel & Aswan", image: tourAswan, tours: 1, region: "Red Sea" },
  { name: "Dolphin House Samadai", image: tourDolphin, tours: 1, region: "Red Sea" },
  { name: "Hamata Islands", image: tourHamata, tours: 1, region: "Red Sea" },
  { name: "Marsa Mubarak", image: tourMubarak, tours: 1, region: "Red Sea" },
  { name: "Sharm El Luli", image: tourSharmLuli, tours: 1, region: "Red Sea" },
  { name: "Abu Dabbab Beach", image: tourAbuDabbab, tours: 1, region: "Red Sea" },
  { name: "Desert Safari", image: tourSuperSafari, tours: 2, region: "Red Sea" },
];

export const tours: Tour[] = [
  {
    id: "luxor-day-trip",
    title: "Luxor Day Trip",
    destination: "Luxor, Egypt",
    region: "Red Sea",
    image: tourLuxor,
    price: 65,
    originalPrice: 85,
    duration: "1 Day",
    durationDays: 1,
    rating: 4.9,
    reviews: 312,
    category: "cultural",
    bestSeason: "October - April",
    description: "Explore the ancient wonders of Luxor in a full-day excursion from Marsa Alam. Visit the legendary Valley of the Kings, the stunning Temple of Hatshepsut, and the colossal Karnak Temple. Travel through Egypt's timeless history with an expert Egyptologist guide.",
    highlights: ["Valley of the Kings", "Karnak Temple", "Temple of Hatshepsut", "Colossi of Memnon"],
    itinerary: [
      { day: 1, title: "Full Day Luxor Excursion", description: "Early morning pickup from your hotel. Drive to Luxor (approx. 4 hours). Visit the Valley of the Kings to explore royal tombs. See the Temple of Hatshepsut and Colossi of Memnon. Lunch at a local restaurant. Afternoon visit to Karnak Temple. Return to Marsa Alam by evening." },
    ],
    included: ["Hotel pickup & drop-off", "Air-conditioned transport", "Egyptologist guide", "Entrance fees", "Lunch", "Bottled water"],
    notIncluded: ["Personal expenses", "Tips", "Photography inside tombs"],
    featured: true,
  },
  {
    id: "aswan-abu-simbel",
    title: "Aswan & Abu Simbel",
    destination: "Aswan, Egypt",
    region: "Red Sea",
    image: tourAswan,
    price: 95,
    originalPrice: 120,
    duration: "2 Days",
    durationDays: 2,
    rating: 4.9,
    reviews: 245,
    category: "cultural",
    bestSeason: "October - April",
    description: "A two-day journey to Aswan and the magnificent Abu Simbel temples. See the Philae Temple, the Aswan High Dam, sail on a traditional felucca on the Nile, and witness the awe-inspiring rock-cut temples of Ramses II at Abu Simbel.",
    highlights: ["Abu Simbel temples", "Philae Temple", "Aswan High Dam", "Nile felucca sail"],
    itinerary: [
      { day: 1, title: "Marsa Alam to Aswan", description: "Morning departure to Aswan. Visit the Aswan High Dam and Philae Temple. Enjoy a felucca sail on the Nile at sunset. Overnight in Aswan hotel." },
      { day: 2, title: "Abu Simbel & Return", description: "Early morning drive to Abu Simbel. Guided tour of the Great Temple of Ramses II and Temple of Nefertari. Return to Marsa Alam by evening." },
    ],
    included: ["Hotel pickup & drop-off", "1 night Aswan hotel", "All entrance fees", "English guide", "Meals (lunch + breakfast)", "Felucca sail"],
    notIncluded: ["Personal expenses", "Tips", "Drinks"],
    featured: true,
  },
  {
    id: "dolphin-house-samadai",
    title: "Dolphin House Samadai",
    destination: "Samadai Reef, Red Sea",
    region: "Red Sea",
    image: tourDolphin,
    price: 30,
    originalPrice: 40,
    duration: "Full Day",
    durationDays: 1,
    rating: 4.8,
    reviews: 428,
    category: "beach",
    bestSeason: "Year-round",
    description: "Swim with wild spinner dolphins at the famous Samadai Reef, also known as Dolphin House. This protected marine area is home to a resident pod of dolphins. Snorkel over vibrant coral reefs and enjoy a boat trip on the crystal-clear Red Sea.",
    highlights: ["Swim with dolphins", "Snorkeling coral reefs", "Boat trip", "Marine wildlife"],
    itinerary: [
      { day: 1, title: "Dolphin House Adventure", description: "Morning pickup and transfer to the marina. Boat ride to Samadai Reef (Dolphin House). Snorkel and swim with wild dolphins in their natural habitat. Enjoy lunch on the boat. Afternoon snorkeling at a nearby coral reef. Return to marina and transfer back to hotel." },
    ],
    included: ["Hotel pickup & drop-off", "Boat trip", "Snorkeling equipment", "Lunch & drinks", "Guide"],
    notIncluded: ["Underwater camera rental", "Tips", "Personal expenses"],
    featured: true,
  },
  {
    id: "hamata-islands",
    title: "Hamata Islands",
    destination: "Hamata, Red Sea",
    region: "Red Sea",
    image: tourHamata,
    price: 35,
    originalPrice: 45,
    duration: "Full Day",
    durationDays: 1,
    rating: 4.9,
    reviews: 356,
    category: "beach",
    bestSeason: "Year-round",
    description: "Discover the untouched paradise of Hamata Islands. These pristine white-sand islands offer some of the best snorkeling in Egypt with crystal-clear turquoise waters, colorful coral gardens, and abundant marine life. A true hidden gem of the Red Sea.",
    highlights: ["Virgin white-sand beaches", "Crystal clear water", "Snorkeling paradise", "Island exploration"],
    itinerary: [
      { day: 1, title: "Hamata Islands Excursion", description: "Early morning pickup. Drive to Hamata port (approx. 2 hours south). Speed boat to the islands. Free time to swim, snorkel, and relax on pristine beaches. Lunch served on the beach. Visit multiple islands throughout the day. Return to Marsa Alam by evening." },
    ],
    included: ["Hotel pickup & drop-off", "Boat transfer", "Snorkeling equipment", "Lunch & drinks", "Guide"],
    notIncluded: ["Tips", "Underwater camera", "Personal expenses"],
    featured: true,
  },
  {
    id: "marsa-mubarak",
    title: "Marsa Mubarak Snorkeling",
    destination: "Marsa Mubarak, Red Sea",
    region: "Red Sea",
    image: tourMubarak,
    price: 25,
    duration: "Full Day",
    durationDays: 1,
    rating: 4.8,
    reviews: 289,
    category: "beach",
    bestSeason: "Year-round",
    description: "Snorkel at Marsa Mubarak, one of the Red Sea's best spots for encountering sea turtles and dugongs. This sheltered bay features stunning coral reefs and is famous for its gentle green sea turtles that graze on sea grass in shallow waters.",
    highlights: ["Sea turtles", "Dugong sightings", "Coral reef snorkeling", "Calm bay swimming"],
    itinerary: [
      { day: 1, title: "Marsa Mubarak Day", description: "Morning pickup from hotel. Drive to Marsa Mubarak bay. Snorkeling session to spot sea turtles and dugongs. Beach relaxation time. Lunch at the beach. Afternoon snorkeling at the coral reef. Return to hotel." },
    ],
    included: ["Hotel pickup & drop-off", "Snorkeling equipment", "Lunch & drinks", "Guide"],
    notIncluded: ["Tips", "Underwater camera", "Personal expenses"],
  },
  {
    id: "sharm-el-luli",
    title: "Sharm El Luli Beach",
    destination: "Sharm El Luli, Red Sea",
    region: "Red Sea",
    image: tourSharmLuli,
    price: 20,
    duration: "Full Day",
    durationDays: 1,
    rating: 4.7,
    reviews: 198,
    category: "beach",
    bestSeason: "Year-round",
    description: "Visit the breathtaking Sharm El Luli beach, often described as the Maldives of Egypt. With its powdery white sand, crystal-clear turquoise lagoon, and stunning mountain backdrop, this is one of the most beautiful beaches in all of Egypt.",
    highlights: ["White sand beach", "Turquoise lagoon", "Mountain views", "Snorkeling"],
    itinerary: [
      { day: 1, title: "Beach Paradise Day", description: "Morning pickup from hotel. Drive to Sharm El Luli (approx. 1.5 hours south). Full day of swimming, snorkeling, and relaxation. Lunch and refreshments. Return to hotel in the afternoon." },
    ],
    included: ["Hotel pickup & drop-off", "Snorkeling equipment", "Lunch & drinks", "Beach umbrella"],
    notIncluded: ["Tips", "Personal expenses"],
  },
  {
    id: "abu-dabbab-beach",
    title: "Abu Dabbab Beach",
    destination: "Abu Dabbab, Red Sea",
    region: "Red Sea",
    image: tourAbuDabbab,
    price: 25,
    duration: "Full Day",
    durationDays: 1,
    rating: 4.8,
    reviews: 267,
    category: "nature",
    bestSeason: "Year-round",
    description: "Abu Dabbab Bay is one of the few places in the world where you can spot dugongs (sea cows) in their natural habitat. The calm, shallow bay is also home to green sea turtles, octopus, and beautiful coral formations.",
    highlights: ["Dugong watching", "Sea turtle encounters", "Calm bay snorkeling", "Marine biodiversity"],
    itinerary: [
      { day: 1, title: "Abu Dabbab Marine Day", description: "Morning pickup from hotel. Short drive to Abu Dabbab Bay. Snorkeling session to spot dugongs and sea turtles. Beach relaxation and swimming. Lunch at the beach restaurant. Afternoon free time. Return to hotel." },
    ],
    included: ["Hotel pickup & drop-off", "Snorkeling equipment", "Lunch", "Guide"],
    notIncluded: ["Tips", "Drinks", "Personal expenses"],
  },
  {
    id: "super-safari",
    title: "Super Safari Adventure",
    destination: "Eastern Desert, Egypt",
    region: "Red Sea",
    image: tourSuperSafari,
    price: 40,
    originalPrice: 55,
    duration: "Half Day",
    durationDays: 1,
    rating: 4.7,
    reviews: 385,
    category: "adventure",
    bestSeason: "October - May",
    description: "Experience the ultimate desert adventure! Ride quad bikes across golden sand dunes, enjoy a thrilling camel ride, visit a Bedouin village for traditional tea, and end the evening with a spectacular sunset BBQ dinner under the stars.",
    highlights: ["Quad biking", "Camel riding", "Bedouin village visit", "Sunset BBQ dinner"],
    itinerary: [
      { day: 1, title: "Desert Adventure", description: "Afternoon pickup from hotel. Drive to the desert base camp. Quad bike ride through the desert dunes. Camel riding experience. Visit a traditional Bedouin village and enjoy fresh tea. Watch the sunset over the desert. BBQ dinner under the stars. Return to hotel." },
    ],
    included: ["Hotel pickup & drop-off", "Quad bike ride", "Camel ride", "Bedouin tea", "BBQ dinner", "Soft drinks"],
    notIncluded: ["Tips", "Photos", "Personal expenses"],
    featured: true,
  },
  {
    id: "quad-safari",
    title: "Quad Bike Safari",
    destination: "Marsa Alam Desert",
    region: "Red Sea",
    image: tourQuad,
    price: 30,
    duration: "3 Hours",
    durationDays: 1,
    rating: 4.6,
    reviews: 234,
    category: "adventure",
    bestSeason: "October - May",
    description: "Get your adrenaline pumping with a thrilling quad bike safari through the Egyptian desert! Race across sand dunes, navigate rocky terrain, and experience the raw beauty of the Eastern Desert landscape near Marsa Alam.",
    highlights: ["Quad biking", "Desert landscape", "Adrenaline rush", "Photo opportunities"],
    itinerary: [
      { day: 1, title: "Quad Bike Experience", description: "Pickup from hotel. Transfer to the quad bike station. Safety briefing and instruction. 2-hour quad bike ride through the desert. Stop for photos and refreshments. Return to hotel." },
    ],
    included: ["Hotel pickup & drop-off", "Quad bike & helmet", "Safety instruction", "Soft drinks", "Guide"],
    notIncluded: ["Tips", "Photos", "Personal expenses"],
  },
  {
    id: "marsa-alam-city-tour",
    title: "Marsa Alam City Tour",
    destination: "Marsa Alam, Egypt",
    region: "Red Sea",
    image: tourCity,
    price: 20,
    duration: "Half Day",
    durationDays: 1,
    rating: 4.5,
    reviews: 156,
    category: "city",
    bestSeason: "Year-round",
    description: "Discover the authentic charm of Marsa Alam on this guided city tour. Explore the local markets, visit the marina, see the old town, and learn about the daily life and culture of this Red Sea coastal town from a knowledgeable local guide.",
    highlights: ["Local markets", "Marina visit", "Old town walk", "Cultural experience"],
    itinerary: [
      { day: 1, title: "City Exploration", description: "Morning pickup from hotel. Visit the Marsa Alam marina and waterfront. Explore the local souq (market) for spices and souvenirs. Walk through the old town. Stop for traditional Egyptian tea. Learn about local customs and traditions. Return to hotel." },
    ],
    included: ["Hotel pickup & drop-off", "English-speaking guide", "Traditional tea", "Market visit"],
    notIncluded: ["Tips", "Shopping", "Personal expenses"],
  },
];

export const testimonials = [
  {
    name: "Marco Rossi",
    location: "Milan, Italy",
    avatar: "MR",
    rating: 5,
    text: "The Dolphin House trip was incredible! Swimming with wild dolphins in crystal clear water was a dream come true. SHAGGY TOURS made it unforgettable.",
    tour: "Dolphin House Samadai",
  },
  {
    name: "Anna Müller",
    location: "Berlin, Germany",
    avatar: "AM",
    rating: 5,
    text: "Our Luxor day trip was perfectly organized. The guide was so knowledgeable about Egyptian history. Seeing the Valley of the Kings was breathtaking!",
    tour: "Luxor Day Trip",
  },
  {
    name: "Katarzyna Nowak",
    location: "Warsaw, Poland",
    avatar: "KN",
    rating: 5,
    text: "Hamata Islands are the most beautiful beaches I've ever seen! White sand, turquoise water — better than the Maldives. Highly recommend SHAGGY TOURS!",
    tour: "Hamata Islands",
  },
  {
    name: "James & Sarah Thompson",
    location: "London, UK",
    avatar: "JT",
    rating: 5,
    text: "The Super Safari was amazing! Quad biking at sunset, camel riding, and BBQ dinner under the stars. Our kids loved every moment. Best family adventure ever!",
    tour: "Super Safari Adventure",
  },
  {
    name: "Olga Petrova",
    location: "Moscow, Russia",
    avatar: "OP",
    rating: 5,
    text: "Abu Simbel took my breath away. The temples are absolutely magnificent. SHAGGY TOURS handled everything perfectly — hotel, meals, transport. Five stars!",
    tour: "Aswan & Abu Simbel",
  },
  {
    name: "Pavel Dvořák",
    location: "Prague, Czech Republic",
    avatar: "PD",
    rating: 5,
    text: "We saw a dugong and three sea turtles at Abu Dabbab! The snorkeling here is world-class. Thank you SHAGGY TOURS for this incredible experience.",
    tour: "Abu Dabbab Beach",
  },
];

export const faqs = [
  {
    question: "How do I book a tour with SHAGGY TOURS?",
    answer: "You can book directly through our website by clicking 'Book on WhatsApp' on any tour page. Send us your details and we'll confirm availability within minutes. You can also call or message us on WhatsApp at +20 150 519 1565.",
  },
  {
    question: "What is your cancellation policy?",
    answer: "Free cancellation up to 24 hours before your tour. For overnight trips (Luxor, Aswan), free cancellation up to 48 hours before. We're flexible and always try to accommodate changes.",
  },
  {
    question: "Do you provide hotel pickup?",
    answer: "Yes! We provide free pickup and drop-off from all hotels and resorts in Marsa Alam, Port Ghalib, and surrounding areas.",
  },
  {
    question: "What should I bring on the tours?",
    answer: "For beach/snorkeling tours: swimwear, towel, sunscreen, and a hat. For desert safaris: comfortable closed shoes and light clothing. For Luxor/Aswan: comfortable walking shoes and modest clothing for temple visits.",
  },
  {
    question: "Are the tours suitable for children?",
    answer: "Most of our tours are family-friendly! Beach and snorkeling trips are great for kids aged 6+. Safari tours are suitable for children aged 8+. Contact us for specific age recommendations.",
  },
  {
    question: "What languages do your guides speak?",
    answer: "Our guides speak English, Italian, German, Polish, Czech, and Russian. Let us know your preferred language when booking and we'll arrange a guide who speaks it.",
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept cash (EUR, USD, GBP, EGP), and payment can be made at the time of the tour. For advance bookings, we can arrange bank transfer.",
  },
];

export const categories = [
  { id: "all", label: "All Tours", icon: "🌍" },
  { id: "beach", label: "Beach & Snorkeling", icon: "🏝️" },
  { id: "adventure", label: "Desert Adventure", icon: "🏜️" },
  { id: "cultural", label: "Historical", icon: "🏛️" },
  { id: "nature", label: "Nature & Wildlife", icon: "🐢" },
  { id: "city", label: "City Tour", icon: "🏙️" },
];
