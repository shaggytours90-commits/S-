export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      bookings: {
        Row: {
          admin_notes: string | null
          created_at: string
          date: string
          email: string
          hotel: string
          id: string
          message: string | null
          name: string
          people: number
          room: string | null
          status: string
          tour_id: string
          tour_title: string
          updated_at: string
          whatsapp: string | null
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string
          date: string
          email: string
          hotel: string
          id?: string
          message?: string | null
          name: string
          people?: number
          room?: string | null
          status?: string
          tour_id: string
          tour_title: string
          updated_at?: string
          whatsapp?: string | null
        }
        Update: {
          admin_notes?: string | null
          created_at?: string
          date?: string
          email?: string
          hotel?: string
          id?: string
          message?: string | null
          name?: string
          people?: number
          room?: string | null
          status?: string
          tour_id?: string
          tour_title?: string
          updated_at?: string
          whatsapp?: string | null
        }
        Relationships: []
      }
      categories: {
        Row: {
          active: boolean
          created_at: string
          description: string
          id: string
          image_url: string | null
          name: string
          slug: string
          sort_order: number
          translations: Json
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          description?: string
          id?: string
          image_url?: string | null
          name: string
          slug: string
          sort_order?: number
          translations?: Json
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          description?: string
          id?: string
          image_url?: string | null
          name?: string
          slug?: string
          sort_order?: number
          translations?: Json
          updated_at?: string
        }
        Relationships: []
      }
      contact_messages: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
          phone: string | null
          read: boolean
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          phone?: string | null
          read?: boolean
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          phone?: string | null
          read?: boolean
        }
        Relationships: []
      }
      content_pages: {
        Row: {
          body: string
          created_at: string
          id: string
          published: boolean
          slug: string
          sort_order: number
          title: string
          translations: Json
          updated_at: string
        }
        Insert: {
          body?: string
          created_at?: string
          id?: string
          published?: boolean
          slug: string
          sort_order?: number
          title?: string
          translations?: Json
          updated_at?: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          published?: boolean
          slug?: string
          sort_order?: number
          title?: string
          translations?: Json
          updated_at?: string
        }
        Relationships: []
      }
      faqs: {
        Row: {
          active: boolean
          answer: string
          created_at: string
          id: string
          question: string
          sort_order: number
          translations: Json
          updated_at: string
        }
        Insert: {
          active?: boolean
          answer: string
          created_at?: string
          id?: string
          question: string
          sort_order?: number
          translations?: Json
          updated_at?: string
        }
        Update: {
          active?: boolean
          answer?: string
          created_at?: string
          id?: string
          question?: string
          sort_order?: number
          translations?: Json
          updated_at?: string
        }
        Relationships: []
      }
      gallery_images: {
        Row: {
          active: boolean
          category: string
          created_at: string
          id: string
          image_url: string
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          category?: string
          created_at?: string
          id?: string
          image_url: string
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          category?: string
          created_at?: string
          id?: string
          image_url?: string
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      hero_sections: {
        Row: {
          badge_text: string
          id: string
          image_url: string | null
          key: string
          subtitle: string
          title: string
          translations: Json
          updated_at: string
        }
        Insert: {
          badge_text?: string
          id?: string
          image_url?: string | null
          key: string
          subtitle?: string
          title?: string
          translations?: Json
          updated_at?: string
        }
        Update: {
          badge_text?: string
          id?: string
          image_url?: string | null
          key?: string
          subtitle?: string
          title?: string
          translations?: Json
          updated_at?: string
        }
        Relationships: []
      }
      hotels: {
        Row: {
          active: boolean
          area: string
          created_at: string
          id: string
          name: string
          sort_order: number
          updated_at: string
          zone_id: string | null
        }
        Insert: {
          active?: boolean
          area?: string
          created_at?: string
          id?: string
          name: string
          sort_order?: number
          updated_at?: string
          zone_id?: string | null
        }
        Update: {
          active?: boolean
          area?: string
          created_at?: string
          id?: string
          name?: string
          sort_order?: number
          updated_at?: string
          zone_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "hotels_zone_id_fkey"
            columns: ["zone_id"]
            isOneToOne: false
            referencedRelation: "transfer_zones"
            referencedColumns: ["id"]
          },
        ]
      }
      kb_documents: {
        Row: {
          active: boolean
          created_at: string
          entry_count: number
          filename: string
          id: string
          language: string
          raw_text: string | null
          storage_path: string | null
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          entry_count?: number
          filename: string
          id?: string
          language?: string
          raw_text?: string | null
          storage_path?: string | null
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          entry_count?: number
          filename?: string
          id?: string
          language?: string
          raw_text?: string | null
          storage_path?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      kb_entries: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          destination: string | null
          document_id: string | null
          duration: string | null
          extra: Json
          faqs: Json
          highlights: string[]
          id: string
          included: string[]
          itinerary: Json
          keywords: string[]
          language: string
          not_included: string[]
          price_note: string | null
          raw_section: string | null
          recommendations: string[]
          sort_order: number
          title: string
          tour_slug: string | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          destination?: string | null
          document_id?: string | null
          duration?: string | null
          extra?: Json
          faqs?: Json
          highlights?: string[]
          id?: string
          included?: string[]
          itinerary?: Json
          keywords?: string[]
          language?: string
          not_included?: string[]
          price_note?: string | null
          raw_section?: string | null
          recommendations?: string[]
          sort_order?: number
          title: string
          tour_slug?: string | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          destination?: string | null
          document_id?: string | null
          duration?: string | null
          extra?: Json
          faqs?: Json
          highlights?: string[]
          id?: string
          included?: string[]
          itinerary?: Json
          keywords?: string[]
          language?: string
          not_included?: string[]
          price_note?: string | null
          raw_section?: string | null
          recommendations?: string[]
          sort_order?: number
          title?: string
          tour_slug?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "kb_entries_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "kb_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      media_assets: {
        Row: {
          created_at: string
          folder: string
          id: string
          name: string
          storage_path: string | null
          updated_at: string
          url: string
        }
        Insert: {
          created_at?: string
          folder?: string
          id?: string
          name?: string
          storage_path?: string | null
          updated_at?: string
          url: string
        }
        Update: {
          created_at?: string
          folder?: string
          id?: string
          name?: string
          storage_path?: string | null
          updated_at?: string
          url?: string
        }
        Relationships: []
      }
      seo_meta: {
        Row: {
          created_at: string
          id: string
          keywords: string
          label: string
          meta_description: string
          meta_title: string
          og_image: string | null
          path: string
          translations: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          keywords?: string
          label?: string
          meta_description?: string
          meta_title?: string
          og_image?: string | null
          path: string
          translations?: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          keywords?: string
          label?: string
          meta_description?: string
          meta_title?: string
          og_image?: string | null
          path?: string
          translations?: Json
          updated_at?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          id: string
          key: string
          updated_at: string
          value: string
        }
        Insert: {
          id?: string
          key: string
          updated_at?: string
          value?: string
        }
        Update: {
          id?: string
          key?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      testimonials: {
        Row: {
          active: boolean
          avatar: string
          country: string
          created_at: string
          id: string
          language: string
          location: string
          name: string
          rating: number
          sort_order: number
          text: string
          tour: string
          translations: Json
          updated_at: string
        }
        Insert: {
          active?: boolean
          avatar?: string
          country?: string
          created_at?: string
          id?: string
          language?: string
          location?: string
          name: string
          rating?: number
          sort_order?: number
          text: string
          tour?: string
          translations?: Json
          updated_at?: string
        }
        Update: {
          active?: boolean
          avatar?: string
          country?: string
          created_at?: string
          id?: string
          language?: string
          location?: string
          name?: string
          rating?: number
          sort_order?: number
          text?: string
          tour?: string
          translations?: Json
          updated_at?: string
        }
        Relationships: []
      }
      tours: {
        Row: {
          active: boolean
          available_days: string[]
          available_from: string | null
          available_to: string | null
          best_season: string
          bookable: boolean
          category: string
          child_price: number | null
          created_at: string
          currency: string
          departure_time: string
          description: string
          destination: string
          duration: string
          duration_days: number
          featured: boolean
          gallery_images: string[]
          highlights: string[]
          id: string
          image_url: string | null
          included: string[]
          itinerary: Json
          meeting_point: string
          not_included: string[]
          original_price: number | null
          price: number
          rating: number
          region: string
          reviews: number
          short_description: string
          slug: string
          sort_order: number
          title: string
          translations: Json
          updated_at: string
          what_to_bring: string[]
        }
        Insert: {
          active?: boolean
          available_days?: string[]
          available_from?: string | null
          available_to?: string | null
          best_season?: string
          bookable?: boolean
          category?: string
          child_price?: number | null
          created_at?: string
          currency?: string
          departure_time?: string
          description?: string
          destination: string
          duration?: string
          duration_days?: number
          featured?: boolean
          gallery_images?: string[]
          highlights?: string[]
          id?: string
          image_url?: string | null
          included?: string[]
          itinerary?: Json
          meeting_point?: string
          not_included?: string[]
          original_price?: number | null
          price?: number
          rating?: number
          region?: string
          reviews?: number
          short_description?: string
          slug: string
          sort_order?: number
          title: string
          translations?: Json
          updated_at?: string
          what_to_bring?: string[]
        }
        Update: {
          active?: boolean
          available_days?: string[]
          available_from?: string | null
          available_to?: string | null
          best_season?: string
          bookable?: boolean
          category?: string
          child_price?: number | null
          created_at?: string
          currency?: string
          departure_time?: string
          description?: string
          destination?: string
          duration?: string
          duration_days?: number
          featured?: boolean
          gallery_images?: string[]
          highlights?: string[]
          id?: string
          image_url?: string | null
          included?: string[]
          itinerary?: Json
          meeting_point?: string
          not_included?: string[]
          original_price?: number | null
          price?: number
          rating?: number
          region?: string
          reviews?: number
          short_description?: string
          slug?: string
          sort_order?: number
          title?: string
          translations?: Json
          updated_at?: string
          what_to_bring?: string[]
        }
        Relationships: []
      }
      transfer_zones: {
        Row: {
          active: boolean
          created_at: string
          id: string
          name: string
          notes: string
          sort_order: number
          transfer_price: number
          translations: Json
          updated_at: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          name: string
          notes?: string
          sort_order?: number
          transfer_price?: number
          translations?: Json
          updated_at?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          name?: string
          notes?: string
          sort_order?: number
          transfer_price?: number
          translations?: Json
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      is_admin: { Args: never; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
