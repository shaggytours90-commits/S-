import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface TransferZone {
  id: string;
  name: string;
  translations: Record<string, { name?: string }> | null;
  transfer_price: number;
  notes: string;
  sort_order: number;
  active: boolean;
}

export interface Hotel {
  id: string;
  name: string;
  zone_id: string | null;
  area: string;
  sort_order: number;
  active: boolean;
}

export const useTransferZones = (includeInactive = false) =>
  useQuery({
    queryKey: ["transfer-zones", includeInactive],
    queryFn: async () => {
      let query = supabase.from("transfer_zones").select("*").order("sort_order");
      if (!includeInactive) query = query.eq("active", true);
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []) as unknown as TransferZone[];
    },
  });

export const useHotels = (includeInactive = false) =>
  useQuery({
    queryKey: ["hotels", includeInactive],
    queryFn: async () => {
      let query = supabase.from("hotels").select("*").order("sort_order").order("name");
      if (!includeInactive) query = query.eq("active", true);
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []) as unknown as Hotel[];
    },
  });

export const zoneName = (zone: TransferZone | undefined, lang: string) =>
  zone ? zone.translations?.[lang]?.name || zone.name : "";
