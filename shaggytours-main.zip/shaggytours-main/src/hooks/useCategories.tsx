import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface DbCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  image_url: string | null;
  sort_order: number;
  active: boolean;
  translations?: Record<string, { name?: string }> | null;
}

export const categoryLabel = (c: DbCategory | undefined, lang: string) =>
  c ? c.translations?.[lang.slice(0, 2)]?.name || c.name : "";

export const useCategories = (onlyActive = true) => {
  return useQuery({
    queryKey: ["categories", onlyActive],
    queryFn: async (): Promise<DbCategory[]> => {
      let query = supabase.from("categories").select("*").order("sort_order", { ascending: true });
      if (onlyActive) query = query.eq("active", true);
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []) as unknown as DbCategory[];
    },
    staleTime: 1000 * 60 * 5,
  });
};
