import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";

export interface ContentPage {
  id: string;
  slug: string;
  title: string;
  body: string;
  translations: Record<string, { title?: string; body?: string }>;
  published: boolean;
  sort_order: number;
}

export const localizePage = (page: ContentPage | null, lang: string) => {
  if (!page) return null;
  const tr = page.translations?.[lang] ?? {};
  return {
    ...page,
    title: tr.title?.trim() || page.title,
    body: tr.body?.trim() || page.body,
  };
};

export const useContentPage = (slug: string) => {
  const { i18n } = useTranslation();
  return useQuery({
    queryKey: ["content-page", slug, i18n.language],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("content_pages")
        .select("*")
        .eq("slug", slug)
        .eq("published", true)
        .maybeSingle();
      if (error) throw error;
      return localizePage(data as unknown as ContentPage | null, i18n.language);
    },
    staleTime: 1000 * 60 * 5,
  });
};

export const useContentPages = () => {
  const { i18n } = useTranslation();
  return useQuery({
    queryKey: ["content-pages", i18n.language],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("content_pages")
        .select("*")
        .eq("published", true)
        .order("sort_order");
      if (error) throw error;
      return ((data ?? []) as unknown as ContentPage[]).map((p) => localizePage(p, i18n.language)!);
    },
    staleTime: 1000 * 60 * 5,
  });
};
