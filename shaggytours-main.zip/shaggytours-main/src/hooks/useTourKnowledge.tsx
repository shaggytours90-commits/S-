import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";

export interface KbItineraryStep {
  day: number;
  title: string;
  description: string;
}

export interface KbFaq {
  question: string;
  answer: string;
}

export interface KbEntry {
  id: string;
  document_id: string | null;
  language: string;
  tour_slug: string | null;
  title: string;
  category: string | null;
  destination: string | null;
  keywords: string[];
  description: string | null;
  duration: string | null;
  price_note: string | null;
  highlights: string[];
  itinerary: KbItineraryStep[];
  included: string[];
  not_included: string[];
  recommendations: string[];
  faqs: KbFaq[];
  sort_order: number;
}

const fetchKnowledge = async (): Promise<KbEntry[]> => {
  const { data: docs, error: docErr } = await supabase
    .from("kb_documents")
    .select("id, language, updated_at")
    .eq("active", true);
  if (docErr) throw docErr;
  const ids = (docs ?? []).map((d) => d.id);
  if (!ids.length) return [];

  const { data, error } = await supabase
    .from("kb_entries")
    .select("*")
    .in("document_id", ids)
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data ?? []) as unknown as KbEntry[];
};

/** All knowledge-base entries from the currently active uploaded documents. */
export const useKnowledgeBase = () =>
  useQuery({
    queryKey: ["kb-entries"],
    queryFn: fetchKnowledge,
    staleTime: 1000 * 60 * 5,
  });

const normalise = (v: string) => v.toLowerCase().trim();

/** Pick the best entry for a tour in the active UI language, falling back to any language. */
export const useTourKnowledge = (slug?: string, title?: string) => {
  const { i18n } = useTranslation();
  const lang = (i18n.language || "en").split("-")[0];
  const { data = [], isLoading } = useKnowledgeBase();

  const candidates = data.filter((e) => {
    if (slug && e.tour_slug && e.tour_slug === slug) return true;
    if (title && normalise(e.title) === normalise(title)) return true;
    if (title && e.keywords?.some((k) => normalise(title).includes(normalise(k)))) return true;
    return false;
  });

  const entry = candidates.find((e) => e.language === lang) ?? candidates[0] ?? null;
  return { entry, isLoading, isTranslated: entry ? entry.language === lang : false };
};

/** Free-text search across the knowledge base by name, category, destination or keyword. */
export const searchKnowledge = (entries: KbEntry[], q: string) => {
  const term = normalise(q);
  if (!term) return entries;
  return entries.filter((e) =>
    [e.title, e.category ?? "", e.destination ?? "", e.description ?? "", ...(e.keywords ?? [])]
      .join(" ")
      .toLowerCase()
      .includes(term),
  );
};
