import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface DbFAQ {
  id: string;
  question: string;
  answer: string;
  sort_order: number;
  active: boolean;
}

export const useFAQs = () => {
  return useQuery({
    queryKey: ["faqs"],
    queryFn: async (): Promise<DbFAQ[]> => {
      const { data, error } = await supabase
        .from("faqs")
        .select("*")
        .eq("active", true)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as DbFAQ[];
    },
    staleTime: 1000 * 60 * 5,
  });
};
