import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import i18n from "@/i18n";
import { catalogBySlug } from "@/data/catalog";

export interface DbTour {
  id: string;
  slug: string;
  title: string;
  destination: string;
  region: string;
  image_url: string | null;
  price: number;
  original_price: number | null;
  duration: string;
  duration_days: number;
  rating: number;
  reviews: number;
  description: string;
  highlights: string[];
  itinerary: { day: number; title: string; description: string }[];
  included: string[];
  not_included: string[];
  featured: boolean;
  category: string;
  best_season: string;
  sort_order: number;
  active: boolean;
  child_price?: number | null;
  short_description?: string;
  available_days?: string[];
  translations?: Record<string, Partial<Record<"title" | "short_description" | "description", string>>> | null;
}

/** Returns the tour with title/descriptions in the given language, falling back to English. */
export const localizeTour = <T extends DbTour>(tour: T, lang: string): T => {
  const tr = tour.translations?.[lang.slice(0, 2)];
  const text = (field: "title" | "short_description" | "description") => {
    const translated = tr?.[field];
    if (translated) return translated;
    const key = `tourCatalog.${tour.slug}.${field}`;
    if (catalogBySlug.has(tour.slug) && i18n.exists(key, { lng: lang })) {
      // Existing CMS English edits remain authoritative over seed text.
      const english = i18n.t(key, { lng: "en" });
      if (tour[field] && tour[field] !== english) return tour[field];
      return i18n.t(key, { lng: lang });
    }
    return tour[field];
  };
  return {
    ...tour,
    title: text("title") || tour.title,
    short_description: text("short_description"),
    description: text("description") || tour.description,
  };
};

export const useTours = () => {
  return useQuery({
    queryKey: ["tours"],
    queryFn: async (): Promise<DbTour[]> => {
      const { data, error } = await supabase
        .from("tours")
        .select("*")
        .eq("active", true)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as DbTour[];
    },
    staleTime: 1000 * 60 * 2,
  });
};
