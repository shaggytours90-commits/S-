import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface DbGalleryImage {
  id: string;
  title: string;
  image_url: string;
  category: string;
  sort_order: number;
  active: boolean;
}

export const useGalleryImages = () => {
  return useQuery({
    queryKey: ["gallery-images"],
    queryFn: async (): Promise<DbGalleryImage[]> => {
      const { data, error } = await supabase
        .from("gallery_images")
        .select("*")
        .eq("active", true)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as DbGalleryImage[];
    },
    staleTime: 1000 * 60 * 5,
  });
};
