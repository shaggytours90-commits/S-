import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface SiteSettings {
  site_name: string;
  site_email: string;
  whatsapp_number: string;
  whatsapp_number_2: string;
  phone_display: string;
  address: string;
  facebook_url: string;
  instagram_url: string;
  tiktok_url: string;
  youtube_url: string;
  twitter_url: string;
  tripadvisor_url: string;
  site_description: string;
  footer_tagline: string;
  logo_url: string;
  currency_code: string;
  currency_symbol: string;
  company_name: string;
  company_address: string;
  company_registration: string;
  working_hours: string;
  default_meta_title: string;
  default_meta_description: string;
  default_meta_keywords: string;
  default_og_image: string;
}

const defaults: SiteSettings = {
  site_name: "SHAGGY TOURS",
  site_email: "info@shaggytours.com",
  whatsapp_number: "201505191565",
  whatsapp_number_2: "",
  phone_display: "+20 150 519 1565",
  address: "Marsa Alam, Red Sea, Egypt",
  facebook_url: "#",
  instagram_url: "#",
  tiktok_url: "",
  youtube_url: "",
  twitter_url: "",
  tripadvisor_url: "",
  site_description: "",
  footer_tagline: "",
  logo_url: "",
  currency_code: "GBP",
  currency_symbol: "£",
  company_name: "SHAGGY TOURS",
  company_address: "",
  company_registration: "",
  working_hours: "",
  default_meta_title: "",
  default_meta_description: "",
  default_meta_keywords: "",
  default_og_image: "",
};

export const SETTING_KEYS = Object.keys(defaults) as (keyof SiteSettings)[];

export const useSiteSettings = () => {
  return useQuery({
    queryKey: ["site-settings"],
    queryFn: async (): Promise<SiteSettings> => {
      const { data, error } = await supabase.from("site_settings").select("key, value");
      if (error) throw error;
      const settings = { ...defaults };
      data?.forEach((row: { key: string; value: string }) => {
        if (row.key in settings && row.value) {
          (settings as Record<string, string>)[row.key] = row.value;
        }
      });
      return settings;
    },
    staleTime: 1000 * 60 * 5,
  });
};
