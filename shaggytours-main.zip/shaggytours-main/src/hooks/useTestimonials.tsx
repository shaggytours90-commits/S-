import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";

export interface DbTestimonial {
  id: string;
  name: string;
  location: string;
  avatar: string;
  rating: number;
  text: string;
  tour: string;
  sort_order: number;
  active: boolean;
  language: string;
  country: string;
}

/** All active testimonials, every language. */
export const useAllTestimonials = () => {
  return useQuery({
    queryKey: ["testimonials"],
    queryFn: async (): Promise<DbTestimonial[]> => {
      const { data, error } = await supabase
        .from("testimonials")
        .select("*")
        .eq("active", true)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data ?? []) as DbTestimonial[];
    },
    staleTime: 1000 * 60 * 5,
  });
};

/**
 * Testimonials for the active UI language.
 * Falls back to English, then to every review, so the section is never empty.
 */
export const useTestimonials = () => {
  const { i18n } = useTranslation();
  const lang = (i18n.language || "en").split("-")[0];
  const query = useAllTestimonials();
  const all = query.data ?? [];

  const inLang = all.filter((t) => (t.language || "en") === lang);
  const inEnglish = all.filter((t) => (t.language || "en") === "en");
  const data = inLang.length ? inLang : inEnglish.length ? inEnglish : all;

  return { ...query, data };
};
