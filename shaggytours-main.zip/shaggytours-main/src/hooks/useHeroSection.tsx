import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface DbHeroSection {
  id: string;
  key: string;
  title: string;
  subtitle: string;
  badge_text: string;
  image_url: string | null;
}

export const useHeroSection = (key: string) => {
  return useQuery({
    queryKey: ["hero-section", key],
    queryFn: async (): Promise<DbHeroSection | null> => {
      const { data, error } = await supabase
        .from("hero_sections")
        .select("*")
        .eq("key", key)
        .maybeSingle();
      if (error) throw error;
      return data as DbHeroSection | null;
    },
    staleTime: 1000 * 60 * 5,
  });
};
