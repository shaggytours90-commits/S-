import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import WhatsAppFloat from "./components/WhatsAppFloat";

const Tours = lazy(() => import("./pages/Tours"));
const TourDetail = lazy(() => import("./pages/TourDetail"));
const Gallery = lazy(() => import("./pages/Gallery"));
const About = lazy(() => import("./pages/About"));
const Contact = lazy(() => import("./pages/Contact"));
const NotFound = lazy(() => import("./pages/NotFound"));
const AdminLogin = lazy(() => import("./pages/AdminLogin"));
const AdminLayout = lazy(() => import("./pages/admin/AdminLayout"));
const DashboardHome = lazy(() => import("./pages/admin/DashboardHome"));
const AdminBookings = lazy(() => import("./pages/admin/AdminBookings"));
const AdminTours = lazy(() => import("./pages/admin/AdminTours"));
const AdminMessages = lazy(() => import("./pages/admin/AdminMessages"));
const AdminSettings = lazy(() => import("./pages/admin/AdminSettings"));
const AdminFAQs = lazy(() => import("./pages/admin/AdminFAQs"));
const AdminTestimonials = lazy(() => import("./pages/admin/AdminTestimonials"));
const AdminGallery = lazy(() => import("./pages/admin/AdminGallery"));
const AdminHero = lazy(() => import("./pages/admin/AdminHero"));
const AdminKnowledge = lazy(() => import("./pages/admin/AdminKnowledge"));
const AdminHotels = lazy(() => import("./pages/admin/AdminHotels"));
const AdminPages = lazy(() => import("./pages/admin/AdminPages"));
const AdminMedia = lazy(() => import("./pages/admin/AdminMedia"));
const AdminSeo = lazy(() => import("./pages/admin/AdminSeo"));
const OAuthConsent = lazy(() => import("./pages/OAuthConsent"));


const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <WhatsAppFloat />
          <Suspense fallback={null}>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/tours" element={<Tours />} />
              <Route path="/tour/:id" element={<TourDetail />} />
              <Route path="/gallery" element={<Gallery />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/.lovable/oauth/consent" element={<OAuthConsent />} />
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<DashboardHome />} />
                <Route path="bookings" element={<AdminBookings />} />
                <Route path="tours" element={<AdminTours />} />
                <Route path="messages" element={<AdminMessages />} />
                <Route path="hero" element={<AdminHero />} />
                <Route path="gallery" element={<AdminGallery />} />
                <Route path="faqs" element={<AdminFAQs />} />
                <Route path="testimonials" element={<AdminTestimonials />} />
                <Route path="settings" element={<AdminSettings />} />
                <Route path="knowledge" element={<AdminKnowledge />} />
                <Route path="hotels" element={<AdminHotels />} />
                <Route path="pages" element={<AdminPages />} />
                <Route path="media" element={<AdminMedia />} />
                <Route path="seo" element={<AdminSeo />} />

              </Route>
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
