import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { supabase } from "@/integrations/supabase/client";
import { useSiteSettings } from "@/hooks/useSiteSettings";

interface SeoRow {
  path: string;
  meta_title: string;
  meta_description: string;
  keywords: string;
  og_image: string | null;
  translations: Record<string, { meta_title?: string; meta_description?: string; keywords?: string }>;
}

const setMeta = (selector: string, attr: string, key: string, value: string) => {
  if (!value) return;
  let el = document.head.querySelector<HTMLMetaElement>(selector);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", value);
};

interface SeoProps {
  path?: string;
  title?: string;
  description?: string;
  image?: string;
  jsonLd?: Record<string, unknown>;
}

/** Reads SEO metadata from the database (seo_meta) with per-language overrides. */
export const Seo = ({ path, title, description, image, jsonLd }: SeoProps) => {
  const { i18n } = useTranslation();
  const { data: settings } = useSiteSettings();
  const activePath = path ?? window.location.pathname;

  const { data: row } = useQuery({
    queryKey: ["seo-meta", activePath],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("seo_meta")
        .select("*")
        .eq("path", activePath)
        .maybeSingle();
      if (error) throw error;
      return data as unknown as SeoRow | null;
    },
    staleTime: 1000 * 60 * 5,
  });

  useEffect(() => {
    const tr = row?.translations?.[i18n.language] ?? {};
    const finalTitle =
      title || tr.meta_title || row?.meta_title || settings?.default_meta_title || document.title;
    const finalDesc =
      description || tr.meta_description || row?.meta_description || settings?.default_meta_description || "";
    const finalKeywords = tr.keywords || row?.keywords || settings?.default_meta_keywords || "";
    const finalImage = image || row?.og_image || settings?.default_og_image || "";

    if (finalTitle) document.title = finalTitle;
    setMeta('meta[name="description"]', "name", "description", finalDesc);
    setMeta('meta[name="keywords"]', "name", "keywords", finalKeywords);
    setMeta('meta[property="og:title"]', "property", "og:title", finalTitle);
    setMeta('meta[property="og:description"]', "property", "og:description", finalDesc);
    setMeta('meta[property="og:type"]', "property", "og:type", "website");
    setMeta('meta[name="twitter:card"]', "name", "twitter:card", "summary_large_image");
    if (finalImage) setMeta('meta[property="og:image"]', "property", "og:image", finalImage);

    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.rel = "canonical";
      document.head.appendChild(canonical);
    }
    canonical.href = window.location.origin + activePath;
  }, [row, settings, title, description, image, i18n.language, activePath]);

  useEffect(() => {
    if (!jsonLd) return;
    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.text = JSON.stringify(jsonLd);
    document.head.appendChild(script);
    return () => {
      document.head.removeChild(script);
    };
  }, [jsonLd]);

  return null;
};

export default Seo;
