import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import { MessageCircle } from "lucide-react";
import { Button } from "./ui/button";
import { useSiteSettings } from "@/hooks/useSiteSettings";

const NewsletterSection = () => {
  const { data: settings } = useSiteSettings();
  const { t } = useTranslation();
  const whatsapp = settings?.whatsapp_number || "201505191565";
  const siteName = settings?.site_name || "SHAGGY TOURS";

  const handleWhatsApp = () => {
    const msg = encodeURIComponent(`Hello ${siteName},\n${t("sections.newsletter.msg")}\n\nThank you!`);
    window.open(`https://wa.me/${whatsapp}?text=${msg}`, "_blank");
  };

  return (
    <section className="section-padding bg-primary relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-accent/10 blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-primary-foreground/5 blur-2xl translate-y-1/2 -translate-x-1/2" />

      <div className="container-wide mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-primary-foreground mb-4">
            {t("sections.newsletter.title")}
          </h2>
          <p className="text-primary-foreground/70 max-w-lg mx-auto mb-8">
            {t("sections.newsletter.subtitle")}
          </p>
          <Button
            onClick={handleWhatsApp}
            size="lg"
            className="bg-[hsl(142,70%,45%)] text-primary-foreground hover:bg-[hsl(142,70%,40%)] rounded-xl px-8 gap-2 text-base"
          >
            <MessageCircle className="h-5 w-5" /> {t("sections.newsletter.cta")}
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default NewsletterSection;
