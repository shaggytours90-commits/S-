import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useFAQs } from "@/hooks/useFAQs";
import InlineEditable from "@/components/InlineEditable";

const FAQSection = () => {
  const { data: faqs = [] } = useFAQs();
  const { t } = useTranslation();

  if (faqs.length === 0) return null;

  return (
    <section className="section-padding bg-background">
      <div className="container-wide mx-auto max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <span className="section-label">{t("sections.faq.label")}</span>
          <h2 className="section-title">{t("sections.faq.title")}</h2>
        </motion.div>

        <Accordion type="single" collapsible className="space-y-3">
          {faqs.map((faq, i) => (
            <AccordionItem
              key={faq.id}
              value={`faq-${i}`}
              className="bg-card rounded-2xl border border-border px-6 data-[state=open]:shadow-md transition-shadow"
            >
              <AccordionTrigger className="text-left text-foreground font-medium text-sm hover:no-underline py-5">
                <InlineEditable table="faqs" id={faq.id} field="question" value={faq.question} queryKey={["faqs"]}>
                  {faq.question}
                </InlineEditable>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-5">
                <InlineEditable table="faqs" id={faq.id} field="answer" value={faq.answer} queryKey={["faqs"]} multiline>
                  {faq.answer}
                </InlineEditable>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

export default FAQSection;
