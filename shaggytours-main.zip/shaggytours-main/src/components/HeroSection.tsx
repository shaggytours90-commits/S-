import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import heroImageFallback from "@/assets/hero-marsa-alam.jpg";
import TravelSearchBox from "./TravelSearchBox";
import { Plane, Shield, CreditCard, Headphones, Star, MessageCircle, ArrowRight, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { useHeroSection } from "@/hooks/useHeroSection";

const HeroSection = () => {
  const { data: settings } = useSiteSettings();
  const { data: hero } = useHeroSection("home");
  const { t, i18n } = useTranslation();
  const siteName = settings?.site_name || "SHAGGY TOURS";
  const whatsapp = settings?.whatsapp_number || "201505191565";
  const waMessage = encodeURIComponent(`Hello ${siteName},\nI'd like to book a tour. Please confirm availability.`);

  const features = [
    { icon: Plane, label: t("hero.features.excursions") },
    { icon: Shield, label: t("hero.features.bestPrice") },
    { icon: CreditCard, label: t("hero.features.freeCancel") },
    { icon: Headphones, label: t("hero.features.support") },
  ];

  const isEnglish = i18n.language.startsWith("en");
  const badgeText = isEnglish && hero?.badge_text ? hero.badge_text : t("hero.badgeFallback");
  const subtitle = isEnglish && hero?.subtitle ? hero.subtitle : `${t("hero.subtitleFallback")} ${siteName}.`;
  const heroImage = hero?.image_url || heroImageFallback;

  const renderTitle = () => {
    const rawTitle = isEnglish && hero?.title ? hero.title : `${t("hero.titleLine1")}<br><span>${t("hero.titleAccent")}</span>`;
    return <span dangerouslySetInnerHTML={{ __html: rawTitle.replace(/<span>/g, '<span class="text-accent">') }} />;
  };

  return (
    <section className="relative min-h-[100dvh] flex flex-col items-center justify-center overflow-hidden">
      <img
        src={heroImage}
        alt="Marsa Alam Red Sea coast aerial view"
        width={1920}
        height={1080}
        sizes="100vw"
        className="absolute inset-0 w-full h-full object-cover scale-105"
        loading="eager"
        fetchPriority="high"
      />
      <div className="hero-overlay" />

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 flex flex-col items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-center mb-8 max-w-3xl"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.15 }}
            className="inline-flex items-center gap-2 bg-accent/20 backdrop-blur-md border border-accent/30 text-accent-foreground px-4 py-1.5 rounded-full text-sm font-medium mb-6 shadow-lg"
          >
            <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
            {badgeText}
          </motion.div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-primary-foreground leading-[1.05] mb-5 drop-shadow-lg">
            {renderTitle()}
          </h1>
          <p className="text-primary-foreground/85 text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
            {subtitle}
          </p>

          {/* Rating + CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="mt-7 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <div className="flex items-center gap-2 trust-chip">
              <div className="flex" aria-hidden>
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-3.5 w-3.5 fill-warm text-warm" />
                ))}
              </div>
              <span className="text-primary-foreground font-semibold">4.9</span>
              <span className="text-primary-foreground/70">· 500+ {t("hero.reviews", "reviews")}</span>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Button asChild size="lg" className="rounded-full px-6 shadow-lg hover:shadow-xl transition-shadow">
                <Link to="/tours">
                  {t("hero.exploreTours", "Explore Tours")}
                  <ArrowRight className="ms-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="secondary" className="rounded-full px-6 bg-[hsl(142,70%,45%)] text-white hover:bg-[hsl(142,70%,40%)] border-0 shadow-lg">
                <a href={`https://wa.me/${whatsapp}?text=${waMessage}`} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="me-1 h-4 w-4" />
                  {t("hero.whatsapp", "Book on WhatsApp")}
                </a>
              </Button>
            </div>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="w-full flex justify-center mb-10"
        >
          <TravelSearchBox />
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="flex flex-wrap items-center justify-center gap-x-8 gap-y-3"
        >
          {features.map(({ icon: Icon, label }) => (
            <div key={label} className="flex items-center gap-2 text-primary-foreground/85">
              <div className="w-8 h-8 rounded-full bg-primary-foreground/10 backdrop-blur-md flex items-center justify-center border border-white/10">
                <Icon className="h-4 w-4" />
              </div>
              <span className="text-sm font-medium">{label}</span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.a
        href="#destinations"
        aria-label="Scroll to explore"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 hidden md:flex flex-col items-center gap-1 text-primary-foreground/70 hover:text-primary-foreground transition-colors"
      >
        <span className="text-[10px] tracking-[0.3em] uppercase">{t("hero.scroll", "Scroll")}</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        >
          <ChevronDown className="h-5 w-5" />
        </motion.div>
      </motion.a>
    </section>
  );
};

export default HeroSection;
