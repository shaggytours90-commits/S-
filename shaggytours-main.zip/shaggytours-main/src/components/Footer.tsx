import { Link } from "react-router-dom";
import { MapPin, Mail, Phone, Facebook, Instagram, MessageCircle } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useSiteSettings } from "@/hooks/useSiteSettings";

const Footer = () => {
  const { data: settings } = useSiteSettings();
  const { t, i18n } = useTranslation();
  const siteName = settings?.site_name || "SHAGGY TOURS";
  const whatsapp = settings?.whatsapp_number || "201505191565";
  const phone = settings?.phone_display || "+20 150 519 1565";
  const email = settings?.site_email || "info@shaggytours.com";
  const address = settings?.address || "Marsa Alam, Red Sea, Egypt";
  const tagline = i18n.language.startsWith("en") && settings?.footer_tagline
    ? settings.footer_tagline
    : t("footer.tagline");
  const facebookUrl = settings?.facebook_url || "#";
  const instagramUrl = settings?.instagram_url || "#";

  const socialLinks = [
    { icon: Facebook, href: facebookUrl },
    { icon: Instagram, href: instagramUrl },
    { icon: MessageCircle, href: `https://wa.me/${whatsapp}`, external: true },
  ];

  return (
    <footer className="bg-foreground text-background">
      <div className="container-wide mx-auto section-padding">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="h-6 w-6 text-accent" />
              <span className="font-serif text-2xl font-bold">{siteName}</span>
            </div>
            <p className="text-background/60 text-sm leading-relaxed mb-6">{tagline}</p>
            <div className="flex gap-2">
              {socialLinks.map((link, i) => (
                <a
                  key={i}
                  href={link.href}
                  target={link.external ? "_blank" : undefined}
                  rel={link.external ? "noopener noreferrer" : undefined}
                  className="w-9 h-9 rounded-xl bg-background/10 flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-colors"
                  aria-label="Social media"
                >
                  <link.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold mb-4">{t("footer.quickLinks")}</h4>
            <ul className="space-y-2.5">
              {[
                { label: t("nav.home"), path: "/" },
                { label: t("nav.tours"), path: "/tours" },
                { label: t("nav.gallery"), path: "/gallery" },
                { label: t("nav.about"), path: "/about" },
                { label: t("nav.contact"), path: "/contact" },
              ].map((link) => (
                <li key={link.path}>
                  <Link to={link.path} className="text-sm text-background/60 hover:text-accent transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold mb-4">{t("footer.popularTours")}</h4>
            <ul className="space-y-2.5">
              {["Dolphin House Samadai", "Hamata Islands", "Luxor Day Trip", "Super Safari", "Sharm El Luli", "Abu Simbel"].map((dest) => (
                <li key={dest}>
                  <Link to="/tours" className="text-sm text-background/60 hover:text-accent transition-colors">
                    {dest}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold mb-4">{t("footer.contactInfo")}</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5">
                <MapPin className="h-4 w-4 mt-0.5 text-accent shrink-0" />
                <span className="text-sm text-background/60">{address}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 text-accent shrink-0" />
                <a href={`https://wa.me/${whatsapp}`} target="_blank" rel="noopener noreferrer" className="text-sm text-background/60 hover:text-accent transition-colors">{phone}</a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 text-accent shrink-0" />
                <a href={`mailto:${email}`} className="text-sm text-background/60 hover:text-accent transition-colors">{email}</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-background/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-background/40">
            © {new Date().getFullYear()} {siteName}. {t("footer.rights")}
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-xs text-background/40 hover:text-background/70 transition-colors">{t("footer.privacy")}</a>
            <a href="#" className="text-xs text-background/40 hover:text-background/70 transition-colors">{t("footer.terms")}</a>
            <Link to="/admin/login" className="text-xs text-background/40 hover:text-background/70 transition-colors">{t("footer.adminLogin")}</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
