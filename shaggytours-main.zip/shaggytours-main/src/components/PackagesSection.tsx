import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import TourCard from "./TourCard";
import { Button } from "./ui/button";
import { ArrowRight } from "lucide-react";
import { useState, useMemo } from "react";
import { useTours } from "@/hooks/useTours";
import { useCategories, categoryLabel } from "@/hooks/useCategories";

const PackagesSection = () => {
  const [activeCategory, setActiveCategory] = useState("all");
  const { data: tours = [] } = useTours();
  const { t, i18n } = useTranslation();
  const { data: dbCats = [] } = useCategories();
  const categories = [{ id: "all", label: t("catalog.allTours") }, ...dbCats.map((c) => ({ id: c.slug, label: t(`categoryNames.${c.slug}`, { defaultValue: categoryLabel(c, i18n.language) }) }))];

  const filtered = useMemo(() => {
    const list = activeCategory === "all" ? tours : tours.filter((t) => t.category === activeCategory);
    return list.slice(0, 8);
  }, [activeCategory, tours]);

  return (
    <section className="section-padding bg-secondary/50">
      <div className="container-wide mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <span className="section-label">{t("sections.packages.label")}</span>
          <h2 className="section-title mb-4">{t("sections.packages.title")}</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">{t("sections.packages.subtitle")}</p>
        </motion.div>

        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                activeCategory === cat.id
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filtered.map((tour, i) => (
            <motion.div
              key={tour.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              layout
            >
              <TourCard tour={tour} />
            </motion.div>
          ))}
        </div>

        {filtered.length === 0 && (
          <p className="text-center text-muted-foreground py-12">{t("sections.packages.emptyCategory")}</p>
        )}

        <div className="text-center mt-10">
          <Link to="/tours">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2 rounded-xl px-8">
              {t("sections.packages.viewAllTours")} <ArrowRight className="h-4 w-4 rtl:rotate-180" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PackagesSection;
