import { useState } from "react";
import { MoreVertical, Pencil, Eye, EyeOff, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TourQuickActionsProps {
  isActive: boolean;
  onEdit: () => void;
  onToggleActive: () => void;
  onDelete: () => void;
  isToggling?: boolean;
}

const TourQuickActions = ({ isActive, onEdit, onToggleActive, onDelete, isToggling }: TourQuickActionsProps) => {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="icon"
        className="h-10 w-10 rounded-full"
        onClick={() => setOpen(!open)}
      >
        <MoreVertical className="h-5 w-5" />
      </Button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-12 z-50 bg-card border border-border rounded-xl shadow-lg min-w-[180px] py-2 animate-in fade-in slide-in-from-top-2">
            <button
              onClick={() => { onEdit(); setOpen(false); }}
              className="flex items-center gap-3 w-full px-4 py-3 text-sm text-foreground hover:bg-muted transition-colors"
            >
              <Pencil className="h-4 w-4" /> Edit
            </button>
            <button
              onClick={() => { onToggleActive(); setOpen(false); }}
              disabled={isToggling}
              className="flex items-center gap-3 w-full px-4 py-3 text-sm text-foreground hover:bg-muted transition-colors"
            >
              {isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              {isActive ? "Hide" : "Show"}
            </button>
            <button
              onClick={() => {
                if (confirm("Delete this tour permanently?")) {
                  onDelete();
                }
                setOpen(false);
              }}
              className="flex items-center gap-3 w-full px-4 py-3 text-sm text-destructive hover:bg-destructive/10 transition-colors"
            >
              <Trash2 className="h-4 w-4" /> Delete
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default TourQuickActions;
