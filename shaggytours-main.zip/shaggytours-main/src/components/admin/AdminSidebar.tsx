import { LayoutDashboard, CalendarCheck, Map, MessageSquare, Settings, LogOut, Image, HelpCircle, Star, Sparkles, BookOpen, Hotel, FileText, Search, FolderOpen } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useAuth } from "@/hooks/useAuth";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";

const items = [
  { title: "Dashboard", url: "/admin", icon: LayoutDashboard },
  { title: "Bookings", url: "/admin/bookings", icon: CalendarCheck },
  { title: "Tours", url: "/admin/tours", icon: Map },
  { title: "Hotels & Zones", url: "/admin/hotels", icon: Hotel },
  { title: "Knowledge Base", url: "/admin/knowledge", icon: BookOpen },
  { title: "Messages", url: "/admin/messages", icon: MessageSquare },
  { title: "Hero Section", url: "/admin/hero", icon: Sparkles },
  { title: "Gallery", url: "/admin/gallery", icon: Image },
  { title: "Pages", url: "/admin/pages", icon: FileText },
  { title: "Media", url: "/admin/media", icon: FolderOpen },
  { title: "SEO", url: "/admin/seo", icon: Search },
  { title: "FAQs", url: "/admin/faqs", icon: HelpCircle },
  { title: "Testimonials", url: "/admin/testimonials", icon: Star },
  { title: "Site Settings", url: "/admin/settings", icon: Settings },
];


export function AdminSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { signOut, user } = useAuth();

  return (
    <Sidebar collapsible="icon">
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>
            {!collapsed && "SHAGGY TOURS"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      end={item.url === "/admin"}
                      className="hover:bg-sidebar-accent/50"
                      activeClassName="bg-sidebar-accent text-sidebar-primary font-medium"
                    >
                      <item.icon className="mr-2 h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <div className="p-2">
          {!collapsed && user && (
            <p className="text-xs text-sidebar-foreground/60 truncate mb-2 px-2">
              {user.email}
            </p>
          )}
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton onClick={signOut} className="text-destructive hover:bg-destructive/10">
                <LogOut className="mr-2 h-4 w-4" />
                {!collapsed && <span>Sign Out</span>}
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
