import { useState } from "react";
import { Upload, X, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { optimizeImageUrl } from "@/lib/imageUtils";
import { toast } from "sonner";

interface TourImageGalleryProps {
  mainImage: string;
  images: string[];
  onMainImageChange: (url: string) => void;
  onImagesChange: (urls: string[]) => void;
}

const TourImageGallery = ({ mainImage, images, onMainImageChange, onImagesChange }: TourImageGalleryProps) => {
  const [uploading, setUploading] = useState(false);

  const all = Array.from(new Set([...(mainImage ? [mainImage] : []), ...images]));

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files?.length) return;
    setUploading(true);

    const uploaded: string[] = [];
    for (const file of Array.from(files)) {
      const ext = file.name.split(".").pop();
      const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage.from("tour-images").upload(path, file);
      if (error) {
        toast.error(`Failed: ${file.name}`);
        continue;
      }
      const { data } = supabase.storage.from("tour-images").getPublicUrl(path);
      uploaded.push(data.publicUrl);
    }

    if (uploaded.length) {
      const next = Array.from(new Set([...all, ...uploaded]));
      onImagesChange(next);
      if (!mainImage) onMainImageChange(uploaded[0]);
      toast.success(`${uploaded.length} image(s) uploaded`);
    }
    setUploading(false);
    e.target.value = "";
  };

  const removeImage = (url: string) => {
    const next = all.filter((u) => u !== url);
    onImagesChange(next);
    if (url === mainImage) onMainImageChange(next[0] || "");
  };

  const setAsMain = (url: string) => {
    onMainImageChange(url);
    onImagesChange(Array.from(new Set([url, ...all])));
    toast.success("Main image updated");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-semibold text-foreground">Images ({all.length})</h4>
        <label>
          <input type="file" accept="image/*" multiple onChange={handleUpload} className="hidden" />
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="gap-2 rounded-xl h-10 px-4"
            disabled={uploading}
            onClick={(e) => {
              e.preventDefault();
              (e.currentTarget.previousElementSibling as HTMLInputElement)?.click();
            }}
          >
            <Upload className="h-4 w-4" />
            {uploading ? "Uploading..." : "Add Photos"}
          </Button>
        </label>
      </div>

      {all.length === 0 ? (
        <div className="border-2 border-dashed border-border rounded-xl p-8 text-center">
          <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">No images yet. Upload photos above.</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {all.map((url) => (
            <div key={url} className="relative group rounded-xl overflow-hidden aspect-square">
              <img src={optimizeImageUrl(url, 400)} alt="" className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/40 transition-colors flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 focus-within:opacity-100">
                <button
                  type="button"
                  onClick={() => setAsMain(url)}
                  className={`p-2 rounded-full transition-colors ${
                    url === mainImage
                      ? "bg-accent text-accent-foreground"
                      : "bg-card/90 text-foreground hover:bg-accent hover:text-accent-foreground"
                  }`}
                  title="Set as main image"
                >
                  <Star className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => removeImage(url)}
                  className="p-2 rounded-full bg-card/90 text-destructive hover:bg-destructive hover:text-destructive-foreground transition-colors"
                  title="Remove image"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              {url === mainImage && (
                <div className="absolute top-1.5 left-1.5 bg-accent text-accent-foreground text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Main
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      <p className="text-xs text-muted-foreground">Tap the star to set the cover image shown on the website.</p>
    </div>
  );
};

export default TourImageGallery;
