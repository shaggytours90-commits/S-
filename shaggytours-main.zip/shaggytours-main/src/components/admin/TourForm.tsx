import { useState } from "react";
import { ArrowLeft, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import TourImageGallery from "./TourImageGallery";
import { useCategories } from "@/hooks/useCategories";
import { CURRENCIES, currencySymbol } from "@/lib/currency";

export interface TourFormData {
  slug: string;
  title: string;
  destination: string;
  image_url: string;
  gallery_images: string[];
  price: number;
  child_price: number | null;
  currency: string;
  original_price: number | null;
  duration: string;
  departure_time: string;
  rating: number;
  reviews: number;
  short_description: string;
  description: string;
  highlights: string[];
  included: string[];
  not_included: string[];
  what_to_bring: string[];
  meeting_point: string;
  featured: boolean;
  category: string;
  best_season: string;
  active: boolean;
  sort_order: number;
  itinerary: any[];
}

interface TourFormProps {
  initialData: TourFormData;
  isEditing: boolean;
  isSaving: boolean;
  onSave: (data: TourFormData) => void;
  onCancel: () => void;
}

const inputClass =
  "w-full px-4 py-3.5 border border-border rounded-xl bg-background text-base text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30 transition-shadow";

const labelClass = "text-xs uppercase tracking-wider text-muted-foreground mb-2 block";

const TourForm = ({ initialData, isEditing, isSaving, onSave, onCancel }: TourFormProps) => {
  const [form, setForm] = useState<TourFormData>(initialData);
  const { data: categories = [] } = useCategories(false);

  const set = <K extends keyof TourFormData>(key: K, value: TourFormData[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const csvField = (key: keyof TourFormData, label: string, placeholder: string) => (
    <div>
      <Label className={labelClass}>{label}</Label>
      <input
        placeholder={placeholder}
        value={(form[key] as string[]).join(", ")}
        onChange={(e) =>
          set(key, e.target.value.split(",").map((s) => s.trim()).filter(Boolean) as any)
        }
        className={inputClass}
      />
    </div>
  );

  const handleSave = () => {
    if (!form.title || !form.slug) return;
    onSave(form);
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-3.5rem)]">
      <div className="flex items-center gap-3 pb-4 border-b border-border mb-5">
        <button onClick={onCancel} className="p-2 -ml-2 rounded-full hover:bg-muted transition-colors">
          <ArrowLeft className="h-5 w-5 text-foreground" />
        </button>
        <h2 className="text-lg font-semibold text-foreground">{isEditing ? "Edit Tour" : "New Tour"}</h2>
      </div>

      <div className="flex-1 space-y-6 pb-24 overflow-auto">
        <div>
          <Label className={labelClass}>Tour Name *</Label>
          <input
            placeholder="e.g. Dolphin House Samadai"
            value={form.title}
            onChange={(e) => set("title", e.target.value)}
            className={`${inputClass} text-lg font-semibold`}
          />
        </div>

        {/* Pricing */}
        <div className="space-y-3 p-4 bg-muted/50 rounded-xl">
          <div>
            <Label className={labelClass}>Currency</Label>
            <select value={form.currency} onChange={(e) => set("currency", e.target.value)} className={inputClass}>
              {CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>{c.label}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className={labelClass}>Adult Price ({currencySymbol(form.currency)}) *</Label>
              <input
                type="number"
                value={form.price}
                onChange={(e) => set("price", Number(e.target.value))}
                className={`${inputClass} text-xl font-bold`}
              />
            </div>
            <div>
              <Label className={labelClass}>Child Price</Label>
              <input
                type="number"
                placeholder="Optional"
                value={form.child_price ?? ""}
                onChange={(e) => set("child_price", e.target.value ? Number(e.target.value) : null)}
                className={inputClass}
              />
            </div>
          </div>
          <div>
            <Label className={labelClass}>Original Price (before discount)</Label>
            <input
              type="number"
              placeholder="Optional"
              value={form.original_price ?? ""}
              onChange={(e) => set("original_price", e.target.value ? Number(e.target.value) : null)}
              className={inputClass}
            />
          </div>
        </div>

        {/* Toggles */}
        <div className="flex flex-col gap-4 p-4 bg-muted/50 rounded-xl">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-foreground">Visible</p>
              <p className="text-xs text-muted-foreground">Show this tour on the website</p>
            </div>
            <Switch checked={form.active} onCheckedChange={(c) => set("active", c)} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-foreground">Featured / Popular</p>
              <p className="text-xs text-muted-foreground">Highlight on homepage</p>
            </div>
            <Switch checked={form.featured} onCheckedChange={(c) => set("featured", c)} />
          </div>
        </div>

        <TourImageGallery
          mainImage={form.image_url}
          images={form.gallery_images}
          onMainImageChange={(url) => set("image_url", url)}
          onImagesChange={(urls) => set("gallery_images", urls)}
        />

        <div>
          <Label className={labelClass}>Short Description</Label>
          <textarea
            placeholder="One-line summary shown on tour cards"
            rows={2}
            value={form.short_description}
            onChange={(e) => set("short_description", e.target.value)}
            className={`${inputClass} resize-none`}
          />
        </div>

        <div>
          <Label className={labelClass}>Full Description</Label>
          <textarea
            placeholder="Describe this tour..."
            rows={5}
            value={form.description}
            onChange={(e) => set("description", e.target.value)}
            className={`${inputClass} resize-none`}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className={labelClass}>Category</Label>
            <select value={form.category} onChange={(e) => set("category", e.target.value)} className={inputClass}>
              {categories.length === 0 && <option value={form.category}>{form.category || "—"}</option>}
              {categories.map((c) => (
                <option key={c.id} value={c.slug}>{c.name}</option>
              ))}
              {categories.length > 0 && form.category && !categories.some((c) => c.slug === form.category) && (
                <option value={form.category}>{form.category}</option>
              )}
            </select>
          </div>
          <div>
            <Label className={labelClass}>Duration</Label>
            <input
              placeholder="e.g. Full Day"
              value={form.duration}
              onChange={(e) => set("duration", e.target.value)}
              className={inputClass}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className={labelClass}>Departure Time</Label>
            <input
              placeholder="e.g. 06:00 AM"
              value={form.departure_time}
              onChange={(e) => set("departure_time", e.target.value)}
              className={inputClass}
            />
          </div>
          <div>
            <Label className={labelClass}>Best Season</Label>
            <input
              placeholder="e.g. Year-round"
              value={form.best_season}
              onChange={(e) => set("best_season", e.target.value)}
              className={inputClass}
            />
          </div>
        </div>

        <div>
          <Label className={labelClass}>Meeting / Pickup Information</Label>
          <textarea
            placeholder="e.g. Hotel pickup 30 min before departure"
            rows={2}
            value={form.meeting_point}
            onChange={(e) => set("meeting_point", e.target.value)}
            className={`${inputClass} resize-none`}
          />
        </div>

        <div>
          <Label className={labelClass}>URL Slug *</Label>
          <input
            placeholder="e.g. dolphin-house"
            value={form.slug}
            onChange={(e) => set("slug", e.target.value)}
            className={inputClass}
          />
        </div>

        <div>
          <Label className={labelClass}>Destination</Label>
          <input
            placeholder="e.g. Samadai Reef, Red Sea"
            value={form.destination}
            onChange={(e) => set("destination", e.target.value)}
            className={inputClass}
          />
        </div>

        <div>
          <Label className={labelClass}>Display Order</Label>
          <input
            type="number"
            value={form.sort_order}
            onChange={(e) => set("sort_order", Number(e.target.value))}
            className={inputClass}
          />
        </div>

        {csvField("highlights", "Highlights", "Comma separated: Dolphins, Snorkeling, Boat trip")}
        {csvField("included", "Included Services", "Comma separated: Transport, Lunch, Guide")}
        {csvField("not_included", "Not Included", "Comma separated: Tips, Personal expenses")}
        {csvField("what_to_bring", "What To Bring", "Comma separated: Towel, Sunscreen, Camera")}
      </div>

      <div className="sticky bottom-0 left-0 right-0 bg-background border-t border-border p-4 -mx-6 -mb-6 flex gap-3">
        <Button onClick={onCancel} variant="outline" className="flex-1 h-12 rounded-xl text-base">
          Cancel
        </Button>
        <Button
          onClick={handleSave}
          disabled={isSaving || !form.title || !form.slug}
          className="flex-1 h-12 rounded-xl text-base gap-2"
        >
          <Save className="h-5 w-5" />
          {isSaving ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </div>
  );
};

export default TourForm;
