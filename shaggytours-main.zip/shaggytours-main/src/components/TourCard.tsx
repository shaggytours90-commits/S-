import { Link } from "react-router-dom";
import { Star, Clock, MapPin, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { localizeTour, type DbTour } from "@/hooks/useTours";
import { useTranslation } from "react-i18next";
import { useCategories, categoryLabel } from "@/hooks/useCategories";
import { optimizeImageUrl } from "@/lib/imageUtils";

const TourCard = ({ tour: raw }: { tour: DbTour }) => {
  const { t, i18n } = useTranslation();
  const { data: cats = [] } = useCategories();
  const tour = localizeTour(raw, i18n.language);
  const catName = t(`categoryNames.${tour.category}`, { defaultValue: categoryLabel(cats.find((c) => c.slug === tour.category), i18n.language) || tour.category });
  const [liked, setLiked] = useState(false);
  const originalPrice = tour.original_price;

  return (
    <div className="group hover-lift card-shine">
      <div className="bg-card rounded-2xl overflow-hidden border border-border shadow-sm transition-shadow duration-300 hover:shadow-card-hover">
        <Link to={`/tour/${tour.slug}`}>
          <div className="relative aspect-[16/11] overflow-hidden">
            <img
              src={optimizeImageUrl(tour.image_url || "/placeholder.svg", 600)}
              alt={tour.title}
              width={600}
              height={413}
              sizes="(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 25vw"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            {originalPrice && (
              <span className="badge-deal">
                {Math.round(((originalPrice - tour.price) / originalPrice) * 100)}{t("tourCard.off")}
              </span>
            )}
            <div className="absolute top-3 right-3 flex gap-2">
              <span className="bg-card/90 backdrop-blur-sm text-foreground text-[11px] font-medium px-2.5 py-1 rounded-full">
                {catName}
              </span>
            </div>
          </div>
        </Link>
        <div className="p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="h-3.5 w-3.5 text-primary" />
              <span>{tour.destination}</span>
            </div>
            <button
              onClick={(e) => { e.preventDefault(); setLiked(!liked); }}
              className="p-1.5 rounded-full hover:bg-muted transition-colors"
            >
              <Heart className={`h-4 w-4 transition-colors ${liked ? "text-destructive fill-destructive" : "text-muted-foreground"}`} />
            </button>
          </div>
          <Link to={`/tour/${tour.slug}`}>
            <h3 className="font-serif text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors leading-snug">
              {tour.title}
            </h3>
          </Link>
          <div className="flex items-center gap-3 text-xs text-muted-foreground mb-4">
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {tour.duration}
            </span>
            <span className="flex items-center gap-1">
              <Star className="h-3.5 w-3.5 text-warm fill-warm" />
              {tour.rating}
            </span>
            <span className="text-muted-foreground">({t("tourDetail.reviews", { count: tour.reviews })})</span>
          </div>
          <div className="flex items-end justify-between pt-3 border-t border-border">
            <div>
              <span className="text-xs text-muted-foreground block">{t("common.from")}</span>
              {tour.price > 0 ? (
                <>
                  <div className="flex items-baseline gap-1.5">
                    {originalPrice && (
                      <span className="text-sm text-muted-foreground line-through">€{originalPrice}</span>
                    )}
                    <span className="text-2xl font-bold text-primary">€{tour.price}</span>
                  </div>
                  <span className="text-[11px] text-muted-foreground">{t("common.perPerson")}</span>
                </>
              ) : (
                <span className="text-sm font-semibold text-primary block">{t("catalog.priceOnRequest")}</span>
              )}
            </div>
            <Link to={`/tour/${tour.slug}`}>
              <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl px-5">
                {t("tourCard.viewDeal")}
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TourCard;
