import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { Check, X, Pencil } from "lucide-react";
import { toast } from "sonner";

interface InlineEditableProps {
  table: string;
  id: string;
  field: string;
  value: string;
  queryKey: string[];
  children: React.ReactNode;
  as?: "span" | "p" | "h1" | "h2" | "h3" | "div";
  className?: string;
  multiline?: boolean;
}

const InlineEditable = ({
  table,
  id,
  field,
  value,
  queryKey,
  children,
  as: Tag = "span",
  className = "",
  multiline = false,
}: InlineEditableProps) => {
  const { isAdmin } = useAuth();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const [saving, setSaving] = useState(false);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  useEffect(() => {
    setDraft(value);
  }, [value]);

  if (!isAdmin) return <>{children}</>;

  const save = async () => {
    if (draft === value) {
      setEditing(false);
      return;
    }
    setSaving(true);
    const { error } = await supabase
      .from(table as any)
      .update({ [field]: draft } as any)
      .eq("id", id as any);
    setSaving(false);
    if (error) {
      toast.error("Failed to save");
      return;
    }
    toast.success("Updated!");
    queryClient.invalidateQueries({ queryKey });
    setEditing(false);
  };

  const cancel = () => {
    setDraft(value);
    setEditing(false);
  };

  if (editing) {
    return (
      <div className="inline-flex items-center gap-1.5 relative">
        {multiline ? (
          <textarea
            ref={inputRef as any}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Escape") cancel();
            }}
            rows={3}
            className="px-2 py-1 border-2 border-primary rounded-lg bg-background text-foreground text-sm outline-none min-w-[200px] resize-y"
          />
        ) : (
          <input
            ref={inputRef as any}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") save();
              if (e.key === "Escape") cancel();
            }}
            className="px-2 py-1 border-2 border-primary rounded-lg bg-background text-foreground text-sm outline-none min-w-[120px]"
          />
        )}
        <button onClick={save} disabled={saving} className="p-1 rounded bg-primary text-primary-foreground hover:bg-primary/90">
          <Check className="h-3.5 w-3.5" />
        </button>
        <button onClick={cancel} className="p-1 rounded bg-muted text-muted-foreground hover:bg-muted/80">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    );
  }

  return (
    <Tag
      className={`${className} group/editable relative cursor-pointer inline`}
      onClick={() => setEditing(true)}
      title="Click to edit"
    >
      {children}
      <Pencil className="h-3 w-3 text-primary opacity-0 group-hover/editable:opacity-100 transition-opacity inline-block ml-1 align-middle" />
    </Tag>
  );
};

export default InlineEditable;
