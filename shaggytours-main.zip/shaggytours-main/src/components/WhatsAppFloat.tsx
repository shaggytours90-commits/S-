import { MessageCircle } from "lucide-react";
import { useSiteSettings } from "@/hooks/useSiteSettings";

const WhatsAppFloat = () => {
  const { data: settings } = useSiteSettings();
  const whatsapp = settings?.whatsapp_number || "201505191565";
  const siteName = settings?.site_name || "SHAGGY TOURS";
  const message = encodeURIComponent(`Hello ${siteName},\nI want to book a tour.\n\nPlease confirm availability.`);
  
  return (
    <a
      href={`https://wa.me/${whatsapp}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-[hsl(142,70%,45%)] text-primary-foreground flex items-center justify-center shadow-lg hover:bg-[hsl(142,70%,40%)] hover:scale-110 transition-all duration-200"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="h-7 w-7" />
    </a>
  );
};

export default WhatsAppFloat;
