import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import { Star, Quote } from "lucide-react";
import { useTestimonials } from "@/hooks/useTestimonials";
import { useState } from "react";
import InlineEditable from "@/components/InlineEditable";

const TestimonialsSection = () => {
  const { data: testimonials = [] } = useTestimonials();
  const [active, setActive] = useState(0);
  const { t: tt } = useTranslation();



  const idx = Math.min(active, testimonials.length - 1);
  const cur = testimonials[idx];

  if (testimonials.length === 0) return null;

  return (
    <section className="section-padding bg-secondary/50">
      <div className="container-wide mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="section-label">{tt("sections.testimonials.label")}</span>
          <h2 className="section-title">{tt("sections.testimonials.title")}</h2>

        </motion.div>

        {/* Desktop grid */}
        <div className="hidden md:grid grid-cols-3 gap-6">
          {testimonials.slice(0, 6).map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-card rounded-2xl p-7 border border-border hover:shadow-lg transition-shadow relative"
            >
              <Quote className="h-8 w-8 text-primary/10 absolute top-6 right-6" />
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="h-4 w-4 text-warm fill-warm" />
                ))}
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed mb-5">
                <InlineEditable table="testimonials" id={t.id} field="text" value={t.text} queryKey={["testimonials"]} as="span" multiline>
                  "{t.text}"
                </InlineEditable>
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-border">
                <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold">
                  {t.avatar}
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">{t.name}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {[t.country, t.location, t.tour].filter(Boolean).join(" · ")}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Mobile carousel */}
        <div className="md:hidden">
          {testimonials.length > 0 && (
            <>
              <div className="bg-card rounded-2xl p-7 border border-border">
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: cur?.rating || 5 }).map((_, j) => (
                    <Star key={j} className="h-4 w-4 text-warm fill-warm" />
                  ))}
                </div>
                <p className="text-muted-foreground text-sm leading-relaxed mb-5">"{cur?.text}"</p>
                <div className="flex items-center gap-3 pt-4 border-t border-border">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold">
                    {cur?.avatar}
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-sm">{cur?.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {[cur?.country, cur?.location].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex justify-center gap-2 mt-4">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActive(i)}
                    className={`w-2.5 h-2.5 rounded-full transition-colors ${i === idx ? "bg-primary" : "bg-border"}`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
