import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { destinations } from "@/data/tours";
import { ArrowRight } from "lucide-react";

const DestinationsSection = () => {
  const { t } = useTranslation();
  return (
    <section id="destinations" className="section-padding bg-background">
      <div className="container-wide mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10"
        >
          <div>
            <span className="section-label">{t("sections.destinations.label")}</span>
            <h2 className="section-title">{t("sections.destinations.title")}</h2>
          </div>
          <Link to="/tours" className="flex items-center gap-1.5 text-primary font-medium text-sm hover:gap-3 transition-all">
            {t("sections.destinations.viewAll")} <ArrowRight className="h-4 w-4 rtl:rotate-180" />
          </Link>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {destinations.map((dest, i) => (
            <motion.div
              key={dest.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <Link to={`/tours?search=${encodeURIComponent(dest.name.split(",")[0].split("&")[0].trim())}`} className="group block">
                <div className="relative rounded-2xl overflow-hidden aspect-[3/4] hover-lift">
                  <img
                    src={dest.image}
                    alt={dest.name}
                    width={400}
                    height={533}
                    sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/10 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4 md:p-5">
                    <h3 className="font-serif text-lg md:text-xl font-bold text-primary-foreground leading-snug">{dest.name}</h3>
                    <p className="text-primary-foreground/70 text-xs mt-1">
                      {t(dest.tours === 1 ? "sections.destinations.tourOne" : "sections.destinations.tourOther", { count: dest.tours })}
                    </p>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DestinationsSection;
