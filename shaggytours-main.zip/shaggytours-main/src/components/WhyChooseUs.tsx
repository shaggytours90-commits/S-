import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import { Shield, Users, MapPin, Star, Clock, MessageCircle } from "lucide-react";

const iconMap = { local: MapPin, groups: Users, safety: Shield, prices: Star, cancel: Clock, support: MessageCircle };
const keys = ["local", "groups", "safety", "prices", "cancel", "support"] as const;

const WhyChooseUs = () => {
  const { t } = useTranslation();
  return (
    <section className="section-padding bg-background">
      <div className="container-wide mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="section-label">{t("sections.why.label")}</span>
          <h2 className="section-title">{t("sections.why.title")}</h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {keys.map((key, i) => {
            const Icon = iconMap[key];
            return (
              <motion.div
                key={key}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="bg-card rounded-2xl p-7 border border-border hover:shadow-lg transition-shadow text-center"
              >
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-serif text-lg font-bold text-foreground mb-2">{t(`sections.why.items.${key}.title`)}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{t(`sections.why.items.${key}.desc`)}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
