import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Search, MapPin, Calendar, Users, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarPicker } from "@/components/ui/calendar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { tours } from "@/data/tours";
import { useTranslation } from "react-i18next";

const allDestinations = [...new Set(tours.map((t) => t.destination))];

const TravelSearchBox = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [destination, setDestination] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [travelDate, setTravelDate] = useState<Date | undefined>();
  const [travelers, setTravelers] = useState(2);
  const [showTravelers, setShowTravelers] = useState(false);
  const destRef = useRef<HTMLDivElement>(null);
  const travelersRef = useRef<HTMLDivElement>(null);

  const filteredDest = destination
    ? allDestinations.filter((d) => d.toLowerCase().includes(destination.toLowerCase()))
    : allDestinations;

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (destRef.current && !destRef.current.contains(e.target as Node)) setShowSuggestions(false);
      if (travelersRef.current && !travelersRef.current.contains(e.target as Node)) setShowTravelers(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (destination) params.set("search", destination);
    navigate(`/tours?${params.toString()}`);
  };

  return (
    <div className="glass-card p-3 md:p-4 shadow-search w-full max-w-4xl">
      <div className="grid grid-cols-1 md:grid-cols-10 gap-0 md:divide-x md:divide-border">
        {/* Destination */}
        <div className="md:col-span-3 relative" ref={destRef}>
          <div className="search-field" onClick={() => setShowSuggestions(true)}>
            <MapPin className="h-5 w-5 text-primary shrink-0" />
            <div className="flex-1 min-w-0">
              <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider block">{t("search.destination")}</label>
              <input
                type="text"
                placeholder={t("search.whereTo")}
                value={destination}
                onChange={(e) => { setDestination(e.target.value); setShowSuggestions(true); }}
                onFocus={() => setShowSuggestions(true)}
                className="search-input text-sm font-medium"
              />
            </div>
          </div>
          <AnimatePresence>
            {showSuggestions && filteredDest.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto"
              >
                {filteredDest.map((d) => (
                  <button
                    key={d}
                    onClick={() => { setDestination(d); setShowSuggestions(false); }}
                    className="w-full text-left px-4 py-3 text-sm hover:bg-muted/60 transition-colors flex items-center gap-3 text-foreground"
                  >
                    <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
                    {d}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Date */}
        <div className="md:col-span-3">
          <Popover>
            <PopoverTrigger asChild>
              <div className="search-field">
                <Calendar className="h-5 w-5 text-primary shrink-0" />
                <div className="flex-1 min-w-0">
                  <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider block">{t("search.date")}</label>
                  <span className={cn("text-sm font-medium block truncate", !travelDate && "text-muted-foreground")}>
                    {travelDate ? format(travelDate, "MMM d, yyyy") : t("search.selectDate")}
                  </span>
                </div>
              </div>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarPicker
                mode="single"
                selected={travelDate}
                onSelect={setTravelDate}
                disabled={(date) => date < new Date()}
                initialFocus
                className={cn("p-3 pointer-events-auto")}
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Travelers */}
        <div className="md:col-span-3 relative" ref={travelersRef}>
          <div className="search-field" onClick={() => setShowTravelers(!showTravelers)}>
            <Users className="h-5 w-5 text-primary shrink-0" />
            <div className="flex-1 min-w-0">
              <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider block">{t("search.travelers")}</label>
              <span className="text-sm font-medium text-foreground">{t(travelers === 1 ? "search.guestOne" : "search.guestOther", { count: travelers })}</span>
            </div>
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          </div>
          <AnimatePresence>
            {showTravelers && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-xl shadow-lg z-50 p-4"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{t("search.guests")}</span>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setTravelers(Math.max(1, travelers - 1))}
                      className="w-8 h-8 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-muted transition-colors"
                    >−</button>
                    <span className="text-sm font-bold text-foreground w-4 text-center">{travelers}</span>
                    <button
                      onClick={() => setTravelers(Math.min(20, travelers + 1))}
                      className="w-8 h-8 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-muted transition-colors"
                    >+</button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Search Button */}
        <div className="md:col-span-1 flex items-stretch p-2">
          <Button
            onClick={handleSearch}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl h-full min-h-[48px] gap-2 text-base font-semibold"
          >
            <Search className="h-5 w-5" />
            <span className="md:hidden">{t("search.button")}</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TravelSearchBox;
