import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, MapPin, Phone } from "lucide-react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import LanguageSwitcher from "./LanguageSwitcher";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === "/";
  const { data: settings } = useSiteSettings();
  const { t } = useTranslation();

  const navLinks = [
    { label: t("nav.home"), path: "/" },
    { label: t("nav.tours"), path: "/tours" },
    { label: t("nav.gallery"), path: "/gallery" },
    { label: t("nav.about"), path: "/about" },
    { label: t("nav.contact"), path: "/contact" },
  ];

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const navBg = scrolled || !isHome
    ? "bg-background/95 backdrop-blur-xl border-b border-border shadow-sm"
    : "bg-transparent";

  const textColor = scrolled || !isHome ? "text-foreground" : "text-primary-foreground";
  const mutedColor = scrolled || !isHome ? "text-muted-foreground" : "text-primary-foreground/70";

  return (
    <nav className={cn("fixed top-0 left-0 right-0 z-50 transition-all duration-300", navBg)}>
      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link to="/" className="flex items-center gap-2">
            <MapPin className="h-6 w-6 text-accent" />
            <span className={cn("font-serif text-xl md:text-2xl font-bold transition-colors", textColor)}>
              {settings?.site_name || "SHAGGY TOURS"}
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "text-sm font-medium transition-colors relative",
                  location.pathname === link.path
                    ? cn(textColor, "after:absolute after:bottom-[-4px] after:left-0 after:right-0 after:h-0.5 after:bg-accent after:rounded-full")
                    : cn(mutedColor, "hover:opacity-100")
                )}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-2">
            <a href={`https://wa.me/${settings?.whatsapp_number || "201505191565"}`} target="_blank" rel="noopener noreferrer" className={cn("flex items-center gap-1.5 text-sm transition-colors mr-2", mutedColor)}>
              <Phone className="h-4 w-4" />
              <span className="hidden lg:inline">{settings?.phone_display || "+20 150 519 1565"}</span>
            </a>
            <LanguageSwitcher className={textColor} />
            <Link to="/tours">
              <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl">
                {t("nav.bookNow")}
              </Button>
            </Link>
          </div>

          <div className="md:hidden flex items-center gap-1">
            <LanguageSwitcher className={textColor} />
            <button
              className={cn("p-2 transition-colors", textColor)}
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-background border-b border-border"
          >
            <div className="px-4 py-4 space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    "block py-3 px-3 rounded-lg text-base font-medium transition-colors",
                    location.pathname === link.path
                      ? "text-primary bg-primary/5"
                      : "text-muted-foreground hover:bg-muted"
                  )}
                >
                  {link.label}
                </Link>
              ))}
              <Link to="/tours" onClick={() => setIsOpen(false)} className="block pt-2">
                <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl">
                  {t("nav.bookNow")}
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
