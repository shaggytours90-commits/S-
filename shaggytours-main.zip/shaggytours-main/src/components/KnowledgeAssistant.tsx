import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Bot, Send, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

interface Msg {
  role: "user" | "assistant";
  content: string;
}

const KnowledgeAssistant = ({ tourSlug }: { tourSlug?: string }) => {
  const { i18n } = useTranslation();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const ask = async (e: React.FormEvent) => {
    e.preventDefault();
    const question = input.trim();
    if (!question || loading) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", content: question }]);
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("kb-assistant", {
        body: {
          question,
          language: (i18n.language || "en").split("-")[0],
          tour_slug: tourSlug ?? null,
        },
      });
      const answer = error
        ? "Information not available."
        : (data?.answer as string) || "Information not available.";
      setMessages((m) => [...m, { role: "assistant", content: answer }]);
    } catch {
      setMessages((m) => [...m, { role: "assistant", content: "Information not available." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5">
      <h3 className="font-serif text-lg font-bold text-foreground mb-1 flex items-center gap-2">
        <Bot className="h-5 w-5 text-primary" /> Ask about this tour
      </h3>
      <p className="text-xs text-muted-foreground mb-4">
        Answers come only from our official tour document.
      </p>

      {messages.length > 0 && (
        <div className="space-y-3 mb-4 max-h-72 overflow-y-auto">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`text-sm rounded-xl px-3 py-2 ${
                m.role === "user"
                  ? "bg-primary/10 text-foreground ms-8"
                  : "bg-muted text-muted-foreground me-8"
              }`}
            >
              {m.content}
            </div>
          ))}
        </div>
      )}

      <form onSubmit={ask} className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="e.g. What is included?"
          className="flex-1 px-3 py-2 border border-border rounded-xl bg-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30"
        />
        <Button type="submit" size="icon" className="rounded-xl shrink-0" disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </form>
    </div>
  );
};

export default KnowledgeAssistant;
