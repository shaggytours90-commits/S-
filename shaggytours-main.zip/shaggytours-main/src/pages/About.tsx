import { motion } from "framer-motion";
import { Award, Users, Globe, Heart, Shield, Star, MapPin, Headphones } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import NewsletterSection from "@/components/NewsletterSection";
import heroImage from "@/assets/hero-marsa-alam.jpg";
import { useSiteSettings } from "@/hooks/useSiteSettings";

const stats = [
  { icon: Globe, num: "10+", label: "Excursions" },
  { icon: Users, num: "5,000+", label: "Happy Travelers" },
  { icon: Award, num: "9+", label: "Years Experience" },
  { icon: Heart, num: "98%", label: "Satisfaction Rate" },
];

const values = [
  { icon: Shield, title: "Safety First", desc: "Licensed guides, insured vehicles, and well-maintained equipment on every tour." },
  { icon: Star, title: "Small Groups", desc: "We keep groups small to ensure personalized attention and the best experience." },
  { icon: MapPin, title: "Local Experts", desc: "Our team are locals who know every hidden gem in Marsa Alam and the Red Sea." },
  { icon: Headphones, title: "24/7 Support", desc: "Available on WhatsApp around the clock to answer questions and help with bookings." },
];

const About = () => {
  const { data: settings } = useSiteSettings();
  const siteName = settings?.site_name || "SHAGGY TOURS";

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-8 bg-primary">
        <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary-foreground mb-2">About {siteName}</h1>
          <p className="text-primary-foreground/80">Your trusted tour operator in Marsa Alam since 2015</p>
        </div>
      </div>

      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-3xl font-serif font-bold text-foreground mb-6">Our Story</h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                {siteName} was founded in Marsa Alam with a simple mission: to share the incredible beauty of the Red Sea and Egyptian heritage with travelers from around the world.
              </p>
              <p>
                As locals who grew up on these shores, we know every reef, every beach, and every hidden gem. We believe the best travel experiences come from genuine local knowledge, small group sizes, and a personal touch that big tour companies can't offer.
              </p>
              <p>
                From swimming with wild dolphins at Samadai Reef to exploring the ancient temples of Luxor and Abu Simbel, our expert guides ensure every trip is safe, fun, and unforgettable. We're proud to serve thousands of happy travelers each year from Italy, Germany, Poland, Czech Republic, Russia, and beyond.
              </p>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <img src={heroImage} alt={`${siteName} team in Marsa Alam`} className="rounded-2xl shadow-xl w-full" loading="lazy" />
          </motion.div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
          {stats.map(({ icon: Icon, num, label }, i) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-card border border-border rounded-xl p-6 text-center"
            >
              <Icon className="h-8 w-8 text-accent mx-auto mb-3" />
              <p className="text-2xl font-bold text-foreground">{num}</p>
              <p className="text-sm text-muted-foreground">{label}</p>
            </motion.div>
          ))}
        </div>

        <div className="mb-20">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-8 text-center">Why Choose {siteName}?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map(({ icon: Icon, title, desc }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card border border-border rounded-xl p-6 text-center"
              >
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-serif font-bold text-foreground mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground">{desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="bg-secondary rounded-2xl p-8 md:p-12 text-center max-w-3xl mx-auto"
        >
          <h2 className="text-3xl font-serif font-bold text-foreground mb-4">Our Mission</h2>
          <p className="text-muted-foreground leading-relaxed text-lg">
            "To provide safe, authentic, and unforgettable travel experiences in the Red Sea region, connecting travelers with Egypt's natural beauty and ancient heritage through personalized small-group tours."
          </p>
        </motion.div>
      </div>

      <NewsletterSection />
      <Footer />
    </div>
  );
};

export default About;
