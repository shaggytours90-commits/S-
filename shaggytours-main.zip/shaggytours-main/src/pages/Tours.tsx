import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, SlidersHorizontal, X } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import TourCard from "@/components/TourCard";
import { useCategories, categoryLabel } from "@/hooks/useCategories";
import { useTranslation } from "react-i18next";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { MessageCircle } from "lucide-react";
import { isRequestPrice, regionMatches } from "@/data/catalog";
import { useTours, localizeTour } from "@/hooks/useTours";
import { Button } from "@/components/ui/button";

const priceRanges = [
  { label: "any", min: 0, max: Infinity },
  { label: "under30", min: 0.01, max: 30 },
  { label: "r30_50", min: 30, max: 50 },
  { label: "r50_100", min: 50, max: 100 },
  { label: "over100", min: 100, max: Infinity },
];
const sortOptions = [
  { label: "recommended", value: "recommended" },
  { label: "priceAsc", value: "price-asc" },
  { label: "priceDesc", value: "price-desc" },
  { label: "rating", value: "rating" },
];

const Tours = () => {
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [region, setRegion] = useState(searchParams.get("region") || "all");
  const [category, setCategory] = useState("all");
  const [priceRange, setPriceRange] = useState(Number(searchParams.get("budget")) || 0);
  const [sortBy, setSortBy] = useState("recommended");
  const [showFilters, setShowFilters] = useState(false);
  const { data: tours = [] } = useTours();
  const { t, i18n } = useTranslation();
  const { data: dbCats = [] } = useCategories();
  const { data: settings } = useSiteSettings();
  const wa = settings?.whatsapp_number || "201505191565";
  const categories = [{ id: "all", label: t("catalog.allTours") }, ...dbCats.map((c) => ({ id: c.slug, label: t(`categoryNames.${c.slug}`, { defaultValue: categoryLabel(c, i18n.language) }) }))];
  const dayShort = (d: string) => new Date(2026, 0, 4 + ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"].indexOf(d)).toLocaleDateString(i18n.language, { weekday: "short" });
  const daysText = (days?: string[]) => !days?.length ? "—" : days.length === 7 ? t("catalog.everyDay") : days.map(dayShort).join(", ");

  const filtered = useMemo(() => {
    let result = tours.map((tour) => localizeTour(tour, i18n.language)).filter((t) => {
      const matchesSearch = !search || t.title.toLowerCase().includes(search.toLowerCase()) || t.destination.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === "all" || t.category === category;
      const range = priceRanges[priceRange];
      const matchesPrice = priceRange === 0 || (t.price >= range.min && t.price <= range.max);
      return matchesSearch && matchesCategory && matchesPrice && regionMatches(t.region, region);
    });

    switch (sortBy) {
      case "price-asc": result.sort((a, b) => (isRequestPrice(a.price) ? Infinity : a.price) - (isRequestPrice(b.price) ? Infinity : b.price)); break;
      case "price-desc": result.sort((a, b) => (isRequestPrice(b.price) ? -Infinity : b.price) - (isRequestPrice(a.price) ? -Infinity : a.price)); break;
      case "rating": result.sort((a, b) => b.rating - a.rating); break;
    }
    return result;
  }, [search, category, region, priceRange, sortBy, tours, i18n.language]);

  const activeFilters = [
    category !== "all" && categories.find((c) => c.id === category)?.label,
    priceRange > 0 && t(`toursPage.priceRanges.${priceRanges[priceRange].label}`),
  ].filter(Boolean);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20 md:pt-24 pb-6 bg-primary">
        <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary-foreground mb-2">{t("toursPage.title")}</h1>
          <p className="text-primary-foreground/70 text-sm">{t("toursPage.subtitle", { count: tours.length })}</p>
        </div>
      </div>

      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-wrap items-center gap-2 mb-5" role="group" aria-label={t("regions.label")}>
          {["all", "hurghada", "marsa-alam"].map((value) => <Button key={value} variant={region === value ? "default" : "outline"} onClick={() => setRegion(value)} aria-pressed={region === value}>{t(`regions.${value}`)}</Button>)}
        </div>
        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <div className="flex-1 flex items-center gap-3 bg-card border border-border rounded-xl px-4 py-3 focus-within:ring-2 focus-within:ring-primary/30 transition-shadow">
            <Search className="h-5 w-5 text-muted-foreground" />
            <input
              type="text"
              placeholder={t("toursPage.searchPlaceholder")}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-transparent text-sm outline-none w-full text-foreground placeholder:text-muted-foreground"
            />
            {search && (
              <Button onClick={() => setSearch("")} className="text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className={`gap-2 rounded-xl border-border ${showFilters ? "bg-primary text-primary-foreground border-primary" : ""}`}
            >
              <SlidersHorizontal className="h-4 w-4" />
              {t("toursPage.filters")}
              {activeFilters.length > 0 && (
                <span className="w-5 h-5 rounded-full bg-accent text-accent-foreground text-[10px] font-bold flex items-center justify-center">
                  {activeFilters.length}
                </span>
              )}
            </Button>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-card border border-border rounded-xl px-3 py-2 text-sm text-foreground outline-none"
            >
              {sortOptions.map((o) => (
                <option key={o.value} value={o.value}>{t(`toursPage.sort.${o.label}`)}</option>
              ))}
            </select>
          </div>
        </div>

        {activeFilters.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {activeFilters.map((f) => (
              <span key={f as string} className="flex items-center gap-1.5 bg-primary/10 text-primary text-xs font-medium px-3 py-1.5 rounded-full">
                {f as string}
                <Button onClick={() => {
                  if (f === categories.find((c) => c.id === category)?.label) setCategory("all");
                  if (f === priceRanges[priceRange].label) setPriceRange(0);
                }}><X className="h-3 w-3" /></Button>
              </span>
            ))}
            <Button
              onClick={() => { setCategory("all"); setPriceRange(0); }}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              {t("toursPage.clearAll")}
            </Button>
          </div>
        )}

        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-card border border-border rounded-2xl p-6 mb-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-xs font-semibold text-foreground mb-3 block uppercase tracking-wider">{t("toursPage.category")}</label>
                <div className="flex flex-wrap gap-2">
                  {categories.map((c) => (
                    <Button
                      key={c.id}
                      onClick={() => setCategory(c.id)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                        category === c.id ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground hover:bg-muted"
                      }`}
                    >{c.label}</Button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-foreground mb-3 block uppercase tracking-wider">{t("toursPage.budget")}</label>
                <select
                  value={priceRange}
                  onChange={(e) => setPriceRange(Number(e.target.value))}
                  className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground outline-none"
                >
                  {priceRanges.map((p, i) => (
                    <option key={i} value={i}>{t(`toursPage.priceRanges.${p.label}`)}</option>
                  ))}
                </select>
              </div>
            </div>
          </motion.div>
        )}

        <p className="text-sm text-muted-foreground mb-6">{t("toursPage.found", { count: filtered.length })}</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filtered.map((tour, i) => (
            <motion.div
              key={tour.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
            >
              <TourCard tour={tour} />
            </motion.div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20">
            <p className="text-2xl font-serif text-foreground mb-2">{t("toursPage.empty")}</p>
            <p className="text-muted-foreground mb-4">{t("toursPage.emptyHint")}</p>
            <Button onClick={() => { setSearch(""); setCategory("all"); setPriceRange(0); setRegion("all"); }} variant="outline" className="rounded-xl">
              {t("toursPage.clearAll")} filters
            </Button>
          </div>
        )}

        <section className="mt-14">
          <h2 className="text-2xl font-serif font-bold text-foreground mb-4">{t("catalog.priceList")}</h2>
          <div className="overflow-x-auto bg-card border border-border rounded-2xl">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-foreground">
                <tr>{["colTour","colRegion","colDays","colAdult","colChild610","colChild05"].map((k) => <th key={k} className="text-start px-4 py-3 font-semibold">{t(`catalog.${k}`)}</th>)}</tr>
              </thead>
              <tbody>
                {filtered.map((tr) => (
                  <tr key={tr.id} className="border-t border-border">
                    <td className="px-4 py-3 text-foreground">{(tr.translations?.[i18n.language.slice(0,2)]?.title) || tr.title}</td>
                    <td className="px-4 py-3">{t(`regions.${tr.region}`)}</td>
                    <td className="px-4 py-3 text-muted-foreground">{daysText(tr.available_days)}</td>
                    <td className="px-4 py-3 font-semibold text-primary">{tr.price > 0 ? `€${tr.price}` : t("catalog.onRequest")}</td>
                    <td className="px-4 py-3">{tr.child_price != null ? `€${tr.child_price}` : t("catalog.na")}</td>
                    <td className="px-4 py-3">{t("catalog.free")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mt-10 bg-card border border-border rounded-2xl p-6">
          <h2 className="text-xl font-serif font-bold text-foreground mb-3">{t("catalog.importantInfo")}</h2>
          <ul className="space-y-2 text-sm text-muted-foreground list-disc ps-5">
            {["child","pricing","cancel","documents"].map((k) => <li key={k}>{t(`catalog.${k}`)}</li>)}
          </ul>
        </section>

        <section className="mt-10 bg-primary text-primary-foreground rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-serif font-bold mb-1">{t("catalog.otherTitle")}</h2>
            <p className="text-primary-foreground/80 text-sm">{t("catalog.otherText")}</p>
            <p className="text-primary-foreground/80 text-sm mt-1">{t("catalog.ebook")}</p>
          </div>
          <a href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl gap-2"><MessageCircle className="h-4 w-4" /> {t("catalog.otherCta")}</Button>
          </a>
        </section>
      </div>
      <Footer />
    </div>
  );
};

export default Tours;
