import { useState } from "react";
import { motion } from "framer-motion";
import { MapPin, Phone, Mail, MessageCircle, Send, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSiteSettings } from "@/hooks/useSiteSettings";

const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const { data: settings } = useSiteSettings();
  const siteName = settings?.site_name || "SHAGGY TOURS";
  const whatsapp = settings?.whatsapp_number || "201505191565";
  const phone = settings?.phone_display || "+20 150 519 1565";
  const email = settings?.site_email || "info@shaggytours.com";
  const address = settings?.address || "Marsa Alam, Red Sea, Egypt";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await supabase.from("contact_messages").insert({
      name: form.name,
      email: form.email,
      phone: form.phone || null,
      message: form.message,
    });
    const msg = encodeURIComponent(
      `Hello ${siteName},\n\nName: ${form.name}\nEmail: ${form.email}\nPhone: ${form.phone}\n\nMessage: ${form.message}\n\nPlease reply. Thank you!`
    );
    window.open(`https://wa.me/${whatsapp}?text=${msg}`, "_blank");
    toast.success("Opening WhatsApp to send your message!");
    setForm({ name: "", email: "", phone: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-8 bg-primary">
        <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary-foreground mb-2">Contact Us</h1>
          <p className="text-primary-foreground/80">Get in touch for bookings, questions, or custom tours</p>
        </div>
      </div>

      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
            <h2 className="text-2xl font-serif font-bold text-foreground mb-6">Send Us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="px-4 py-3 border border-border rounded-lg bg-card text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary"
                />
                <input
                  type="email"
                  placeholder="Email Address"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="px-4 py-3 border border-border rounded-lg bg-card text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <input
                type="tel"
                placeholder="WhatsApp Number"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-lg bg-card text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary"
              />
              <textarea
                placeholder="Your Message"
                rows={5}
                required
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-lg bg-card text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary resize-none"
              />
              <Button type="submit" className="bg-accent text-accent-foreground hover:bg-accent/90 gap-2 h-12 px-8">
                <Send className="h-4 w-4" /> Send via WhatsApp
              </Button>
            </form>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
            <div>
              <h2 className="text-2xl font-serif font-bold text-foreground mb-6">Get in Touch</h2>
              <div className="space-y-4">
                {[
                  { icon: MapPin, label: "Location", value: address },
                  { icon: Phone, label: "WhatsApp", value: phone },
                  { icon: Mail, label: "Email", value: email },
                  { icon: Clock, label: "Available", value: "Every day: 8:00 AM - 10:00 PM" },
                ].map(({ icon: Icon, label, value }) => (
                  <div key={label} className="flex items-start gap-4 p-4 bg-card border border-border rounded-xl">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground text-sm">{label}</p>
                      <p className="text-muted-foreground text-sm">{value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <a
              href={`https://wa.me/${whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 bg-[hsl(142,70%,45%)] text-primary-foreground rounded-xl p-4 hover:bg-[hsl(142,70%,40%)] transition-colors"
            >
              <MessageCircle className="h-6 w-6" />
              <div>
                <p className="font-semibold">Chat on WhatsApp</p>
                <p className="text-sm opacity-90">Quick response within minutes</p>
              </div>
            </a>

            <div className="rounded-xl overflow-hidden border border-border h-64">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114796.51932376!2d34.84!3d25.07!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14330e3c7873e2b5%3A0x1c6e8c5b963c3c24!2sMarsa%20Alam%2C%20Red%20Sea%20Governorate%2C%20Egypt!5e0!3m2!1sen!2seg!4v1700000000000!5m2!1sen!2seg"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title={`${siteName} - Marsa Alam location`}
              />
            </div>
          </motion.div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Contact;
