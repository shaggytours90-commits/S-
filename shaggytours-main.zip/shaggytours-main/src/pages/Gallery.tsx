import { motion } from "framer-motion";
import { useState, useMemo } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { X } from "lucide-react";
import { useGalleryImages } from "@/hooks/useGalleryImages";
import { optimizeImageUrl } from "@/lib/imageUtils";

const Gallery = () => {
  const { data: galleryImages = [] } = useGalleryImages();
  const [selected, setSelected] = useState<number | null>(null);
  const [filter, setFilter] = useState("All");

  const categories = useMemo(() => {
    const cats = new Set(galleryImages.map((img) => img.category));
    return ["All", ...Array.from(cats)];
  }, [galleryImages]);

  const filtered = filter === "All" ? galleryImages : galleryImages.filter((img) => img.category === filter);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20 md:pt-24 pb-6 bg-primary">
        <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-serif font-bold text-primary-foreground mb-2">Photo Gallery</h1>
          <p className="text-primary-foreground/70 text-sm">Stunning moments from our tours in Marsa Alam & Red Sea</p>
        </div>
      </div>

      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                filter === cat
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-muted"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
          {filtered.map((img, i) => (
            <motion.div
              key={img.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: i * 0.05 }}
              className="break-inside-avoid cursor-pointer group"
              onClick={() => setSelected(galleryImages.indexOf(img))}
            >
              <div className="relative overflow-hidden rounded-2xl">
                <img
                  src={optimizeImageUrl(img.image_url, 600)}
                  alt={img.title}
                  className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/30 transition-colors flex items-end">
                  <div className="p-5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <p className="text-primary-foreground font-serif font-bold text-lg">{img.title}</p>
                    <p className="text-primary-foreground/80 text-sm">{img.category}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filtered.length === 0 && (
          <p className="text-center text-muted-foreground py-12">No images in this category yet.</p>
        )}
      </div>

      {selected !== null && galleryImages[selected] && (
        <div className="fixed inset-0 z-50 bg-foreground/90 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <button className="absolute top-6 right-6 text-primary-foreground hover:text-accent transition-colors" onClick={() => setSelected(null)}>
            <X className="h-8 w-8" />
          </button>
          <img
            src={galleryImages[selected].image_url}
            alt={galleryImages[selected].title}
            className="max-w-full max-h-[85vh] object-contain rounded-2xl"
          />
        </div>
      )}

      <Footer />
    </div>
  );
};

export default Gallery;
