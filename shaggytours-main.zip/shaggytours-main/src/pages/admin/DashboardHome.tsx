import { useEffect, useState } from "react";
import { CalendarCheck, MessageSquare, Map, TrendingUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const DashboardHome = () => {
  const [stats, setStats] = useState({ bookings: 0, messages: 0, unread: 0, pending: 0 });

  useEffect(() => {
    const fetchStats = async () => {
      const [bookingsRes, messagesRes, unreadRes, pendingRes] = await Promise.all([
        supabase.from("bookings").select("id", { count: "exact", head: true }),
        supabase.from("contact_messages").select("id", { count: "exact", head: true }),
        supabase.from("contact_messages").select("id", { count: "exact", head: true }).eq("read", false),
        supabase.from("bookings").select("id", { count: "exact", head: true }).eq("status", "pending"),
      ]);
      setStats({
        bookings: bookingsRes.count ?? 0,
        messages: messagesRes.count ?? 0,
        unread: unreadRes.count ?? 0,
        pending: pendingRes.count ?? 0,
      });
    };
    fetchStats();
  }, []);

  const cards = [
    { label: "Total Bookings", value: stats.bookings, icon: CalendarCheck, color: "text-primary" },
    { label: "Pending Bookings", value: stats.pending, icon: TrendingUp, color: "text-accent" },
    { label: "Total Messages", value: stats.messages, icon: MessageSquare, color: "text-success" },
    { label: "Unread Messages", value: stats.unread, icon: MessageSquare, color: "text-destructive" },
  ];

  return (
    <div>
      <h2 className="text-2xl font-serif font-bold text-foreground mb-6">Overview</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => (
          <div key={card.label} className="bg-card border border-border rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-muted-foreground">{card.label}</span>
              <card.icon className={`h-5 w-5 ${card.color}`} />
            </div>
            <p className="text-3xl font-bold text-foreground">{card.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DashboardHome;
