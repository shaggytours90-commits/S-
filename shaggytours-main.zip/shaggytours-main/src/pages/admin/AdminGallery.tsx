import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, Save, X, Upload } from "lucide-react";
import { toast } from "sonner";

interface GalleryImage {
  id: string;
  title: string;
  image_url: string;
  category: string;
  sort_order: number;
  active: boolean;
}

const emptyImage = { title: "", image_url: "", category: "General", sort_order: 0, active: true };

const AdminGallery = () => {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState(emptyImage);
  const [uploading, setUploading] = useState(false);

  const { data: images = [], isLoading } = useQuery({
    queryKey: ["admin-gallery"],
    queryFn: async () => {
      const { data, error } = await supabase.from("gallery_images").select("*").order("sort_order");
      if (error) throw error;
      return data as GalleryImage[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (img: typeof emptyImage & { id?: string }) => {
      if (img.id) {
        const { error } = await supabase.from("gallery_images").update(img).eq("id", img.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("gallery_images").insert(img);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-gallery"] });
      queryClient.invalidateQueries({ queryKey: ["gallery-images"] });
      setEditing(null);
      setCreating(false);
      toast.success("Image saved!");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("gallery_images").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-gallery"] });
      queryClient.invalidateQueries({ queryKey: ["gallery-images"] });
      toast.success("Image deleted");
    },
    onError: (e) => toast.error(e.message),
  });

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const ext = file.name.split(".").pop();
    const path = `gallery/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("tour-images").upload(path, file);
    if (error) { toast.error(error.message); setUploading(false); return; }
    const { data } = supabase.storage.from("tour-images").getPublicUrl(path);
    setForm({ ...form, image_url: data.publicUrl });
    setUploading(false);
    toast.success("Image uploaded");
  };

  const startEdit = (img: GalleryImage) => {
    setEditing(img.id);
    setForm({ title: img.title, image_url: img.image_url, category: img.category, sort_order: img.sort_order, active: img.active });
    setCreating(false);
  };

  const startCreate = () => {
    setCreating(true);
    setEditing(null);
    setForm({ ...emptyImage, sort_order: images.length + 1 });
  };

  const isFormOpen = editing || creating;

  if (isLoading) return <div className="animate-pulse text-muted-foreground">Loading gallery...</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-foreground">Gallery ({images.length})</h2>
        <Button onClick={startCreate} className="gap-2 rounded-xl"><Plus className="h-4 w-4" /> Add Image</Button>
      </div>

      {isFormOpen && (
        <div className="bg-card border border-border rounded-2xl p-6 mb-6 space-y-4">
          <h3 className="font-semibold text-foreground">{editing ? "Edit Image" : "New Image"}</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input placeholder="Title *" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
            <input placeholder="Category" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
            <input type="number" placeholder="Order" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none" />
          </div>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              <Button type="button" variant="outline" size="sm" className="gap-2 rounded-xl" disabled={uploading} onClick={(e) => { e.preventDefault(); (e.currentTarget.previousElementSibling as HTMLInputElement)?.click(); }}>
                <Upload className="h-4 w-4" /> {uploading ? "Uploading..." : "Upload Image"}
              </Button>
            </label>
            {form.image_url && <img src={form.image_url} alt="" className="h-16 rounded-lg object-cover" />}
            <input placeholder="Or paste image URL" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} className="flex-1 px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
            <label className="flex items-center gap-2 text-sm text-foreground">
              <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Active
            </label>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => {
              if (!form.title || !form.image_url) { toast.error("Title and image are required"); return; }
              saveMutation.mutate(editing ? { ...form, id: editing } : form);
            }} disabled={saveMutation.isPending} className="gap-2 rounded-xl"><Save className="h-4 w-4" /> Save</Button>
            <Button variant="outline" onClick={() => { setEditing(null); setCreating(false); }} className="gap-2 rounded-xl"><X className="h-4 w-4" /> Cancel</Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {images.map((img) => (
          <div key={img.id} className="bg-card border border-border rounded-xl overflow-hidden group relative">
            <img src={img.image_url} alt={img.title} className="w-full aspect-square object-cover" />
            <div className="p-3">
              <p className="text-sm font-medium text-foreground truncate">{img.title}</p>
              <p className="text-xs text-muted-foreground">{img.category}</p>
              {!img.active && <span className="text-xs text-destructive">Inactive</span>}
            </div>
            <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <Button size="icon" variant="secondary" className="h-7 w-7 rounded-lg" onClick={() => startEdit(img)}><Pencil className="h-3 w-3" /></Button>
              <Button size="icon" variant="secondary" className="h-7 w-7 rounded-lg text-destructive" onClick={() => { if (confirm("Delete?")) deleteMutation.mutate(img.id); }}><Trash2 className="h-3 w-3" /></Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminGallery;
