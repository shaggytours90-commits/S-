import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import mammoth from "mammoth";
import { Upload, FileText, Loader2, Trash2, CheckCircle2, Search } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

const LANGS = [
  { code: "en", label: "English" },
  { code: "it", label: "Italiano" },
  { code: "ar", label: "العربية" },
  { code: "pl", label: "Polski" },
];

const extractText = async (file: File): Promise<string> => {
  if (file.name.toLowerCase().endsWith(".docx")) {
    const buffer = await file.arrayBuffer();
    const { value } = await mammoth.extractRawText({ arrayBuffer: buffer });
    return value;
  }
  return await file.text();
};

const AdminKnowledge = () => {
  const qc = useQueryClient();
  const [language, setLanguage] = useState("en");
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [replaceAll, setReplaceAll] = useState(false);

  const { data: docs = [] } = useQuery({
    queryKey: ["kb-documents-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kb_documents")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: entries = [] } = useQuery({
    queryKey: ["kb-entries-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("kb_entries")
        .select("*")
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const handleUpload = async (file: File) => {
    setBusy(true);
    try {
      const text = await extractText(file);
      if (!text.trim()) throw new Error("Could not read any text from this file.");

      const path = `${language}/${Date.now()}-${file.name}`;
      const { error: upErr } = await supabase.storage.from("knowledge-base").upload(path, file);
      if (upErr) throw upErr;

      const { data, error } = await supabase.functions.invoke("kb-ingest", {
        body: { filename: file.name, language, storage_path: path, text, replace_all: replaceAll },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success(
        replaceAll
          ? `Knowledge base replaced — ${data.entries} tours indexed from ${file.name}`
          : `Indexed ${data.entries} tours from ${file.name}`,
      );
      setReplaceAll(false);
      qc.invalidateQueries({ queryKey: ["kb-documents-admin"] });
      qc.invalidateQueries({ queryKey: ["kb-entries-admin"] });
      qc.invalidateQueries({ queryKey: ["kb-entries"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  };

  const removeDoc = async (id: string) => {
    const { error } = await supabase.from("kb_documents").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Document removed");
    qc.invalidateQueries({ queryKey: ["kb-documents-admin"] });
    qc.invalidateQueries({ queryKey: ["kb-entries-admin"] });
    qc.invalidateQueries({ queryKey: ["kb-entries"] });
  };

  const activate = async (id: string, lang: string) => {
    await supabase.from("kb_documents").update({ active: false }).eq("language", lang);
    const { error } = await supabase.from("kb_documents").update({ active: true }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Document activated");
    qc.invalidateQueries({ queryKey: ["kb-documents-admin"] });
    qc.invalidateQueries({ queryKey: ["kb-entries"] });
  };

  const term = search.toLowerCase().trim();
  const filtered = entries.filter((e) =>
    !term
      ? true
      : [e.title, e.category, e.destination, e.tour_slug, ...(e.keywords ?? [])]
          .join(" ")
          .toLowerCase()
          .includes(term),
  );

  return (
    <div className="space-y-6 pb-16">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Tour Knowledge Base</h1>
        <p className="text-sm text-muted-foreground">
          Upload the official tour document (.docx, .txt or .md). It becomes the source of truth for
          every tour page — replace the file any time to update the site.
        </p>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <div className="flex flex-wrap gap-2">
          {LANGS.map((l) => (
            <button
              key={l.code}
              onClick={() => setLanguage(l.code)}
              className={`px-3 py-1.5 rounded-full text-sm border transition-colors ${
                language === l.code
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>

        <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-border rounded-xl py-10 cursor-pointer hover:border-primary/50 transition-colors">
          {busy ? (
            <Loader2 className="h-7 w-7 text-primary animate-spin" />
          ) : (
            <Upload className="h-7 w-7 text-muted-foreground" />
          )}
          <span className="text-sm text-muted-foreground">
            {busy ? "Parsing and indexing…" : "Tap to upload the tour document"}
          </span>
          <input
            type="file"
            accept=".docx,.txt,.md"
            className="hidden"
            disabled={busy}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleUpload(f);
              e.target.value = "";
            }}
          />
        </label>

        <label className="flex items-start gap-3 text-sm text-muted-foreground cursor-pointer">
          <input
            type="checkbox"
            checked={replaceAll}
            disabled={busy}
            onChange={(e) => setReplaceAll(e.target.checked)}
            className="mt-1 h-4 w-4 accent-[hsl(var(--primary))]"
          />
          <span>
            <span className="text-foreground font-medium">
              Replace the entire knowledge base
            </span>
            <br />
            Deletes every previously uploaded document and indexed tour in all languages, then
            rebuilds everything from this new file.
          </span>
        </label>
      </div>

      <div className="space-y-3">
        <h2 className="font-semibold text-foreground">Uploaded documents</h2>
        {docs.length === 0 && (
          <p className="text-sm text-muted-foreground">No documents uploaded yet.</p>
        )}
        {docs.map((d) => (
          <div
            key={d.id}
            className="bg-card border border-border rounded-xl p-4 flex items-center gap-3"
          >
            <FileText className="h-5 w-5 text-primary shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-foreground truncate">{d.filename}</p>
              <p className="text-xs text-muted-foreground">
                {d.language.toUpperCase()} · {d.entry_count} tours ·{" "}
                {new Date(d.created_at).toLocaleDateString()}
              </p>
            </div>
            {d.active ? (
              <span className="text-xs text-[hsl(var(--success))] flex items-center gap-1">
                <CheckCircle2 className="h-4 w-4" /> Active
              </span>
            ) : (
              <Button size="sm" variant="outline" onClick={() => activate(d.id, d.language)}>
                Activate
              </Button>
            )}
            <Button size="icon" variant="ghost" onClick={() => removeDoc(d.id)}>
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <h2 className="font-semibold text-foreground">Indexed tours ({entries.length})</h2>
        <div className="flex items-center gap-2 border border-border rounded-xl px-3 py-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, category, destination or keyword"
            className="bg-transparent text-sm text-foreground outline-none w-full"
          />
        </div>
        {filtered.map((e) => (
          <div key={e.id} className="bg-card border border-border rounded-xl p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm font-medium text-foreground">{e.title}</p>
              <span className="text-[11px] uppercase text-muted-foreground">{e.language}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {e.tour_slug ? `linked to /tour/${e.tour_slug}` : "not linked to a tour page"} ·{" "}
              {(e.keywords ?? []).join(", ") || "no keywords"}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminKnowledge;
