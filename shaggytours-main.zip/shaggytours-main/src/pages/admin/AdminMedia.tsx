import { useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Upload, Trash2, Copy, Check, Pencil, X } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface MediaAsset {
  id: string;
  name: string;
  url: string;
  storage_path: string | null;
  folder: string;
}

const BUCKET = "tour-images";

const AdminMedia = () => {
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [folder, setFolder] = useState("general");
  const [search, setSearch] = useState("");
  const [copied, setCopied] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<MediaAsset | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [deleting, setDeleting] = useState<MediaAsset | null>(null);

  const { data: assets = [], isLoading } = useQuery({
    queryKey: ["admin-media"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("media_assets")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as MediaAsset[];
    },
  });

  const folders = Array.from(new Set(["general", ...assets.map((a) => a.folder)]));

  const filtered = assets.filter(
    (a) =>
      (folder === "all" || a.folder === folder) &&
      a.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleUpload = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const ext = file.name.split(".").pop();
        const path = `media/${folder === "all" ? "general" : folder}/${crypto.randomUUID()}.${ext}`;
        const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, file, {
          cacheControl: "31536000",
          upsert: false,
        });
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(path);
        const { error: dbErr } = await supabase.from("media_assets").insert({
          name: file.name,
          url: pub.publicUrl,
          storage_path: path,
          folder: folder === "all" ? "general" : folder,
        });
        if (dbErr) throw dbErr;
      }
      qc.invalidateQueries({ queryKey: ["admin-media"] });
      toast.success("Images uploaded");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const renameMutation = useMutation({
    mutationFn: async ({ id, name }: { id: string; name: string }) => {
      const { error } = await supabase.from("media_assets").update({ name }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-media"] });
      setRenaming(null);
      toast.success("Renamed");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (asset: MediaAsset) => {
      if (asset.storage_path) await supabase.storage.from(BUCKET).remove([asset.storage_path]);
      const { error } = await supabase.from("media_assets").delete().eq("id", asset.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-media"] });
      setDeleting(null);
      toast.success("Image deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const copy = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopied(url);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-serif font-bold text-foreground">Media Library</h2>
        <Button
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          className="gap-2 rounded-xl"
        >
          <Upload className="h-4 w-4" /> {uploading ? "Uploading..." : "Upload images"}
        </Button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => handleUpload(e.target.files)}
        />
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search images..."
          className="flex-1 px-4 py-3 border border-border rounded-xl bg-background text-sm outline-none focus:ring-2 focus:ring-primary/30"
        />
        <select
          value={folder}
          onChange={(e) => setFolder(e.target.value)}
          className="px-4 py-3 border border-border rounded-xl bg-background text-sm"
        >
          <option value="all">All folders</option>
          {folders.map((f) => (
            <option key={f} value={f}>{f}</option>
          ))}
        </select>
        <input
          placeholder="New folder name"
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              const v = (e.target as HTMLInputElement).value.trim();
              if (v) { setFolder(v); (e.target as HTMLInputElement).value = ""; }
            }
          }}
          className="px-4 py-3 border border-border rounded-xl bg-background text-sm"
        />
      </div>

      {isLoading ? (
        <p className="text-muted-foreground">Loading media...</p>
      ) : filtered.length === 0 ? (
        <p className="text-muted-foreground">No images yet. Upload your first image.</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {filtered.map((asset) => (
            <div key={asset.id} className="bg-card border border-border rounded-xl overflow-hidden">
              <img src={asset.url} alt={asset.name} loading="lazy" className="w-full h-32 object-cover" />
              <div className="p-2 space-y-2">
                <p className="text-xs text-foreground truncate" title={asset.name}>{asset.name}</p>
                <p className="text-[10px] text-muted-foreground">{asset.folder}</p>
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" className="flex-1 h-8 px-0" onClick={() => copy(asset.url)}>
                    {copied === asset.url ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 h-8 px-0"
                    onClick={() => { setRenaming(asset); setRenameValue(asset.name); }}
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 h-8 px-0 text-destructive" onClick={() => setDeleting(asset)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {renaming && (
        <div className="fixed inset-0 z-50 bg-background/80 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-2xl p-5 w-full max-w-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Rename image</h3>
              <button onClick={() => setRenaming(null)}><X className="h-4 w-4" /></button>
            </div>
            <input
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
            />
            <Button
              className="w-full rounded-xl"
              onClick={() => renameMutation.mutate({ id: renaming.id, name: renameValue })}
            >
              Save
            </Button>
          </div>
        </div>
      )}

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this image?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes the file. Pages using it will show a broken image.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && deleteMutation.mutate(deleting)}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AdminMedia;
