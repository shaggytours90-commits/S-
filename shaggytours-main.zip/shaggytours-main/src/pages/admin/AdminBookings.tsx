import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";

interface Booking {
  id: string;
  tour_id: string;
  tour_title: string;
  name: string;
  email: string;
  whatsapp: string | null;
  hotel: string;
  room: string | null;
  date: string;
  people: number;
  message: string | null;
  status: string;
  created_at: string;
}

const statusColors: Record<string, string> = {
  pending: "bg-warm/20 text-warm border-warm/30",
  confirmed: "bg-success/20 text-success border-success/30",
  cancelled: "bg-destructive/20 text-destructive border-destructive/30",
  completed: "bg-primary/20 text-primary border-primary/30",
};

const AdminBookings = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchBookings = async () => {
    const { data } = await supabase
      .from("bookings")
      .select("*")
      .order("created_at", { ascending: false });
    setBookings((data as Booking[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchBookings(); }, []);

  const updateStatus = async (id: string, status: string) => {
    await supabase.from("bookings").update({ status }).eq("id", id);
    toast.success(`Booking ${status}`);
    fetchBookings();
  };

  const deleteBooking = async (id: string) => {
    await supabase.from("bookings").delete().eq("id", id);
    toast.success("Booking deleted");
    fetchBookings();
  };

  if (loading) return <div className="text-muted-foreground">Loading...</div>;

  return (
    <div>
      <h2 className="text-2xl font-serif font-bold text-foreground mb-6">Bookings ({bookings.length})</h2>
      {bookings.length === 0 ? (
        <p className="text-muted-foreground">No bookings yet.</p>
      ) : (
        <div className="space-y-3">
          {bookings.map((b) => (
            <div key={b.id} className="bg-card border border-border rounded-xl p-5">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                <div>
                  <h3 className="font-semibold text-foreground">{b.tour_title}</h3>
                  <p className="text-sm text-muted-foreground">by {b.name} · {b.email}</p>
                </div>
                <Badge variant="outline" className={statusColors[b.status] ?? ""}>
                  {b.status}
                </Badge>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-sm text-muted-foreground mb-3">
                <span>📅 {format(new Date(b.date), "MMM d, yyyy")}</span>
                <span>👥 {b.people} people</span>
                <span>🏨 {b.hotel}{b.room ? ` #${b.room}` : ""}</span>
                {b.whatsapp && <span>📱 {b.whatsapp}</span>}
              </div>
              {b.message && <p className="text-sm text-muted-foreground mb-3 italic">"{b.message}"</p>}
              <div className="flex flex-wrap gap-2">
                {b.status === "pending" && (
                  <>
                    <Button size="sm" onClick={() => updateStatus(b.id, "confirmed")} className="bg-success hover:bg-success/90 text-success-foreground">
                      Confirm
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => updateStatus(b.id, "cancelled")}>
                      Cancel
                    </Button>
                  </>
                )}
                {b.status === "confirmed" && (
                  <Button size="sm" onClick={() => updateStatus(b.id, "completed")} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    Complete
                  </Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => deleteBooking(b.id)} className="text-destructive hover:bg-destructive/10 ml-auto">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminBookings;
