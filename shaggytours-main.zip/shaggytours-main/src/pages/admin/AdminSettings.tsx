import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";
import { toast } from "sonner";

const settingFields = [
  { key: "site_name", label: "Site Name", type: "text" },
  { key: "site_email", label: "Email Address", type: "email" },
  { key: "whatsapp_number", label: "WhatsApp Number (no +)", type: "text" },
  { key: "phone_display", label: "Phone Display Text", type: "text" },
  { key: "address", label: "Address", type: "text" },
  { key: "facebook_url", label: "Facebook URL", type: "url" },
  { key: "instagram_url", label: "Instagram URL", type: "url" },
  { key: "site_description", label: "Site Meta Description", type: "textarea" },
  { key: "footer_tagline", label: "Footer Tagline", type: "textarea" },
];

const AdminSettings = () => {
  const queryClient = useQueryClient();
  const [form, setForm] = useState<Record<string, string>>({});

  const { data: settings, isLoading } = useQuery({
    queryKey: ["admin-site-settings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("site_settings").select("key, value");
      if (error) throw error;
      const map: Record<string, string> = {};
      data?.forEach((r: { key: string; value: string }) => { map[r.key] = r.value; });
      return map;
    },
  });

  useEffect(() => {
    if (settings) setForm(settings);
  }, [settings]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      for (const [key, value] of Object.entries(form)) {
        await supabase.from("site_settings").upsert({ key, value }, { onConflict: "key" });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-site-settings"] });
      queryClient.invalidateQueries({ queryKey: ["site-settings"] });
      toast.success("Settings saved!");
    },
    onError: (e) => toast.error(e.message),
  });

  if (isLoading) return <div className="animate-pulse text-muted-foreground">Loading settings...</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-foreground">Site Settings</h2>
        <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="gap-2 rounded-xl">
          <Save className="h-4 w-4" /> {saveMutation.isPending ? "Saving..." : "Save All"}
        </Button>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
        {settingFields.map((field) => (
          <div key={field.key}>
            <label className="text-sm font-medium text-foreground mb-1.5 block">{field.label}</label>
            {field.type === "textarea" ? (
              <textarea
                rows={3}
                value={form[field.key] || ""}
                onChange={(e) => setForm({ ...form, [field.key]: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30 resize-none"
              />
            ) : (
              <input
                type={field.type}
                value={form[field.key] || ""}
                onChange={(e) => setForm({ ...form, [field.key]: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30"
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminSettings;
