import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import TourQuickActions from "@/components/admin/TourQuickActions";
import TourForm, { type TourFormData } from "@/components/admin/TourForm";
import { optimizeImageUrl } from "@/lib/imageUtils";
import { formatPrice } from "@/lib/currency";
import { Search } from "lucide-react";

interface TourRow {
  id: string;
  slug: string;
  title: string;
  destination: string;
  image_url: string | null;
  gallery_images: string[] | null;
  price: number;
  child_price: number | null;
  currency: string;
  original_price: number | null;
  duration: string;
  departure_time: string;
  rating: number;
  reviews: number;
  short_description: string;
  description: string;
  highlights: string[];
  included: string[];
  not_included: string[];
  what_to_bring: string[] | null;
  meeting_point: string;
  featured: boolean;
  category: string;
  best_season: string;
  active: boolean;
  sort_order: number;
  itinerary: any;
}

const emptyTour: TourFormData = {
  slug: "", title: "", destination: "", image_url: "", gallery_images: [], price: 0,
  child_price: null, currency: "GBP", original_price: null,
  duration: "Full Day", departure_time: "", rating: 4.5, reviews: 0,
  short_description: "", description: "", highlights: [],
  included: [], not_included: [], what_to_bring: [], meeting_point: "",
  featured: false, category: "adventure",
  best_season: "Year-round", active: true, sort_order: 0, itinerary: [],
};

const AdminTours = () => {
  const queryClient = useQueryClient();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [editData, setEditData] = useState<TourFormData>(emptyTour);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "hidden" | "featured">("all");

  const { data: tours = [], isLoading } = useQuery({
    queryKey: ["admin-tours"],
    queryFn: async () => {
      const { data, error } = await supabase.from("tours").select("*").order("sort_order");
      if (error) throw error;
      return data as unknown as TourRow[];
    },
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["admin-tours"] });
    queryClient.invalidateQueries({ queryKey: ["tours"] });
  };

  const saveMutation = useMutation({
    mutationFn: async (tour: TourFormData & { id?: string }) => {
      if (tour.id) {
        const { error } = await supabase.from("tours").update(tour).eq("id", tour.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("tours").insert(tour);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      invalidate();
      setEditingId(null);
      setCreating(false);
      toast.success("Tour saved!");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("tours").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Tour deleted"); },
    onError: (e) => toast.error(e.message),
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from("tours").update({ active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Tour updated"); },
    onError: (e) => toast.error(e.message),
  });

  const startEdit = (tour: TourRow) => {
    setEditingId(tour.id);
    setEditData({
      slug: tour.slug, title: tour.title, destination: tour.destination,
      image_url: tour.image_url || "", gallery_images: tour.gallery_images || [],
      price: tour.price, child_price: tour.child_price ?? null, currency: tour.currency || "GBP",
      original_price: tour.original_price,
      duration: tour.duration, departure_time: tour.departure_time || "",
      rating: tour.rating, reviews: tour.reviews,
      short_description: tour.short_description || "",
      description: tour.description, highlights: tour.highlights || [], included: tour.included || [],
      not_included: tour.not_included || [], what_to_bring: tour.what_to_bring || [],
      meeting_point: tour.meeting_point || "",
      featured: tour.featured, category: tour.category,
      best_season: tour.best_season, active: tour.active, sort_order: tour.sort_order,
      itinerary: tour.itinerary || [],
    });
    setCreating(false);
  };

  const startCreate = () => {
    setCreating(true);
    setEditingId(null);
    setEditData({ ...emptyTour, sort_order: tours.length + 1 });
  };

  const handleSave = (data: TourFormData) => {
    if (editingId) {
      saveMutation.mutate({ ...data, id: editingId } as any);
    } else {
      saveMutation.mutate(data as any);
    }
  };

  // Show form view
  if (editingId || creating) {
    return (
      <TourForm
        initialData={editData}
        isEditing={!!editingId}
        isSaving={saveMutation.isPending}
        onSave={handleSave}
        onCancel={() => { setEditingId(null); setCreating(false); }}
      />
    );
  }

  const visibleTours = tours.filter((t) => {
    const q = search.trim().toLowerCase();
    if (q && !`${t.title} ${t.destination} ${t.category}`.toLowerCase().includes(q)) return false;
    if (filter === "active") return t.active;
    if (filter === "hidden") return !t.active;
    if (filter === "featured") return t.featured;
    return true;
  });

  if (isLoading) return <div className="animate-pulse text-muted-foreground p-4">Loading tours...</div>;

  // Tour list view
  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-foreground">Tours</h2>
          <p className="text-sm text-muted-foreground">{tours.length} products</p>
        </div>
        <Button onClick={startCreate} className="gap-2 rounded-xl h-11 px-5 text-base">
          <Plus className="h-5 w-5" /> Add
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search tours..."
            className="w-full pl-9 pr-4 h-11 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as typeof filter)}
          className="h-11 px-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none"
        >
          <option value="all">All</option>
          <option value="active">Visible</option>
          <option value="hidden">Hidden</option>
          <option value="featured">Featured</option>
        </select>
      </div>

      <div className="space-y-3">
        {visibleTours.map((t) => (
          <div
            key={t.id}
            className="bg-card border border-border rounded-xl p-3 sm:p-4 flex gap-3 items-start"
          >
            {/* Thumbnail */}
            {t.image_url ? (
              <img
                src={optimizeImageUrl(t.image_url, 200)}
                alt={t.title}
                className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-lg shrink-0"
                loading="lazy"
              />
            ) : (
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-muted rounded-lg shrink-0 flex items-center justify-center text-muted-foreground text-xs">
                No img
              </div>
            )}

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <h3 className="font-semibold text-foreground text-sm sm:text-base truncate">{t.title}</h3>
                  <div className="flex items-center gap-2 mt-0.5">
                    {t.original_price && (
                      <span className="text-xs text-muted-foreground line-through">{formatPrice(t.original_price, t.currency)}</span>
                    )}
                    <span className="text-base sm:text-lg font-bold text-primary">{formatPrice(t.price, t.currency)}</span>
                  </div>
                </div>
                <TourQuickActions
                  isActive={t.active}
                  onEdit={() => startEdit(t)}
                  onToggleActive={() => toggleActiveMutation.mutate({ id: t.id, active: !t.active })}
                  onDelete={() => deleteMutation.mutate(t.id)}
                  isToggling={toggleActiveMutation.isPending}
                />
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                <Badge variant="outline" className="text-[11px]">{t.category}</Badge>
                <Badge variant="outline" className="text-[11px]">⭐ {t.rating}</Badge>
                {t.featured && <Badge className="bg-accent text-accent-foreground text-[11px]">Featured</Badge>}
                {!t.active && <Badge variant="destructive" className="text-[11px]">Hidden</Badge>}
              </div>
            </div>
          </div>
        ))}
      </div>

      {tours.length === 0 && (
        <div className="text-center py-16">
          <p className="text-muted-foreground mb-4">No tours yet.</p>
          <Button onClick={startCreate} className="gap-2 rounded-xl h-11">
            <Plus className="h-5 w-5" /> Add your first tour
          </Button>
        </div>
      )}
    </div>
  );
};

export default AdminTours;
