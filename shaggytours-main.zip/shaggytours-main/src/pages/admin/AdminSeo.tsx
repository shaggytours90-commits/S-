import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus, Save, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { SUPPORTED_LANGUAGES } from "@/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface SeoRow {
  id: string;
  path: string;
  label: string;
  meta_title: string;
  meta_description: string;
  keywords: string;
  og_image: string | null;
  translations: Record<string, { meta_title?: string; meta_description?: string; keywords?: string }>;
}

const empty: Omit<SeoRow, "id"> = {
  path: "/",
  label: "",
  meta_title: "",
  meta_description: "",
  keywords: "",
  og_image: "",
  translations: {},
};

type Field = "meta_title" | "meta_description" | "keywords";

const AdminSeo = () => {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<(Omit<SeoRow, "id"> & { id?: string }) | null>(null);
  const [lang, setLang] = useState("en");
  const [deleting, setDeleting] = useState<SeoRow | null>(null);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["admin-seo"],
    queryFn: async () => {
      const { data, error } = await supabase.from("seo_meta").select("*").order("path");
      if (error) throw error;
      return data as unknown as SeoRow[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (row: Omit<SeoRow, "id"> & { id?: string }) => {
      const payload = {
        path: row.path,
        label: row.label,
        meta_title: row.meta_title,
        meta_description: row.meta_description,
        keywords: row.keywords,
        og_image: row.og_image || null,
        translations: row.translations,
      };
      if (row.id) {
        const { error } = await supabase.from("seo_meta").update(payload).eq("id", row.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("seo_meta").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-seo"] });
      qc.invalidateQueries({ queryKey: ["seo-meta"] });
      setEditing(null);
      toast.success("SEO saved");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("seo_meta").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-seo"] });
      setDeleting(null);
      toast.success("Entry deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const getVal = (field: Field) => {
    if (!editing) return "";
    return lang === "en" ? editing[field] : editing.translations?.[lang]?.[field] ?? "";
  };

  const setVal = (field: Field, value: string) => {
    if (!editing) return;
    if (lang === "en") setEditing({ ...editing, [field]: value });
    else
      setEditing({
        ...editing,
        translations: {
          ...editing.translations,
          [lang]: { ...(editing.translations?.[lang] ?? {}), [field]: value },
        },
      });
  };

  if (editing) {
    return (
      <div className="space-y-4 pb-24">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-serif font-bold">{editing.id ? "Edit SEO" : "New SEO entry"}</h2>
          <Button variant="ghost" size="sm" onClick={() => setEditing(null)}><X className="h-4 w-4" /></Button>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1">
          {SUPPORTED_LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => setLang(l.code)}
              className={`px-3 py-2 rounded-xl text-sm whitespace-nowrap border ${
                lang === l.code ? "bg-primary text-primary-foreground border-primary" : "border-border bg-card"
              }`}
            >
              {l.flag} {l.label}
            </button>
          ))}
        </div>

        <div className="bg-card border border-border rounded-2xl p-4 space-y-4">
          {lang === "en" && (
            <>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Page path</label>
                <input
                  value={editing.path}
                  onChange={(e) => setEditing({ ...editing, path: e.target.value })}
                  placeholder="/tours"
                  className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Label</label>
                <input
                  value={editing.label}
                  onChange={(e) => setEditing({ ...editing, label: e.target.value })}
                  className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Social share image URL</label>
                <input
                  value={editing.og_image ?? ""}
                  onChange={(e) => setEditing({ ...editing, og_image: e.target.value })}
                  className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
                />
              </div>
            </>
          )}
          <div>
            <label className="text-sm font-medium mb-1.5 block">Meta title ({lang})</label>
            <input
              value={getVal("meta_title")}
              onChange={(e) => setVal("meta_title", e.target.value)}
              className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Meta description ({lang})</label>
            <textarea
              rows={3}
              value={getVal("meta_description")}
              onChange={(e) => setVal("meta_description", e.target.value)}
              className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Keywords ({lang})</label>
            <input
              value={getVal("keywords")}
              onChange={(e) => setVal("keywords", e.target.value)}
              className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
            />
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 p-3 bg-card border-t border-border md:static md:p-0 md:bg-transparent md:border-0">
          <Button
            className="w-full md:w-auto gap-2 rounded-xl"
            onClick={() => saveMutation.mutate(editing)}
            disabled={saveMutation.isPending || !editing.path}
          >
            <Save className="h-4 w-4" /> {saveMutation.isPending ? "Saving..." : "Save SEO"}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-serif font-bold">SEO</h2>
        <Button className="gap-2 rounded-xl" onClick={() => { setLang("en"); setEditing({ ...empty }); }}>
          <Plus className="h-4 w-4" /> New entry
        </Button>
      </div>
      <p className="text-sm text-muted-foreground">
        Global defaults live in Site Settings. Entries here override them per page.
      </p>

      {isLoading ? (
        <p className="text-muted-foreground">Loading...</p>
      ) : (
        <div className="grid gap-3">
          {rows.map((r) => (
            <div key={r.id} className="bg-card border border-border rounded-2xl p-4 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="font-medium truncate">{r.label || r.path}</p>
                <p className="text-xs text-muted-foreground truncate">{r.path} — {r.meta_title || "no title"}</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <Button size="sm" variant="outline" className="rounded-xl" onClick={() => { setLang("en"); setEditing(r); }}>Edit</Button>
                <Button size="sm" variant="outline" className="rounded-xl text-destructive" onClick={() => setDeleting(r)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete SEO entry?</AlertDialogTitle>
            <AlertDialogDescription>The page will fall back to the global defaults.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && deleteMutation.mutate(deleting.id)}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AdminSeo;
