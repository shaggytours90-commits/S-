import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, Save, X, Star } from "lucide-react";
import { toast } from "sonner";
import { SUPPORTED_LANGUAGES } from "@/i18n";

interface Testimonial {
  id: string;
  name: string;
  location: string;
  avatar: string;
  rating: number;
  text: string;
  tour: string;
  sort_order: number;
  active: boolean;
  language: string;
  country: string;
}

const emptyTestimonial = { name: "", location: "", avatar: "", rating: 5, text: "", tour: "", sort_order: 0, active: true, language: "en", country: "" };

const AdminTestimonials = () => {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState(emptyTestimonial);

  const { data: testimonials = [], isLoading } = useQuery({
    queryKey: ["admin-testimonials"],
    queryFn: async () => {
      const { data, error } = await supabase.from("testimonials").select("*").order("sort_order");
      if (error) throw error;
      return data as Testimonial[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (t: typeof emptyTestimonial & { id?: string }) => {
      if (t.id) {
        const { error } = await supabase.from("testimonials").update(t).eq("id", t.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("testimonials").insert(t);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-testimonials"] });
      queryClient.invalidateQueries({ queryKey: ["testimonials"] });
      setEditing(null);
      setCreating(false);
      toast.success("Testimonial saved!");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("testimonials").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-testimonials"] });
      queryClient.invalidateQueries({ queryKey: ["testimonials"] });
      toast.success("Testimonial deleted");
    },
    onError: (e) => toast.error(e.message),
  });

  const startEdit = (t: Testimonial) => {
    setEditing(t.id);
    setForm({ name: t.name, location: t.location, avatar: t.avatar, rating: t.rating, text: t.text, tour: t.tour, sort_order: t.sort_order, active: t.active, language: t.language || "en", country: t.country || "" });
    setCreating(false);
  };

  const startCreate = () => {
    setCreating(true);
    setEditing(null);
    setForm({ ...emptyTestimonial, sort_order: testimonials.length + 1 });
  };

  const isFormOpen = editing || creating;

  if (isLoading) return <div className="animate-pulse text-muted-foreground">Loading testimonials...</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-foreground">Testimonials ({testimonials.length})</h2>
        <Button onClick={startCreate} className="gap-2 rounded-xl"><Plus className="h-4 w-4" /> Add Testimonial</Button>
      </div>

      {isFormOpen && (
        <div className="bg-card border border-border rounded-2xl p-6 mb-6 space-y-4">
          <h3 className="font-semibold text-foreground">{editing ? "Edit Testimonial" : "New Testimonial"}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input placeholder="Name *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
            <input placeholder="Location" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
            <input placeholder="Avatar initials (e.g. JD)" value={form.avatar} onChange={(e) => setForm({ ...form, avatar: e.target.value })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
            <input placeholder="Country (e.g. Italy)" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
            <select value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30">
              {SUPPORTED_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>{l.flag} {l.label}</option>
              ))}
            </select>
            <input placeholder="Tour name" value={form.tour} onChange={(e) => setForm({ ...form, tour: e.target.value })} className="px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
          </div>
          <textarea placeholder="Review text *" rows={3} value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30 resize-none" />
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <span className="text-sm text-foreground mr-1">Rating:</span>
              {[1, 2, 3, 4, 5].map((n) => (
                <button key={n} onClick={() => setForm({ ...form, rating: n })} className="p-0.5">
                  <Star className={`h-5 w-5 ${n <= form.rating ? "text-warm fill-warm" : "text-border"}`} />
                </button>
              ))}
            </div>
            <input type="number" placeholder="Order" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) })} className="w-20 px-3 py-2 border border-border rounded-xl bg-background text-sm text-foreground outline-none" />
            <label className="flex items-center gap-2 text-sm text-foreground">
              <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Active
            </label>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => {
              if (!form.name || !form.text) { toast.error("Name and text are required"); return; }
              saveMutation.mutate(editing ? { ...form, id: editing } : form);
            }} disabled={saveMutation.isPending} className="gap-2 rounded-xl"><Save className="h-4 w-4" /> Save</Button>
            <Button variant="outline" onClick={() => { setEditing(null); setCreating(false); }} className="gap-2 rounded-xl"><X className="h-4 w-4" /> Cancel</Button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {testimonials.map((t) => (
          <div key={t.id} className="bg-card border border-border rounded-xl p-5 flex gap-4">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold shrink-0">
              {t.avatar}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-semibold text-foreground text-sm">{t.name}</h3>
                <span className="text-xs text-muted-foreground">{[t.country, t.location].filter(Boolean).join(" · ")}</span>
                <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{t.language || "en"}</span>
                <div className="flex gap-0.5 ml-auto">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="h-3 w-3 text-warm fill-warm" />
                  ))}
                </div>
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2">"{t.text}"</p>
              <div className="flex gap-2 mt-1">
                {t.tour && <span className="text-xs text-primary">{t.tour}</span>}
                {!t.active && <span className="text-xs text-destructive">Inactive</span>}
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button size="sm" variant="outline" onClick={() => startEdit(t)} className="gap-1 rounded-lg"><Pencil className="h-3.5 w-3.5" /></Button>
              <Button size="sm" variant="outline" onClick={() => { if (confirm("Delete?")) deleteMutation.mutate(t.id); }} className="gap-1 rounded-lg text-destructive hover:bg-destructive/10"><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminTestimonials;
