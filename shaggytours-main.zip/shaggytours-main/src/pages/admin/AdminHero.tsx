import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Save, Upload } from "lucide-react";
import { toast } from "sonner";

interface HeroSection {
  id: string;
  key: string;
  title: string;
  subtitle: string;
  badge_text: string;
  image_url: string | null;
}

const AdminHero = () => {
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ title: "", subtitle: "", badge_text: "", image_url: "" });
  const [uploading, setUploading] = useState(false);

  const { data: hero, isLoading } = useQuery({
    queryKey: ["admin-hero-home"],
    queryFn: async () => {
      const { data, error } = await supabase.from("hero_sections").select("*").eq("key", "home").maybeSingle();
      if (error) throw error;
      return data as HeroSection | null;
    },
  });

  useEffect(() => {
    if (hero) {
      setForm({ title: hero.title, subtitle: hero.subtitle, badge_text: hero.badge_text, image_url: hero.image_url || "" });
    }
  }, [hero]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (hero?.id) {
        const { error } = await supabase.from("hero_sections").update(form).eq("id", hero.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("hero_sections").insert({ ...form, key: "home" });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-hero-home"] });
      queryClient.invalidateQueries({ queryKey: ["hero-section"] });
      toast.success("Hero section saved!");
    },
    onError: (e) => toast.error(e.message),
  });

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const ext = file.name.split(".").pop();
    const path = `hero/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("tour-images").upload(path, file);
    if (error) { toast.error(error.message); setUploading(false); return; }
    const { data } = supabase.storage.from("tour-images").getPublicUrl(path);
    setForm({ ...form, image_url: data.publicUrl });
    setUploading(false);
    toast.success("Image uploaded");
  };

  if (isLoading) return <div className="animate-pulse text-muted-foreground">Loading hero section...</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-foreground">Homepage Hero</h2>
        <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="gap-2 rounded-xl">
          <Save className="h-4 w-4" /> {saveMutation.isPending ? "Saving..." : "Save Changes"}
        </Button>
      </div>

      <div className="bg-card border border-border rounded-2xl p-6 space-y-5">
        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">Badge Text</label>
          <input value={form.badge_text} onChange={(e) => setForm({ ...form, badge_text: e.target.value })} placeholder="e.g. Marsa Alam's #1 Tour Operator" className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">Title (use &lt;br&gt; for line breaks)</label>
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Explore the<br><span>Red Sea Magic</span>" className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
          <p className="text-xs text-muted-foreground mt-1">Wrap accented text in &lt;span&gt; tags for the accent color.</p>
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">Subtitle</label>
          <textarea rows={3} value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30 resize-none" />
        </div>
        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">Background Image</label>
          <div className="flex items-center gap-4">
            <label className="cursor-pointer">
              <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
              <Button type="button" variant="outline" size="sm" className="gap-2 rounded-xl" disabled={uploading} onClick={(e) => { e.preventDefault(); (e.currentTarget.previousElementSibling as HTMLInputElement)?.click(); }}>
                <Upload className="h-4 w-4" /> {uploading ? "Uploading..." : "Upload Image"}
              </Button>
            </label>
            <input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="Or paste image URL" className="flex-1 px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
          </div>
          {form.image_url && <img src={form.image_url} alt="Hero preview" className="mt-3 h-40 w-full object-cover rounded-xl" />}
        </div>
      </div>
    </div>
  );
};

export default AdminHero;
