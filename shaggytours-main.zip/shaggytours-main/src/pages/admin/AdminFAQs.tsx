import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, Save, X, GripVertical } from "lucide-react";
import { toast } from "sonner";

interface FAQ {
  id: string;
  question: string;
  answer: string;
  sort_order: number;
  active: boolean;
}

const emptyFAQ = { question: "", answer: "", sort_order: 0, active: true };

const AdminFAQs = () => {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState(emptyFAQ);

  const { data: faqs = [], isLoading } = useQuery({
    queryKey: ["admin-faqs"],
    queryFn: async () => {
      const { data, error } = await supabase.from("faqs").select("*").order("sort_order");
      if (error) throw error;
      return data as FAQ[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (faq: typeof emptyFAQ & { id?: string }) => {
      if (faq.id) {
        const { error } = await supabase.from("faqs").update(faq).eq("id", faq.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("faqs").insert(faq);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-faqs"] });
      queryClient.invalidateQueries({ queryKey: ["faqs"] });
      setEditing(null);
      setCreating(false);
      toast.success("FAQ saved!");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("faqs").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-faqs"] });
      queryClient.invalidateQueries({ queryKey: ["faqs"] });
      toast.success("FAQ deleted");
    },
    onError: (e) => toast.error(e.message),
  });

  const startEdit = (faq: FAQ) => {
    setEditing(faq.id);
    setForm({ question: faq.question, answer: faq.answer, sort_order: faq.sort_order, active: faq.active });
    setCreating(false);
  };

  const startCreate = () => {
    setCreating(true);
    setEditing(null);
    setForm({ ...emptyFAQ, sort_order: faqs.length + 1 });
  };

  const isFormOpen = editing || creating;

  if (isLoading) return <div className="animate-pulse text-muted-foreground">Loading FAQs...</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-foreground">FAQs ({faqs.length})</h2>
        <Button onClick={startCreate} className="gap-2 rounded-xl"><Plus className="h-4 w-4" /> Add FAQ</Button>
      </div>

      {isFormOpen && (
        <div className="bg-card border border-border rounded-2xl p-6 mb-6 space-y-4">
          <h3 className="font-semibold text-foreground">{editing ? "Edit FAQ" : "New FAQ"}</h3>
          <input placeholder="Question *" value={form.question} onChange={(e) => setForm({ ...form, question: e.target.value })} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30" />
          <textarea placeholder="Answer *" rows={4} value={form.answer} onChange={(e) => setForm({ ...form, answer: e.target.value })} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/30 resize-none" />
          <div className="flex items-center gap-4">
            <input type="number" placeholder="Order" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: Number(e.target.value) })} className="w-20 px-3 py-2 border border-border rounded-xl bg-background text-sm text-foreground outline-none" />
            <label className="flex items-center gap-2 text-sm text-foreground">
              <input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /> Active
            </label>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => {
              if (!form.question || !form.answer) { toast.error("Question and answer are required"); return; }
              saveMutation.mutate(editing ? { ...form, id: editing } : form);
            }} disabled={saveMutation.isPending} className="gap-2 rounded-xl"><Save className="h-4 w-4" /> Save</Button>
            <Button variant="outline" onClick={() => { setEditing(null); setCreating(false); }} className="gap-2 rounded-xl"><X className="h-4 w-4" /> Cancel</Button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {faqs.map((faq) => (
          <div key={faq.id} className="bg-card border border-border rounded-xl p-5 flex gap-4">
            <GripVertical className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-foreground text-sm mb-1">{faq.question}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{faq.answer}</p>
              <div className="flex gap-2 mt-2">
                {!faq.active && <span className="text-xs text-destructive">Inactive</span>}
                <span className="text-xs text-muted-foreground">Order: {faq.sort_order}</span>
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button size="sm" variant="outline" onClick={() => startEdit(faq)} className="gap-1 rounded-lg"><Pencil className="h-3.5 w-3.5" /></Button>
              <Button size="sm" variant="outline" onClick={() => { if (confirm("Delete this FAQ?")) deleteMutation.mutate(faq.id); }} className="gap-1 rounded-lg text-destructive hover:bg-destructive/10"><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminFAQs;
