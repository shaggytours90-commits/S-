import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Save, X, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { SUPPORTED_LANGUAGES } from "@/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface PageRow {
  id: string;
  slug: string;
  title: string;
  body: string;
  translations: Record<string, { title?: string; body?: string }>;
  published: boolean;
  sort_order: number;
}

const empty: Omit<PageRow, "id"> = {
  slug: "",
  title: "",
  body: "",
  translations: {},
  published: true,
  sort_order: 0,
};

const slugify = (v: string) =>
  v.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-");

const AdminPages = () => {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<(Omit<PageRow, "id"> & { id?: string }) | null>(null);
  const [lang, setLang] = useState("en");
  const [deleting, setDeleting] = useState<PageRow | null>(null);

  const { data: pages = [], isLoading } = useQuery({
    queryKey: ["admin-pages"],
    queryFn: async () => {
      const { data, error } = await supabase.from("content_pages").select("*").order("sort_order");
      if (error) throw error;
      return data as unknown as PageRow[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (page: Omit<PageRow, "id"> & { id?: string }) => {
      const payload = {
        slug: slugify(page.slug),
        title: page.title,
        body: page.body,
        translations: page.translations,
        published: page.published,
        sort_order: page.sort_order,
      };
      if (page.id) {
        const { error } = await supabase.from("content_pages").update(payload).eq("id", page.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("content_pages").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-pages"] });
      qc.invalidateQueries({ queryKey: ["content-page"] });
      qc.invalidateQueries({ queryKey: ["content-pages"] });
      setEditing(null);
      toast.success("Page saved");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("content_pages").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-pages"] });
      setDeleting(null);
      toast.success("Page deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setLangValue = (field: "title" | "body", value: string) => {
    if (!editing) return;
    if (lang === "en") {
      setEditing({ ...editing, [field]: value });
    } else {
      setEditing({
        ...editing,
        translations: {
          ...editing.translations,
          [lang]: { ...(editing.translations?.[lang] ?? {}), [field]: value },
        },
      });
    }
  };

  const getLangValue = (field: "title" | "body") => {
    if (!editing) return "";
    return lang === "en" ? editing[field] : editing.translations?.[lang]?.[field] ?? "";
  };

  if (editing) {
    return (
      <div className="space-y-4 pb-24">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-serif font-bold">{editing.id ? "Edit page" : "New page"}</h2>
          <Button variant="ghost" size="sm" onClick={() => setEditing(null)}><X className="h-4 w-4" /></Button>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1">
          {SUPPORTED_LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => setLang(l.code)}
              className={`px-3 py-2 rounded-xl text-sm whitespace-nowrap border ${
                lang === l.code ? "bg-primary text-primary-foreground border-primary" : "border-border bg-card"
              }`}
            >
              {l.flag} {l.label}
            </button>
          ))}
        </div>

        <div className="bg-card border border-border rounded-2xl p-4 space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Title ({lang})</label>
            <input
              value={getLangValue("title")}
              onChange={(e) => setLangValue("title", e.target.value)}
              placeholder={lang === "en" ? "" : editing.title}
              className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
            />
          </div>
          {lang === "en" && (
            <div>
              <label className="text-sm font-medium mb-1.5 block">URL slug</label>
              <input
                value={editing.slug}
                onChange={(e) => setEditing({ ...editing, slug: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
              />
              <p className="text-xs text-muted-foreground mt-1">Public URL: /p/{slugify(editing.slug) || "slug"}</p>
            </div>
          )}
          <div>
            <label className="text-sm font-medium mb-1.5 block">Content ({lang})</label>
            <textarea
              rows={14}
              value={getLangValue("body")}
              onChange={(e) => setLangValue("body", e.target.value)}
              className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm"
            />
            <p className="text-xs text-muted-foreground mt-1">Plain text or basic HTML is supported.</p>
          </div>
          <div className="flex flex-wrap gap-4 items-center">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={editing.published}
                onChange={(e) => setEditing({ ...editing, published: e.target.checked })}
              />
              Published
            </label>
            <label className="flex items-center gap-2 text-sm">
              Order
              <input
                type="number"
                value={editing.sort_order}
                onChange={(e) => setEditing({ ...editing, sort_order: Number(e.target.value) })}
                className="w-20 px-3 py-2 border border-border rounded-xl bg-background"
              />
            </label>
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 p-3 bg-card border-t border-border md:static md:p-0 md:bg-transparent md:border-0">
          <Button
            className="w-full md:w-auto gap-2 rounded-xl"
            onClick={() => saveMutation.mutate(editing)}
            disabled={saveMutation.isPending || !editing.slug || !editing.title}
          >
            <Save className="h-4 w-4" /> {saveMutation.isPending ? "Saving..." : "Save page"}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-serif font-bold">Pages</h2>
        <Button className="gap-2 rounded-xl" onClick={() => { setLang("en"); setEditing({ ...empty }); }}>
          <Plus className="h-4 w-4" /> New page
        </Button>
      </div>

      {isLoading ? (
        <p className="text-muted-foreground">Loading pages...</p>
      ) : (
        <div className="grid gap-3">
          {pages.map((p) => (
            <div key={p.id} className="bg-card border border-border rounded-2xl p-4 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="font-medium truncate">{p.title}</p>
                <p className="text-xs text-muted-foreground truncate">/p/{p.slug}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs text-muted-foreground hidden sm:flex items-center gap-1">
                  {p.published ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                  {p.published ? "Live" : "Hidden"}
                </span>
                <Button size="sm" variant="outline" className="rounded-xl" onClick={() => { setLang("en"); setEditing(p); }}>
                  Edit
                </Button>
                <Button size="sm" variant="outline" className="rounded-xl text-destructive" onClick={() => setDeleting(p)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete "{deleting?.title}"?</AlertDialogTitle>
            <AlertDialogDescription>This removes the page and all its translations.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && deleteMutation.mutate(deleting.id)}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AdminPages;
