import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Trash2, Mail, MailOpen } from "lucide-react";

interface Message {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  message: string;
  read: boolean;
  created_at: string;
}

const AdminMessages = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMessages = async () => {
    const { data } = await supabase
      .from("contact_messages")
      .select("*")
      .order("created_at", { ascending: false });
    setMessages((data as Message[]) ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchMessages(); }, []);

  const toggleRead = async (id: string, read: boolean) => {
    await supabase.from("contact_messages").update({ read: !read }).eq("id", id);
    fetchMessages();
  };

  const deleteMessage = async (id: string) => {
    await supabase.from("contact_messages").delete().eq("id", id);
    toast.success("Message deleted");
    fetchMessages();
  };

  if (loading) return <div className="text-muted-foreground">Loading...</div>;

  return (
    <div>
      <h2 className="text-2xl font-serif font-bold text-foreground mb-6">Messages ({messages.length})</h2>
      {messages.length === 0 ? (
        <p className="text-muted-foreground">No messages yet.</p>
      ) : (
        <div className="space-y-3">
          {messages.map((m) => (
            <div key={m.id} className={`bg-card border rounded-xl p-5 ${m.read ? "border-border" : "border-primary/30 bg-primary/5"}`}>
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <h3 className="font-semibold text-foreground flex items-center gap-2">
                    {!m.read && <span className="w-2 h-2 bg-primary rounded-full" />}
                    {m.name}
                  </h3>
                  <p className="text-sm text-muted-foreground">{m.email}{m.phone ? ` · ${m.phone}` : ""}</p>
                </div>
                <span className="text-xs text-muted-foreground shrink-0">
                  {format(new Date(m.created_at), "MMM d, yyyy HH:mm")}
                </span>
              </div>
              <p className="text-sm text-foreground mb-3">{m.message}</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => toggleRead(m.id, m.read)} className="gap-1">
                  {m.read ? <Mail className="h-3.5 w-3.5" /> : <MailOpen className="h-3.5 w-3.5" />}
                  {m.read ? "Mark unread" : "Mark read"}
                </Button>
                <Button size="sm" variant="ghost" onClick={() => deleteMessage(m.id)} className="text-destructive hover:bg-destructive/10 ml-auto">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminMessages;
