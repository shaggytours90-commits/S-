import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Plus, Pencil, Trash2, X } from "lucide-react";
import { toast } from "sonner";

interface CategoryRow {
  id: string;
  name: string;
  slug: string;
  description: string;
  image_url: string | null;
  sort_order: number;
  active: boolean;
}

type Draft = Omit<CategoryRow, "id">;

const emptyDraft: Draft = { name: "", slug: "", description: "", image_url: "", sort_order: 0, active: true };

const inputClass =
  "w-full px-4 py-3 border border-border rounded-xl bg-background text-base text-foreground outline-none focus:ring-2 focus:ring-primary/30";
const labelClass = "text-xs uppercase tracking-wider text-muted-foreground mb-2 block";

const slugify = (v: string) =>
  v.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

const AdminCategories = () => {
  const queryClient = useQueryClient();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ["admin-categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("categories").select("*").order("sort_order");
      if (error) throw error;
      return data as unknown as CategoryRow[];
    },
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["admin-categories"] });
    queryClient.invalidateQueries({ queryKey: ["categories"] });
  };

  const saveMutation = useMutation({
    mutationFn: async (payload: Draft & { id?: string }) => {
      const row = { ...payload, slug: payload.slug || slugify(payload.name) };
      if (row.id) {
        const { id, ...rest } = row;
        const { error } = await supabase.from("categories").update(rest as any).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("categories").insert(row as any);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      invalidate();
      setDraft(null);
      setEditingId(null);
      toast.success("Category saved");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("categories").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Category deleted"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from("categories").update({ active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) return <div className="animate-pulse text-muted-foreground p-4">Loading categories...</div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-foreground">Categories</h2>
          <p className="text-sm text-muted-foreground">{categories.length} categories</p>
        </div>
        <Button
          onClick={() => { setEditingId(null); setDraft({ ...emptyDraft, sort_order: categories.length + 1 }); }}
          className="gap-2 rounded-xl h-11 px-5"
        >
          <Plus className="h-5 w-5" /> Add
        </Button>
      </div>

      {draft && (
        <div className="bg-card border border-border rounded-xl p-4 mb-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-foreground">{editingId ? "Edit category" : "New category"}</h3>
            <button onClick={() => { setDraft(null); setEditingId(null); }} className="p-2 rounded-full hover:bg-muted">
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <Label className={labelClass}>Name *</Label>
              <input
                value={draft.name}
                onChange={(e) => setDraft({ ...draft, name: e.target.value, slug: draft.slug || slugify(e.target.value) })}
                placeholder="e.g. Snorkeling"
                className={inputClass}
              />
            </div>
            <div>
              <Label className={labelClass}>Slug</Label>
              <input
                value={draft.slug}
                onChange={(e) => setDraft({ ...draft, slug: slugify(e.target.value) })}
                placeholder="snorkeling"
                className={inputClass}
              />
            </div>
          </div>
          <div>
            <Label className={labelClass}>Description</Label>
            <textarea
              rows={2}
              value={draft.description}
              onChange={(e) => setDraft({ ...draft, description: e.target.value })}
              className={`${inputClass} resize-none`}
            />
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div>
              <Label className={labelClass}>Image URL</Label>
              <input
                value={draft.image_url ?? ""}
                onChange={(e) => setDraft({ ...draft, image_url: e.target.value })}
                className={inputClass}
              />
            </div>
            <div>
              <Label className={labelClass}>Display Order</Label>
              <input
                type="number"
                value={draft.sort_order}
                onChange={(e) => setDraft({ ...draft, sort_order: Number(e.target.value) })}
                className={inputClass}
              />
            </div>
          </div>
          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-xl">
            <span className="text-sm text-foreground">Active</span>
            <Switch checked={draft.active} onCheckedChange={(c) => setDraft({ ...draft, active: c })} />
          </div>
          <Button
            className="w-full h-12 rounded-xl"
            disabled={!draft.name || saveMutation.isPending}
            onClick={() => saveMutation.mutate(editingId ? { ...draft, id: editingId } : draft)}
          >
            {saveMutation.isPending ? "Saving..." : "Save Category"}
          </Button>
        </div>
      )}

      <div className="space-y-3">
        {categories.map((c) => (
          <div key={c.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-foreground truncate">{c.name}</p>
              <p className="text-xs text-muted-foreground truncate">/{c.slug}</p>
            </div>
            <Switch
              checked={c.active}
              onCheckedChange={(active) => toggleActive.mutate({ id: c.id, active })}
            />
            <button
              onClick={() => { setEditingId(c.id); setDraft({ ...c }); }}
              className="p-2 rounded-full hover:bg-muted text-foreground"
            >
              <Pencil className="h-4 w-4" />
            </button>
            <button
              onClick={() => { if (confirm(`Delete category "${c.name}"?`)) deleteMutation.mutate(c.id); }}
              className="p-2 rounded-full hover:bg-destructive/10 text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
        {categories.length === 0 && (
          <p className="text-center text-muted-foreground py-12">No categories yet.</p>
        )}
      </div>
    </div>
  );
};

export default AdminCategories;
