import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Save } from "lucide-react";
import { toast } from "sonner";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import type { Hotel, TransferZone } from "@/hooks/useHotels";

const LANGS = ["en", "ar", "it"] as const;

const AdminHotels = () => {
  const qc = useQueryClient();
  const { data: settings } = useSiteSettings();
  const symbol = settings?.currency_symbol || "£";
  const [tab, setTab] = useState<"zones" | "hotels">("zones");

  const { data: zones = [] } = useQuery({
    queryKey: ["admin-zones"],
    queryFn: async () => {
      const { data, error } = await supabase.from("transfer_zones").select("*").order("sort_order");
      if (error) throw error;
      return (data ?? []) as unknown as TransferZone[];
    },
  });

  const { data: hotels = [] } = useQuery({
    queryKey: ["admin-hotels"],
    queryFn: async () => {
      const { data, error } = await supabase.from("hotels").select("*").order("sort_order").order("name");
      if (error) throw error;
      return (data ?? []) as unknown as Hotel[];
    },
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["admin-zones"] });
    qc.invalidateQueries({ queryKey: ["admin-hotels"] });
    qc.invalidateQueries({ queryKey: ["transfer-zones"] });
    qc.invalidateQueries({ queryKey: ["hotels"] });
  };

  const saveZone = useMutation({
    mutationFn: async (zone: Partial<TransferZone> & { id?: string }) => {
      const payload = {
        name: zone.name ?? "",
        translations: (zone.translations ?? {}) as never,
        transfer_price: Number(zone.transfer_price ?? 0),
        notes: zone.notes ?? "",
        sort_order: Number(zone.sort_order ?? 0),
        active: zone.active ?? true,
      };
      const { error } = zone.id
        ? await supabase.from("transfer_zones").update(payload).eq("id", zone.id)
        : await supabase.from("transfer_zones").insert(payload);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Zone saved"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteZone = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("transfer_zones").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Zone deleted"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const saveHotel = useMutation({
    mutationFn: async (hotel: Partial<Hotel> & { id?: string }) => {
      const payload = {
        name: hotel.name ?? "",
        zone_id: hotel.zone_id || null,
        area: hotel.area ?? "",
        sort_order: Number(hotel.sort_order ?? 0),
        active: hotel.active ?? true,
      };
      const { error } = hotel.id
        ? await supabase.from("hotels").update(payload).eq("id", hotel.id)
        : await supabase.from("hotels").insert(payload);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Hotel saved"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteHotel = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("hotels").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Hotel deleted"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const [draftZones, setDraftZones] = useState<Record<string, Partial<TransferZone>>>({});
  const [draftHotels, setDraftHotels] = useState<Record<string, Partial<Hotel>>>({});

  const zoneValue = (z: TransferZone) => ({ ...z, ...draftZones[z.id] });
  const hotelValue = (h: Hotel) => ({ ...h, ...draftHotels[h.id] });

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl sm:text-2xl font-serif font-bold text-foreground">Hotels &amp; Transfer Zones</h2>
        <p className="text-sm text-muted-foreground">Set a transfer price per zone, then assign hotels to zones.</p>
      </div>

      <div className="flex gap-2">
        <Button variant={tab === "zones" ? "default" : "outline"} className="rounded-xl" onClick={() => setTab("zones")}>
          Zones ({zones.length})
        </Button>
        <Button variant={tab === "hotels" ? "default" : "outline"} className="rounded-xl" onClick={() => setTab("hotels")}>
          Hotels ({hotels.length})
        </Button>
      </div>

      {tab === "zones" ? (
        <div className="space-y-3">
          <Button
            className="gap-2 rounded-xl h-11"
            onClick={() => saveZone.mutate({ name: "New zone", transfer_price: 0, sort_order: zones.length + 1 })}
          >
            <Plus className="h-4 w-4" /> Add zone
          </Button>

          {zones.map((z) => {
            const v = zoneValue(z);
            const setDraft = (patch: Partial<TransferZone>) =>
              setDraftZones((d) => ({ ...d, [z.id]: { ...d[z.id], ...patch } }));
            return (
              <div key={z.id} className="bg-card border border-border rounded-xl p-4 space-y-3">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label className="text-xs">Zone name (English)</Label>
                    <Input value={v.name ?? ""} onChange={(e) => setDraft({ name: e.target.value })} />
                  </div>
                  <div>
                    <Label className="text-xs">Transfer price per person ({symbol})</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={v.transfer_price ?? 0}
                      onChange={(e) => setDraft({ transfer_price: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {LANGS.filter((l) => l !== "en").map((lang) => (
                    <div key={lang}>
                      <Label className="text-xs uppercase">Name ({lang})</Label>
                      <Input
                        value={v.translations?.[lang]?.name ?? ""}
                        onChange={(e) =>
                          setDraft({
                            translations: {
                              ...(v.translations ?? {}),
                              [lang]: { ...(v.translations?.[lang] ?? {}), name: e.target.value },
                            },
                          })
                        }
                      />
                    </div>
                  ))}
                </div>
                <div>
                  <Label className="text-xs">Notes (optional)</Label>
                  <Input value={v.notes ?? ""} onChange={(e) => setDraft({ notes: e.target.value })} />
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-2">
                    <Switch checked={v.active ?? true} onCheckedChange={(active) => setDraft({ active })} />
                    <span className="text-sm text-muted-foreground">Active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-xs">Order</Label>
                    <Input
                      type="number"
                      className="w-20"
                      value={v.sort_order ?? 0}
                      onChange={(e) => setDraft({ sort_order: Number(e.target.value) })}
                    />
                  </div>
                  <Button size="sm" className="gap-2 rounded-xl ml-auto" onClick={() => saveZone.mutate({ ...v, id: z.id })}>
                    <Save className="h-4 w-4" /> Save
                  </Button>
                  <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteZone.mutate(z.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="space-y-3">
          <Button
            className="gap-2 rounded-xl h-11"
            onClick={() => saveHotel.mutate({ name: "New hotel", zone_id: zones[0]?.id ?? null, sort_order: hotels.length + 1 })}
          >
            <Plus className="h-4 w-4" /> Add hotel
          </Button>

          {zones.length === 0 && (
            <p className="text-sm text-muted-foreground">Create a zone first so hotels can be priced.</p>
          )}

          {hotels.map((h) => {
            const v = hotelValue(h);
            const setDraft = (patch: Partial<Hotel>) =>
              setDraftHotels((d) => ({ ...d, [h.id]: { ...d[h.id], ...patch } }));
            const zone = zones.find((z) => z.id === v.zone_id);
            return (
              <div key={h.id} className="bg-card border border-border rounded-xl p-4 space-y-3">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label className="text-xs">Hotel name</Label>
                    <Input value={v.name ?? ""} onChange={(e) => setDraft({ name: e.target.value })} />
                  </div>
                  <div>
                    <Label className="text-xs">Zone</Label>
                    <select
                      value={v.zone_id ?? ""}
                      onChange={(e) => setDraft({ zone_id: e.target.value || null })}
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                    >
                      <option value="">— No zone —</option>
                      {zones.map((z) => (
                        <option key={z.id} value={z.id}>{z.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <Label className="text-xs">Area / notes</Label>
                  <Input value={v.area ?? ""} onChange={(e) => setDraft({ area: e.target.value })} />
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  {zone && (
                    <Badge variant="outline">Transfer {symbol}{zone.transfer_price}</Badge>
                  )}
                  <div className="flex items-center gap-2">
                    <Switch checked={v.active ?? true} onCheckedChange={(active) => setDraft({ active })} />
                    <span className="text-sm text-muted-foreground">Active</span>
                  </div>
                  <Button size="sm" className="gap-2 rounded-xl ml-auto" onClick={() => saveHotel.mutate({ ...v, id: h.id })}>
                    <Save className="h-4 w-4" /> Save
                  </Button>
                  <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteHotel.mutate(h.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default AdminHotels;
