import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Star, Clock, MapPin, Check, X, ArrowLeft, Users, Calendar, Shield, Heart, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import TourCard from "@/components/TourCard";
import { useTours, localizeTour } from "@/hooks/useTours";
import { useTourKnowledge } from "@/hooks/useTourKnowledge";
import KnowledgeAssistant from "@/components/KnowledgeAssistant";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { useHotels, useTransferZones, zoneName } from "@/hooks/useHotels";
import { useTranslation } from "react-i18next";

import { optimizeImageUrl } from "@/lib/imageUtils";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";



const TourDetail = () => {
  const { id } = useParams();
  const { data: tours = [], isLoading } = useTours();
  const { data: settings } = useSiteSettings();
  const { t, i18n } = useTranslation();
  const NOT_AVAILABLE = t("tourDetail.informationUnavailable");
  const { data: hotels = [] } = useHotels();
  const { data: zones = [] } = useTransferZones();
  const currency = settings?.currency_symbol || "€";
  const whatsapp = settings?.whatsapp_number || "201505191565";
  const rawTour = tours.find((t) => t.slug === id);
  const tour = rawTour ? localizeTour(rawTour, i18n.language) : undefined;
  const { entry: kb } = useTourKnowledge(tour?.slug, tour?.title);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"itinerary" | "included">("itinerary");
  const [bookingForm, setBookingForm] = useState({
    name: "", email: "", whatsapp: "", hotel: "", date: "", people: "2", room: "", message: "",
  });

  const selectedHotel = hotels.find((h) => h.name === bookingForm.hotel);
  const selectedZone = zones.find((z) => z.id === selectedHotel?.zone_id);
  const transferPerPerson = selectedZone?.transfer_price ?? 0;
  const guests = Math.max(1, parseInt(bookingForm.people) || 1);
  const transferTotal = transferPerPerson * guests;
  const transferLine = selectedZone
    ? `Transfer zone: ${zoneName(selectedZone, i18n.language)} (${currency}${transferPerPerson} per person, total ${currency}${transferTotal})`
    : "";


  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-32 text-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto" />
        </div>
      </div>
    );
  }

  if (!tour) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-32 text-center">
          <h1 className="text-2xl font-serif text-foreground">{t("tourDetail.notFound")}</h1>
          <Link to="/tours" className="text-primary mt-4 inline-block">{t("tourDetail.back")}</Link>
        </div>
      </div>
    );
  }

  const relatedTours = tours.filter((t) => t.id !== tour.id && t.category === tour.category).slice(0, 4);
  const originalPrice = tour.original_price;

  // The uploaded knowledge-base document is the primary source of truth.
  const kbDescription = kb?.description?.trim() || null;
  const kbHighlights = kb?.highlights?.length ? kb.highlights : null;
  const kbItinerary = kb?.itinerary?.length ? kb.itinerary : null;
  const kbIncluded = kb?.included?.length ? kb.included : null;
  const kbNotIncluded = kb?.not_included?.length ? kb.not_included : null;
  const kbRecommendations = kb?.recommendations?.length ? kb.recommendations : null;
  const kbFaqs = kb?.faqs?.length ? kb.faqs : null;
  const kbDuration = kb?.duration?.trim() || null;

  const description = tour.description || NOT_AVAILABLE;
  const highlights = tour.highlights ?? [];
  const itinerary = tour.itinerary ?? [];
  const included = tour.included ?? [];
  const notIncluded = tour.not_included ?? [];
  const durationText = kbDuration ?? tour.duration ?? NOT_AVAILABLE;

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from("bookings").insert({
      tour_id: tour.slug,
      tour_title: tour.title,
      name: bookingForm.name,
      email: bookingForm.email,
      whatsapp: bookingForm.whatsapp || null,
      hotel: bookingForm.hotel,
      room: bookingForm.room || null,
      date: bookingForm.date,
      people: parseInt(bookingForm.people),
      message: bookingForm.message || null,
    });
    if (error) { toast.error(t("tourDetail.bookingError")); return; }
    const msg = encodeURIComponent(
      `${t("tourDetail.whatsappMessage.greeting", { name: settings?.site_name || "SHAGGY TOURS" })}\n${t("tourDetail.whatsappMessage.request")}\n\n${t("tourDetail.whatsappMessage.tour")}: ${tour.title}\n${t("tourDetail.whatsappMessage.date")}: ${bookingForm.date}\n${t("tourDetail.whatsappMessage.people")}: ${bookingForm.people}\n${t("tourDetail.whatsappMessage.hotel")}: ${bookingForm.hotel}\n${t("tourDetail.whatsappMessage.room")}: ${bookingForm.room}\n\n${t("tourDetail.whatsappMessage.name")}: ${bookingForm.name}\n${t("tourDetail.whatsappMessage.email")}: ${bookingForm.email}\nWhatsApp: ${bookingForm.whatsapp}\n${bookingForm.message ? `${t("tourDetail.whatsappMessage.message")}: ${bookingForm.message}\n` : ""}\n${t("tourDetail.whatsappMessage.confirm")}`
    );
    window.open(`https://wa.me/${whatsapp}?text=${msg}`, "_blank");
    toast.success(t("tourDetail.bookingSuccess"));
    setBookingOpen(false);
  };

  const handleQuickWhatsApp = () => {
    const msg = encodeURIComponent(
      `${t("tourDetail.whatsappMessage.greeting", { name: settings?.site_name || "SHAGGY TOURS" })}\n${t("tourDetail.whatsappMessage.request")}\n\n${t("tourDetail.whatsappMessage.tour")}: ${tour.title}\n${t("tourDetail.whatsappMessage.date")}: \n${t("tourDetail.whatsappMessage.people")}: \n${t("tourDetail.whatsappMessage.hotel")}: \n${t("tourDetail.whatsappMessage.room")}: \n\n${t("tourDetail.whatsappMessage.confirm")}`
    );
    window.open(`https://wa.me/${whatsapp}?text=${msg}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="relative h-[45vh] md:h-[55vh]">
        <img src={optimizeImageUrl(tour.image_url || "/placeholder.svg", 1200)} alt={tour.title} className="w-full h-full object-cover" loading="eager" />
        <div className="hero-overlay" />
        <div className="absolute inset-0 flex items-end z-10">
          <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8 pb-8 md:pb-10">
            <Link to="/tours" className="inline-flex items-center gap-1.5 text-primary-foreground/70 text-sm mb-3 hover:text-primary-foreground transition-colors">
              <ArrowLeft className="h-4 w-4" /> {t("tourDetail.allTours")}
            </Link>
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="bg-accent/90 text-accent-foreground text-[11px] font-bold px-3 py-1 rounded-full">
                    {t(`categoryNames.${tour.category}`)}
                  </span>
                  {originalPrice && (
                    <span className="bg-[hsl(var(--success))] text-[hsl(var(--success-foreground))] text-[11px] font-bold px-3 py-1 rounded-full">
                      Save €{originalPrice - tour.price}
                    </span>
                  )}
                </div>
                <h1 className="text-3xl md:text-5xl font-serif font-bold text-primary-foreground mb-3">{tour.title}</h1>
                <div className="flex flex-wrap items-center gap-4 text-primary-foreground/80 text-sm">
                  <span className="flex items-center gap-1.5"><MapPin className="h-4 w-4 text-accent" />{tour.destination}</span>
                  <span className="flex items-center gap-1.5"><Clock className="h-4 w-4" />{tour.duration}</span>
                  <span className="flex items-center gap-1.5"><Star className="h-4 w-4 text-[hsl(var(--warm))] fill-[hsl(var(--warm))]" />{tour.rating} ({t("tourDetail.reviews", { count: tour.reviews })})</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-10">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <h2 className="text-2xl font-serif font-bold text-foreground mb-4">{t("tourDetail.about")}</h2>
              <p className="text-muted-foreground leading-relaxed">{description}</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
                {highlights.length === 0 ? (
                  <p className="text-sm text-muted-foreground col-span-full">{NOT_AVAILABLE}</p>
                ) : (
                  highlights.map((h) => (
                    <div key={h} className="bg-primary/5 border border-primary/10 rounded-xl p-4 text-center">
                      <p className="text-sm font-medium text-foreground">{h}</p>
                    </div>
                  ))
                )}
              </div>
            </motion.div>

            <div>
              <div className="flex gap-1 border-b border-border mb-6">
                {(["itinerary", "included"] as const).map((tab) => (
                  <Button
                    key={tab}
                    variant="ghost"
                    onClick={() => setActiveTab(tab)}
                    className={`px-5 py-3 text-sm font-medium transition-colors relative hover:bg-transparent ${
                      activeTab === tab
                        ? "text-primary hover:text-primary after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-primary after:rounded-full"
                        : "text-foreground/70 hover:text-foreground"
                    }`}
                  >
                    {t(tab === "itinerary" ? "tourDetail.programDetails" : "tourDetail.whatsIncluded")}
                  </Button>
                ))}
              </div>

              {activeTab === "itinerary" && (
                <div className="space-y-3">
                  {itinerary.length === 0 ? (
                    <p className="text-sm text-muted-foreground">{NOT_AVAILABLE}</p>
                  ) : (
                    itinerary.map((day, idx) => (
                      <motion.div
                        key={`${day.day}-${idx}`}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        className="flex gap-4"
                      >
                        <div className="flex flex-col items-center">
                          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm shrink-0">
                            {day.day || idx + 1}
                          </div>
                          {idx < itinerary.length - 1 && (
                            <div className="w-0.5 flex-1 bg-border mt-1" />
                          )}
                        </div>
                        <div className="bg-card border border-border rounded-xl p-5 flex-1 mb-1">
                          <h3 className="font-semibold text-foreground mb-1">{day.title}</h3>
                          <p className="text-sm text-muted-foreground">{day.description}</p>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              )}

              {activeTab === "included" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-[hsl(var(--success)/0.05)] border border-[hsl(var(--success)/0.2)] rounded-2xl p-6">
                    <h3 className="font-serif text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                      <Check className="h-5 w-5 text-[hsl(var(--success))]" /> {t("tourDetail.included")}
                    </h3>
                    <ul className="space-y-3">
                      {included.length === 0 ? (
                        <li className="text-sm text-muted-foreground">{NOT_AVAILABLE}</li>
                      ) : (
                        included.map((item) => (
                          <li key={item} className="flex items-center gap-2.5 text-sm text-muted-foreground">
                            <Check className="h-4 w-4 text-[hsl(var(--success))] shrink-0" /> {item}
                          </li>
                        ))
                      )}
                    </ul>
                  </div>
                  <div className="bg-destructive/5 border border-destructive/20 rounded-2xl p-6">
                    <h3 className="font-serif text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                      <X className="h-5 w-5 text-destructive" /> {t("tourDetail.notIncluded")}
                    </h3>
                    <ul className="space-y-3">
                      {notIncluded.length === 0 ? (
                        <li className="text-sm text-muted-foreground">{NOT_AVAILABLE}</li>
                      ) : (
                        notIncluded.map((item) => (
                          <li key={item} className="flex items-center gap-2.5 text-sm text-muted-foreground">
                            <X className="h-4 w-4 text-destructive shrink-0" /> {item}
                          </li>
                        ))
                      )}
                    </ul>
                  </div>
                </div>
              )}
            </div>

            {kbRecommendations && (
              <div>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">{t("tourDetail.goodToKnow")}</h2>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {kbRecommendations.map((r) => (
                    <li key={r} className="bg-card border border-border rounded-xl p-4 text-sm text-muted-foreground">
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {kbFaqs && (
              <div>
                <h2 className="text-2xl font-serif font-bold text-foreground mb-4">{t("tourDetail.faqs")}</h2>
                <div className="space-y-3">
                  {kbFaqs.map((f) => (
                    <div key={f.question} className="bg-card border border-border rounded-xl p-5">
                      <h3 className="font-semibold text-foreground mb-1">{f.question}</h3>
                      <p className="text-sm text-muted-foreground">{f.answer}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>


          <div>
            <div className="sticky top-24 bg-card border border-border rounded-2xl overflow-hidden shadow-lg">
              <div className="bg-primary/5 border-b border-border px-6 py-4">
                {tour.price > 0 ? (
                  <div className="flex items-baseline gap-2">
                    {originalPrice && (
                      <span className="text-lg text-muted-foreground line-through">€{originalPrice}</span>
                    )}
                    <span className="text-3xl font-bold text-primary">€{tour.price}</span>
                    <span className="text-muted-foreground text-sm">{t("common.perPerson")}</span>
                  </div>
                ) : (
                  <p className="text-base font-semibold text-primary">{t("catalog.priceOnRequestLong")}</p>
                )}
                {<p className="text-sm text-foreground mt-1">{t("catalog.colChild610")}: {tour.child_price == null ? t("catalog.na") : `€${tour.child_price}`} · {t("catalog.colChild05")}: {t("catalog.free")}</p>}
                <p className="text-xs text-muted-foreground mt-2">{t("catalog.child")}</p>
                <p className="text-xs text-muted-foreground mt-1">{t("catalog.pricing")}</p>
                <p className="text-xs text-muted-foreground mt-1">{t("catalog.cancel")}</p>
                <p className="text-xs text-muted-foreground mt-1">{t("catalog.documents")}</p>
                <div className="flex items-center gap-1 mt-1">
                  <Star className="h-3.5 w-3.5 text-[hsl(var(--warm))] fill-[hsl(var(--warm))]" />
                  <span className="text-sm font-medium text-foreground">{tour.rating}</span>
                  <span className="text-xs text-muted-foreground">({t("tourDetail.reviews", { count: tour.reviews })})</span>
                </div>
              </div>

              <div className="p-6">
                {!bookingOpen ? (
                  <div className="space-y-3">
                    <Button
                      onClick={() => setBookingOpen(true)}
                      className="w-full bg-accent text-accent-foreground hover:bg-accent/90 text-base h-12 rounded-xl font-semibold"
                    >
                      {t("tourDetail.book")}
                    </Button>
                    <Button
                      onClick={handleQuickWhatsApp}
                      className="w-full bg-[hsl(142,70%,45%)] text-primary-foreground hover:bg-[hsl(142,70%,40%)] rounded-xl gap-2"
                    >
                      <MessageCircle className="h-4 w-4" /> {t("tourDetail.bookWhatsApp")}
                    </Button>
                  </div>
                ) : (
                  <motion.form
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    onSubmit={handleBooking}
                    className="space-y-3"
                  >
                    <input type="text" placeholder={t("tourDetail.form.name")} required value={bookingForm.name} onChange={(e) => setBookingForm({...bookingForm, name: e.target.value})} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                    <input type="email" placeholder={t("tourDetail.form.email")} required value={bookingForm.email} onChange={(e) => setBookingForm({...bookingForm, email: e.target.value})} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                    <input type="tel" placeholder={t("tourDetail.form.whatsapp")} value={bookingForm.whatsapp} onChange={(e) => setBookingForm({...bookingForm, whatsapp: e.target.value})} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                    <input type="text" placeholder={t("tourDetail.form.hotel")} required value={bookingForm.hotel} onChange={(e) => setBookingForm({...bookingForm, hotel: e.target.value})} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                    <div className="grid grid-cols-2 gap-3">
                      <div className="flex items-center gap-2 border border-border rounded-xl px-4 py-3">
                        <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                        <input type="date" aria-label={t("tourDetail.form.date")} title={t("tourDetail.form.date")} required value={bookingForm.date} onChange={(e) => setBookingForm({...bookingForm, date: e.target.value})} className="bg-transparent text-sm text-foreground outline-none w-full" />
                      </div>
                      <div className="flex items-center gap-2 border border-border rounded-xl px-4 py-3">
                        <Users className="h-4 w-4 text-muted-foreground shrink-0" />
                        <input type="number" aria-label={t("tourDetail.form.people")} title={t("tourDetail.form.people")} min={1} max={20} value={bookingForm.people} onChange={(e) => setBookingForm({...bookingForm, people: e.target.value})} className="bg-transparent text-sm text-foreground outline-none w-full" />
                      </div>
                    </div>
                    <input type="text" placeholder={t("tourDetail.form.room")} value={bookingForm.room} onChange={(e) => setBookingForm({...bookingForm, room: e.target.value})} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30" />
                    <textarea placeholder={t("tourDetail.form.message")} rows={2} value={bookingForm.message} onChange={(e) => setBookingForm({...bookingForm, message: e.target.value})} className="w-full px-4 py-3 border border-border rounded-xl bg-background text-sm text-foreground placeholder:text-muted-foreground outline-none focus:ring-2 focus:ring-primary/30 resize-none" />
                    <div className="text-xs text-muted-foreground bg-muted/50 rounded-xl p-3 space-y-1">
                      <p>{t("catalog.child")}</p>
                      <p>{t("catalog.pricing")}</p>
                      <p>{t("catalog.documents")}</p>
                      <p>{t("catalog.cancel")}</p>
                    </div>
                    <Button type="submit" className="w-full bg-[hsl(142,70%,45%)] text-primary-foreground hover:bg-[hsl(142,70%,40%)] rounded-xl h-11 font-semibold gap-2">
                      <MessageCircle className="h-4 w-4" /> {t("tourDetail.sendWhatsApp")}
                    </Button>
                    <Button type="button" onClick={() => setBookingOpen(false)} className="w-full text-sm text-muted-foreground hover:text-foreground transition-colors py-1">
                      {t("tourDetail.form.cancel")}
                    </Button>
                  </motion.form>
                )}

                <div className="mt-5 pt-5 border-t border-border space-y-3 text-sm text-muted-foreground">
                  <p className="flex items-center gap-2.5"><Clock className="h-4 w-4 text-primary" /> {tour.duration}</p>
                  <p className="flex items-center gap-2.5"><Users className="h-4 w-4 text-primary" /> {t("tourDetail.info.smallGroups")}</p>
                  <p className="flex items-center gap-2.5"><MapPin className="h-4 w-4 text-primary" /> {tour.destination}</p>
                  <p className="flex items-center gap-2.5"><Calendar className="h-4 w-4 text-primary" /> {t("tourDetail.info.best", { season: tour.best_season })}</p>
                  <p className="flex items-center gap-2.5"><Shield className="h-4 w-4 text-[hsl(var(--success))]" /> {t("catalog.cancelShort")}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {relatedTours.length > 0 && (
          <div className="mt-16 pt-10 border-t border-border">
            <h2 className="text-2xl font-serif font-bold text-foreground mb-6">{t("tourDetail.related")}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedTours.map((t) => (
                <TourCard key={t.id} tour={t} />
              ))}
            </div>
          </div>
        )}
      </div>
      <KnowledgeAssistant tourSlug={tour.slug} />
      <Footer />
    </div>
  );
};

export default TourDetail;
