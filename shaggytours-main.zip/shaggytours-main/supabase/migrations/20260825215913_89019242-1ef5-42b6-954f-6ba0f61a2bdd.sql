CREATE TABLE public.transfer_zones (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  translations jsonb NOT NULL DEFAULT '{}'::jsonb,
  transfer_price numeric NOT NULL DEFAULT 0,
  notes text NOT NULL DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT ON public.transfer_zones TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.transfer_zones TO authenticated;
GRANT ALL ON public.transfer_zones TO service_role;

ALTER TABLE public.transfer_zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active zones" ON public.transfer_zones
  FOR SELECT USING (active = true);
CREATE POLICY "Admins manage zones" ON public.transfer_zones
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE TRIGGER transfer_zones_updated_at BEFORE UPDATE ON public.transfer_zones
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.hotels (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  zone_id uuid REFERENCES public.transfer_zones(id) ON DELETE SET NULL,
  area text NOT NULL DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT ON public.hotels TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.hotels TO authenticated;
GRANT ALL ON public.hotels TO service_role;

ALTER TABLE public.hotels ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active hotels" ON public.hotels
  FOR SELECT USING (active = true);
CREATE POLICY "Admins manage hotels" ON public.hotels
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE TRIGGER hotels_updated_at BEFORE UPDATE ON public.hotels
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX hotels_zone_id_idx ON public.hotels(zone_id);