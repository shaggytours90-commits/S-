DROP POLICY IF EXISTS "Public read access to tour-images" ON storage.objects;
CREATE POLICY "Public read access to tour-images"
ON storage.objects
FOR SELECT
TO anon, authenticated
USING (bucket_id = 'tour-images');