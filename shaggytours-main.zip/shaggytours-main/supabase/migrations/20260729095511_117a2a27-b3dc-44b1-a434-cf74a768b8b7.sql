
CREATE POLICY "kb_bucket_admin_all" ON storage.objects
  FOR ALL TO authenticated
  USING (bucket_id = 'knowledge-base' AND public.is_admin())
  WITH CHECK (bucket_id = 'knowledge-base' AND public.is_admin());
