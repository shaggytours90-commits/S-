
CREATE TABLE public.kb_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  filename text NOT NULL,
  language text NOT NULL DEFAULT 'en',
  storage_path text,
  raw_text text,
  entry_count integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.kb_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid REFERENCES public.kb_documents(id) ON DELETE CASCADE,
  language text NOT NULL DEFAULT 'en',
  tour_slug text,
  title text NOT NULL,
  category text,
  destination text,
  keywords text[] NOT NULL DEFAULT '{}',
  description text,
  duration text,
  price_note text,
  highlights text[] NOT NULL DEFAULT '{}',
  itinerary jsonb NOT NULL DEFAULT '[]'::jsonb,
  included text[] NOT NULL DEFAULT '{}',
  not_included text[] NOT NULL DEFAULT '{}',
  recommendations text[] NOT NULL DEFAULT '{}',
  faqs jsonb NOT NULL DEFAULT '[]'::jsonb,
  extra jsonb NOT NULL DEFAULT '{}'::jsonb,
  raw_section text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX kb_entries_slug_lang_idx ON public.kb_entries (tour_slug, language);
CREATE INDEX kb_entries_doc_idx ON public.kb_entries (document_id);

GRANT SELECT ON public.kb_documents TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.kb_documents TO authenticated;
GRANT ALL ON public.kb_documents TO service_role;

GRANT SELECT ON public.kb_entries TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.kb_entries TO authenticated;
GRANT ALL ON public.kb_entries TO service_role;

ALTER TABLE public.kb_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kb_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "kb_documents_public_read_active" ON public.kb_documents
  FOR SELECT TO anon, authenticated USING (active = true);
CREATE POLICY "kb_documents_admin_all" ON public.kb_documents
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "kb_entries_public_read" ON public.kb_entries
  FOR SELECT TO anon, authenticated USING (
    document_id IS NULL OR EXISTS (
      SELECT 1 FROM public.kb_documents d WHERE d.id = kb_entries.document_id AND d.active = true
    )
  );
CREATE POLICY "kb_entries_admin_all" ON public.kb_entries
  FOR ALL TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE TRIGGER kb_documents_updated_at BEFORE UPDATE ON public.kb_documents
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER kb_entries_updated_at BEFORE UPDATE ON public.kb_entries
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
