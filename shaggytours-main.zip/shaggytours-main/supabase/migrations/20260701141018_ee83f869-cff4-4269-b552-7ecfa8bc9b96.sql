
-- 1. Move has_role into a private schema so PostgREST can't expose it
CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon, authenticated;
GRANT USAGE ON SCHEMA private TO authenticated, service_role;

CREATE OR REPLACE FUNCTION private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  )
$$;

REVOKE ALL ON FUNCTION private.has_role(uuid, public.app_role) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO authenticated, service_role;

-- 2. Rebuild all policies to use private.has_role instead of public.has_role
-- contact_messages
DROP POLICY IF EXISTS "Admins can delete messages" ON public.contact_messages;
DROP POLICY IF EXISTS "Admins can update messages" ON public.contact_messages;
DROP POLICY IF EXISTS "Admins can view all messages" ON public.contact_messages;
DROP POLICY IF EXISTS "Anyone can submit messages" ON public.contact_messages;

CREATE POLICY "Admins can delete messages" ON public.contact_messages
  FOR DELETE TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update messages" ON public.contact_messages
  FOR UPDATE TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can view all messages" ON public.contact_messages
  FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'));
-- Add basic input validation (no more WITH CHECK true)
CREATE POLICY "Anyone can submit messages" ON public.contact_messages
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    char_length(name) BETWEEN 1 AND 200
    AND char_length(email) BETWEEN 3 AND 320
    AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND char_length(message) BETWEEN 1 AND 5000
    AND (phone IS NULL OR char_length(phone) <= 50)
  );

-- bookings
DROP POLICY IF EXISTS "Admins can delete bookings" ON public.bookings;
DROP POLICY IF EXISTS "Admins can update bookings" ON public.bookings;
DROP POLICY IF EXISTS "Admins can view all bookings" ON public.bookings;
DROP POLICY IF EXISTS "Anyone can create bookings" ON public.bookings;

CREATE POLICY "Admins can delete bookings" ON public.bookings
  FOR DELETE TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update bookings" ON public.bookings
  FOR UPDATE TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can view all bookings" ON public.bookings
  FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Anyone can create bookings" ON public.bookings
  FOR INSERT TO anon, authenticated
  WITH CHECK (
    char_length(name) BETWEEN 1 AND 200
    AND char_length(email) BETWEEN 3 AND 320
    AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
    AND char_length(hotel) BETWEEN 1 AND 200
    AND char_length(tour_id) BETWEEN 1 AND 200
    AND char_length(tour_title) BETWEEN 1 AND 300
    AND people BETWEEN 1 AND 100
    AND (message IS NULL OR char_length(message) <= 5000)
    AND (whatsapp IS NULL OR char_length(whatsapp) <= 50)
    AND (room IS NULL OR char_length(room) <= 100)
  );

-- tours
DROP POLICY IF EXISTS "Admins can do anything with tours" ON public.tours;
CREATE POLICY "Admins can do anything with tours" ON public.tours
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));

-- site_settings: whitelist safe keys for public read
DROP POLICY IF EXISTS "Admins can manage site settings" ON public.site_settings;
DROP POLICY IF EXISTS "Anyone can read site settings" ON public.site_settings;

CREATE POLICY "Admins can manage site settings" ON public.site_settings
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Public can read safe site settings" ON public.site_settings
  FOR SELECT TO anon, authenticated
  USING (key IN (
    'site_name','site_email','whatsapp_number','phone_display','address',
    'facebook_url','instagram_url','site_description','footer_tagline'
  ));

-- faqs / testimonials / gallery_images / hero_sections (rewrap admin policies)
DROP POLICY IF EXISTS "Admins can manage faqs" ON public.faqs;
CREATE POLICY "Admins can manage faqs" ON public.faqs
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage testimonials" ON public.testimonials;
CREATE POLICY "Admins can manage testimonials" ON public.testimonials
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage gallery images" ON public.gallery_images;
CREATE POLICY "Admins can manage gallery images" ON public.gallery_images
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins can manage hero sections" ON public.hero_sections;
CREATE POLICY "Admins can manage hero sections" ON public.hero_sections
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));

-- user_roles: explicit admin-only write policies + admin view
DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;
CREATE POLICY "Users can view their own roles, admins view all" ON public.user_roles
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Only admins can insert roles" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Only admins can update roles" ON public.user_roles
  FOR UPDATE TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Only admins can delete roles" ON public.user_roles
  FOR DELETE TO authenticated
  USING (private.has_role(auth.uid(), 'admin'));

-- storage.objects: replace open SELECT with admin-only listing. Public URLs still work via the public bucket CDN endpoint.
DROP POLICY IF EXISTS "Anyone can view tour images" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete tour images" ON storage.objects;
DROP POLICY IF EXISTS "Admins can update tour images" ON storage.objects;
DROP POLICY IF EXISTS "Admins can upload tour images" ON storage.objects;

CREATE POLICY "Admins can list tour images" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'tour-images' AND private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can upload tour images" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'tour-images' AND private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update tour images" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'tour-images' AND private.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete tour images" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'tour-images' AND private.has_role(auth.uid(), 'admin'));

-- 3. Drop the public.has_role now that no policy references it
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);

-- 4. Public-safe helper: reports admin status for the CURRENT user only
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid() AND role = 'admin'
  )
$$;

REVOKE ALL ON FUNCTION public.is_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated, service_role;
