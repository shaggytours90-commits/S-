DROP POLICY IF EXISTS "Public can read safe site settings" ON public.site_settings;
CREATE POLICY "Public can read safe site settings" ON public.site_settings
FOR SELECT TO anon, authenticated
USING (key = ANY (ARRAY[
  'site_name','site_email','whatsapp_number','phone_display','address',
  'facebook_url','instagram_url','site_description','footer_tagline',
  'logo_url','currency_code','currency_symbol','company_name','company_address',
  'company_registration','working_hours','tiktok_url','youtube_url','twitter_url',
  'tripadvisor_url','whatsapp_number_2','default_meta_title','default_meta_description',
  'default_meta_keywords','default_og_image'
]));