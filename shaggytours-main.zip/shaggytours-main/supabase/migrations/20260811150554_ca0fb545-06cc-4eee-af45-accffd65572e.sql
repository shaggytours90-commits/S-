ALTER TABLE public.testimonials
  ADD COLUMN IF NOT EXISTS language text NOT NULL DEFAULT 'en',
  ADD COLUMN IF NOT EXISTS country text NOT NULL DEFAULT '';

CREATE INDEX IF NOT EXISTS testimonials_language_idx ON public.testimonials (language);