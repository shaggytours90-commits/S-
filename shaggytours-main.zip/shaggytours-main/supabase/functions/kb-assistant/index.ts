import { createClient } from "https://esm.sh/@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { question, language = "en", tour_slug = null } = await req.json();
    if (!question || typeof question !== "string") {
      return json({ error: "Missing question" }, 400);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: docs } = await supabase
      .from("kb_documents")
      .select("id, language")
      .eq("active", true);
    const activeIds = (docs ?? []).map((d: { id: string }) => d.id);
    if (!activeIds.length) {
      return json({ answer: "Information not available." });
    }

    const langsAvailable = new Set((docs ?? []).map((d: { language: string }) => d.language));
    const useLang = langsAvailable.has(language) ? language : (docs?.[0]?.language ?? "en");

    let query = supabase
      .from("kb_entries")
      .select("*")
      .in("document_id", activeIds)
      .eq("language", useLang)
      .order("sort_order", { ascending: true });
    if (tour_slug) query = query.eq("tour_slug", tour_slug);

    const { data: entries } = await query;
    const rows = entries ?? [];
    if (!rows.length) return json({ answer: "Information not available." });

    const context = rows
      .map((e: Record<string, unknown>) =>
        [
          `### ${e.title}`,
          e.destination ? `Destination: ${e.destination}` : "",
          e.duration ? `Duration: ${e.duration}` : "",
          e.price_note ? `Price: ${e.price_note}` : "",
          e.description ? `Description: ${e.description}` : "",
          (e.highlights as string[])?.length ? `Highlights: ${(e.highlights as string[]).join("; ")}` : "",
          (e.included as string[])?.length ? `Included: ${(e.included as string[]).join("; ")}` : "",
          (e.not_included as string[])?.length ? `Not included: ${(e.not_included as string[]).join("; ")}` : "",
          (e.recommendations as string[])?.length
            ? `Recommendations: ${(e.recommendations as string[]).join("; ")}`
            : "",
          Array.isArray(e.itinerary) && e.itinerary.length
            ? `Programme: ${(e.itinerary as { title: string; description: string }[])
                .map((s) => `${s.title}: ${s.description}`)
                .join(" | ")}`
            : "",
          Array.isArray(e.faqs) && e.faqs.length
            ? `FAQs: ${(e.faqs as { question: string; answer: string }[])
                .map((f) => `Q: ${f.question} A: ${f.answer}`)
                .join(" | ")}`
            : "",
        ]
          .filter(Boolean)
          .join("\n"),
      )
      .join("\n\n");

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) return json({ error: "AI gateway not configured" }, 500);

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `You are the Shaggy Tours assistant. Answer ONLY with facts contained in the KNOWLEDGE BASE below.
Never use outside knowledge, never guess, never estimate.
If the answer is not explicitly in the knowledge base, reply exactly: "Information not available."
Answer concisely in the same language as the customer's question.

KNOWLEDGE BASE:
${context}`,
          },
          { role: "user", content: question },
        ],
      }),
    });

    if (aiRes.status === 429) return json({ error: "Rate limit reached, please retry shortly." }, 429);
    if (aiRes.status === 402) return json({ error: "AI credits exhausted." }, 402);
    if (!aiRes.ok) {
      console.error("AI error", aiRes.status, await aiRes.text());
      return json({ error: "Assistant unavailable" }, 500);
    }

    const aiJson = await aiRes.json();
    const answer = aiJson.choices?.[0]?.message?.content?.trim() || "Information not available.";
    return json({ answer });
  } catch (err) {
    console.error("kb-assistant failed", err);
    return json({ error: err instanceof Error ? err.message : "Unexpected error" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
