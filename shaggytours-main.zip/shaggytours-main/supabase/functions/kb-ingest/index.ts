import { createClient } from "https://esm.sh/@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SYSTEM_PROMPT = `You are a strict document indexer for a tour operator knowledge base.
You receive the raw text of a tour document. Split it into one entry per tour/excursion.

Absolute rules:
- NEVER invent, guess or embellish information. Only use what is literally in the text.
- If a field is not present in the text, return an empty string or empty array for it. Do not fill it with plausible content.
- Keep the original language of the document for all textual values.
- Strip decorative emoji/icon placeholders (e.g. "icon", "Icona", stray emojis) from the values.

For each tour return:
- title: the tour name as written
- tour_slug: pick the best match from the provided slug list, or "" if none matches
- category, destination: only if stated or obvious from the title/location line, else ""
- keywords: 3-10 lowercase search keywords derived from the text
- description: a short paragraph assembled ONLY from sentences in the text
- duration: e.g. "Half day", return time / duration if stated, else ""
- price_note: any price information stated, else ""
- highlights: bullet list of highlights stated
- itinerary: array of {day: number (use sequential step numbers), title, description} built from the program/schedule described; [] if no schedule is given
- included: what the price includes
- not_included: what the price excludes
- recommendations: what to bring / important info / tips
- faqs: array of {question, answer} ONLY if the text contains explicit Q&A; otherwise []`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData } = await userClient.auth.getUser();
    if (!userData?.user) {
      return json({ error: "Not authenticated" }, 401);
    }
    const { data: isAdmin } = await userClient.rpc("is_admin");
    if (!isAdmin) return json({ error: "Admin access required" }, 403);

    const admin = createClient(supabaseUrl, serviceKey);

    const body = await req.json();
    const filename: string = body.filename ?? "knowledge-base.txt";
    const language: string = body.language ?? "en";
    const storagePath: string | null = body.storage_path ?? null;
    const text: string = (body.text ?? "").trim();
    if (!text) return json({ error: "No text content supplied" }, 400);

    const { data: tours } = await admin.from("tours").select("slug, title, category, destination");
    const slugList = (tours ?? [])
      .map((t: Record<string, unknown>) => `${t.slug} — ${t.title}`)
      .join("\n");

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) return json({ error: "AI gateway not configured" }, 500);

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          {
            role: "user",
            content: `Existing tour slugs:\n${slugList}\n\nDocument language: ${language}\n\nDocument text:\n"""\n${text.slice(0, 120000)}\n"""`,
          },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "save_entries",
              description: "Save the indexed tour entries",
              parameters: {
                type: "object",
                properties: {
                  entries: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        tour_slug: { type: "string" },
                        category: { type: "string" },
                        destination: { type: "string" },
                        keywords: { type: "array", items: { type: "string" } },
                        description: { type: "string" },
                        duration: { type: "string" },
                        price_note: { type: "string" },
                        highlights: { type: "array", items: { type: "string" } },
                        itinerary: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: {
                              day: { type: "number" },
                              title: { type: "string" },
                              description: { type: "string" },
                            },
                            required: ["day", "title", "description"],
                            additionalProperties: false,
                          },
                        },
                        included: { type: "array", items: { type: "string" } },
                        not_included: { type: "array", items: { type: "string" } },
                        recommendations: { type: "array", items: { type: "string" } },
                        faqs: {
                          type: "array",
                          items: {
                            type: "object",
                            properties: { question: { type: "string" }, answer: { type: "string" } },
                            required: ["question", "answer"],
                            additionalProperties: false,
                          },
                        },
                        raw_section: { type: "string" },
                      },
                      required: ["title", "tour_slug", "keywords", "description"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["entries"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "save_entries" } },
      }),
    });

    if (aiRes.status === 429) return json({ error: "Rate limit reached, please retry shortly." }, 429);
    if (aiRes.status === 402) return json({ error: "AI credits exhausted." }, 402);
    if (!aiRes.ok) {
      const detail = await aiRes.text();
      console.error("AI error", aiRes.status, detail);
      return json({ error: "Failed to index document" }, 500);
    }

    const aiJson = await aiRes.json();
    const call = aiJson.choices?.[0]?.message?.tool_calls?.[0];
    const parsed = call ? JSON.parse(call.function.arguments) : { entries: [] };
    const entries = Array.isArray(parsed.entries) ? parsed.entries : [];

    const replaceAll: boolean = body.replace_all === true;

    if (replaceAll) {
      // Wipe the whole knowledge base so the new file becomes the only source of truth.
      await admin.from("kb_entries").delete().not("id", "is", null);
      await admin.from("kb_documents").delete().not("id", "is", null);
    } else {
      // Deactivate previous documents for the same language so the newest file wins.
      await admin.from("kb_documents").update({ active: false }).eq("language", language);
    }

    const { data: doc, error: docErr } = await admin
      .from("kb_documents")
      .insert({
        filename,
        language,
        storage_path: storagePath,
        raw_text: text,
        entry_count: entries.length,
        active: true,
      })
      .select()
      .single();
    if (docErr) throw docErr;

    if (entries.length) {
      const rows = entries.map((e: Record<string, unknown>, i: number) => ({
        document_id: doc.id,
        language,
        tour_slug: (e.tour_slug as string) || null,
        title: (e.title as string) || "Untitled",
        category: (e.category as string) || null,
        destination: (e.destination as string) || null,
        keywords: (e.keywords as string[]) ?? [],
        description: (e.description as string) || null,
        duration: (e.duration as string) || null,
        price_note: (e.price_note as string) || null,
        highlights: (e.highlights as string[]) ?? [],
        itinerary: e.itinerary ?? [],
        included: (e.included as string[]) ?? [],
        not_included: (e.not_included as string[]) ?? [],
        recommendations: (e.recommendations as string[]) ?? [],
        faqs: e.faqs ?? [],
        raw_section: (e.raw_section as string) || null,
        sort_order: i,
      }));
      const { error: insErr } = await admin.from("kb_entries").insert(rows);
      if (insErr) throw insErr;
    }

    return json({ document: doc, entries: entries.length });
  } catch (err) {
    console.error("kb-ingest failed", err);
    return json({ error: err instanceof Error ? err.message : "Unexpected error" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
