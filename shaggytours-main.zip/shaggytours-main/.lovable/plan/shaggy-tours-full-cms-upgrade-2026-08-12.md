# SHAGGY TOURS — Full CMS Upgrade

Builds on what already exists (tours, bookings, hero, gallery, FAQs, testimonials, settings, knowledge base, admin auth with roles). Nothing is removed; missing pieces are added and gaps fixed.

## What's already working
- Admin at `/admin` with real login + admin role check
- Tours CRUD (images, prices, visibility), Bookings, Messages, Hero, Gallery, FAQs, Testimonials, Site Settings, Knowledge Base
- Public site reads live data from the database
- Languages: English, Italian, Polish, Arabic

## What gets added

### 1. Languages: add German, French, Czech
Extend the language switcher and translation files to 7 languages (EN, IT, DE, PL, CS, FR, AR) with full RTL for Arabic.

### 2. Per-language content in the database
Tours, hero, FAQs, pages and settings get a translations layer, so each language has its own editable title/description/details. Admin editors gain a language tab bar; anything not translated falls back to English on the site.

### 3. Content Pages manager (new)
A `pages` section in admin for About, Contact, FAQ, Terms, Privacy, Cancellation Policy — editable rich text per language, publish/unpublish, and public routes `/terms`, `/privacy`, `/cancellation-policy` wired into the footer.

### 4. SEO manager (new)
Per page and per tour: meta title, description, keywords, social share image and OG/Twitter tags, plus a global default. Rendered on the live site with JSON-LD for tours.

### 5. Media library (new)
Central image manager: upload, browse, rename, delete, copy URL, and pick images directly from tour/hero/page/gallery editors.

### 6. Tours: availability + inclusions/exclusions polish
Availability windows (season/days, bookable yes/no) plus cleaner inclusion/exclusion editing.

### 7. Bookings: full management
Edit customer details, confirm/cancel/complete status, internal notes, filters and search.

### 8. Settings expansion
Currency (with symbol used site-wide), company info, WhatsApp number, all contact and social links — everything read live by header, footer and booking buttons.

### 9. Mobile-first admin polish
Consistent responsive layout, full-screen forms, sticky save bars and larger touch targets across every admin screen.

### 10. Audit & test pass
Sweep for hardcoded content, fix broken links/buttons/forms, verify booking + WhatsApp flows, language switching, admin CRUD and RLS, then browser-test the main journeys.

## Technical notes
- All new tables in the existing backend with row-level security: public read for published content, admin-only writes.
- Translations stored as JSONB keyed by language code on content tables; a shared `useLocalizedContent` helper handles fallback.
- Media library backed by the existing storage bucket, with a `media_assets` table for metadata.
- SEO handled by a shared `<Seo>` component fed from the database.

## Order of delivery
1. Languages + translation layer
2. Pages manager + public pages
3. SEO manager
4. Media library
5. Bookings/tours/settings upgrades
6. Mobile polish + full test pass
