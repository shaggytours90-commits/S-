# Homepage translation completion

## Scope
- Add natural Russian and Czech translations for the existing homepage, navigation, calls to action, and footer.
- Register the Russian translation resource without changing the existing selector or language behavior.
- Preserve all layouts, prices, tour content, sections, and business details.

## Verification
- Check EN, IT, PL, RU, CZ, DE, and AR on desktop and mobile.
- Confirm language switching persists, translated homepage text appears, navigation still works, and Arabic uses RTL.
