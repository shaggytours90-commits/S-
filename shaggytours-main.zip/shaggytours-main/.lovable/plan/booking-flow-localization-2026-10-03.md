# Booking flow localization

## Scope
- Connect the existing tour booking form, booking buttons, confirmation notice, and WhatsApp booking messages to the current translation system.
- Add natural booking-flow translations for EN, IT, PL, RU, CZ, DE, and AR, including field labels, date and guest fields, and WhatsApp message wording.
- Preserve the current form behavior, booking storage, layout, prices, tour details, and seven-language selector.
- Keep Arabic on the existing RTL behavior.

## Verification
- Open an existing tour in every configured language and confirm the booking form and actions display translated text.
- Confirm booking and quick-booking still open WhatsApp with a localized pre-filled message.
- Check desktop and mobile presentation, including Arabic RTL.
