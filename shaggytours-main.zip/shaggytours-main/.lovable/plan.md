# Egypt-wide regions and services update

## What will change
- Replace homepage operator wording and Marsa Alam taglines with the requested Egypt wording, keeping SHAGGY TOURS and the existing design.
- Add `/marsa-alam`, `/hurghada`, `/cairo`, `/sharm-el-sheikh`, and `/bahariya-oasis`, linked from the main navigation and homepage destinations. Each region gets its own image/icon, tour cards, WhatsApp booking, and policy/contact blocks.
- Complete all new text in English, Arabic, Italian, German, French, Russian, Polish and Czech; activate French and verify Arabic right-to-left layout and locale-formatted currency prices.
- Add the requested services on the homepage and Cairo page, including the Cairo guide service card. Display accommodation as per-room pricing and guide services per full day rather than per-person tour prices.
- Update the FAQ with cancellation, guest documents, weather/sea conditions, and availability information.

## Currencies
- Keep EUR as the unchanged base price. Add two owner-editable site settings: USD per €1 and EGP per €1. Leave both unset initially; never invent, automatically fetch, or assume exchange rates.
- Add only these rate fields to the existing admin Settings page, with positive-number validation, clear conversion direction, and the ability to clear a rate. No other admin changes.
- Apply a shared price display to every public price surface, including tour cards/details, price tables, services, ranges, package totals, and child prices. Show EUR with USD and EGP equivalents next to it when their owner-set rates are valid. An unset/invalid rate suppresses only that currency; if both are unset, show EUR only with a translated note that conversion rates have not yet been set.
- Add a header currency selector for EUR/USD/EGP, remembering the visitor's preference. It changes the emphasized currency without hiding the other available equivalents or the EUR base; currencies without a valid rate cannot be selected.
- Preserve child rules in all currencies: ages 0–5 free, ages 6–10 half the EUR adult amount converted using the same rate, ages 11+ the adult amount, and existing N/A private-tour exceptions. Convert before display rounding; format amounts for the selected site language, including Arabic RTL.
- Never convert an unpriced tour into a number. Keep “Price on request” and N/A localized; preserve per-person, per-day, per-room and package-total labels.

## Catalog rules and assumptions
- Keep all 52 existing regional tour records and their identities. Preserve existing images and owner editing.
- Update the supplied Marsa Alam schedules: Hamata Sun/Tue/Thu; Sataya day Mon/Wed/Fri; Sataya overnight Tue/Thu; Luxor group Tue/Thu. Show the Cairo minivan's approximately 22:00 departure the evening before.
- Preserve all supplied adult/child prices, free ages 0–5, and N/A private-tour child prices. Existing tours omitted from the latest priced list remain visible at **Price on request**: Aswan & Abu Simbel, Sharm El-Luli, Abu Dabbab, Beach Transfers, City Vibes, and Private Boat.
- Cairo's page presents the five existing Cairo-bound excursions without merging their Hurghada/Marsa Alam departure-region records; departure region stays visible. Cairo by plane remains daily, as explicitly requested.
- Add exactly the two unpriced tours specified below for each of Sharm El Sheikh and Bahariya Oasis. Flag both regions for owner verification; do not invent departure days, exact durations, prices or confirmed inclusions.
- Retain the previous Special Package/Deals interpretation: from €650 total, details on request, with no invented package contents.

## Sharm El Sheikh — Sinai
- Replace the previous starting-tour suggestions with **Ras Mohammed National Park & Tiran Island snorkeling/diving trip** and **Mount Sinai & St. Catherine's Monastery**. Both remain **Price on request**.
- Present Ras Mohammed as Egypt's first national park, with Red Sea reef snorkeling/diving. Explain the proposed activities, suitability, duration awaiting confirmation, and recommended swimwear, towel and sun protection. Describe the Ras Mohammed/Tiran itinerary as proposed and owner-confirmed, not a guaranteed combined route; do not promise equipment, meals, permits or transfers.
- Describe Mount Sinai as a sunrise-hike or daytime excursion option, and accurately reference St. Catherine's UNESCO World Heritage setting. Include walking demands, suitability, duration awaiting confirmation, and recommended sturdy footwear, warm layers for the sunrise option, water and respectful clothing. Monastery access and itinerary inclusions require confirmation.
- Give both tours full descriptions with activities/proposed inclusions, duration, suitability and what to bring in all eight languages. Clearly mark the **whole Sharm page as owner to verify**.

## Bahariya Oasis — Western Desert wellness
- Replace the previous suggestions with **Bahariya Hot Springs & Wellness Retreat** and **Valley of the Golden Mummies & Black Desert Safari**. Both remain **Price on request**.
- Position the region intro around calm, relaxation and spiritual/physical renewal through a restful oasis experience. Describe mineral/hot springs as relaxation and wellness, never medical treatment or a promised health benefit.
- Describe the retreat around hot-spring relaxation, rest and recovery; describe the second tour around Bahariya's archaeological heritage and Black Desert landscapes. Do not invent lodging, treatments, meals, access permissions or fixed itineraries; inclusions, duration and schedule await owner confirmation.
- Translate the region intro and tour descriptions naturally in all eight languages. Mark **Bahariya Oasis as owner to verify** and retain the no-medical-claims constraint across translations.

## Technical approach
- Use a shared region-page layout, existing components/tokens and active-tour CMS data. Keep language-neutral prices, durations, days and services in shared data modules; keep prose in locale resources with English fallback and CMS overrides.
- Expose Hurghada data through `src/data/hurghadaTours.ts` without duplicating the underlying catalog prices. Reuse consistent tour translation keys across region pages and existing tour listings.
- Synchronize corrected catalog fields and new regional records into the existing CMS so visibility toggles and owner edits still work. Use data updates in existing tables, including the unset exchange-rate settings. Apart from adding the two rate fields in admin Settings, do not change admin screens, `.env`, authentication or permissions.
- Use the existing Seo component for localized region titles/descriptions and language alternates; point page URLs at `https://shaggytours.lovable.app`.
- Add focused tests for exact prices, schedules, child rules, service rates, regional separation, null-price tours, currency conversion, missing/invalid rates, and rounding. Use explicit test-only rates, never production defaults; browser-check all five regions, eight languages, WhatsApp messages, the currency selector, and Arabic mobile layout. Verify owner rate saving and clearing through admin Settings and read the result back publicly; restore test settings afterward.
- At implementation start, record the currency and revised Sharm/Bahariya tasks in the project roadmap; no files outside this plan are changed while plan mode is active.

## Delivery
- Report every changed file/component, all unpriced tours, the two provisional regions, and any uncertain translations, with the preview link.
- Explicitly flag the whole Sharm El Sheikh page and Bahariya Oasis content for owner verification. USD/EGP equivalents remain unavailable until the owner supplies rates; no exchange rates or medical claims will be invented.
- Do not publish. CMS changes affect the shared live catalog immediately; page and wording changes reach the public website only after a later publish.