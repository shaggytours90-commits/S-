# Architecture rules
- Keep numeric catalog seed data in one shared module and English catalog text in locale resources; synchronize seed values to the existing CMS so owner edits remain supported.
- Resolve catalog text through i18next with per-key English fallback and CMS overrides; never localize monetary values or merge records across regions.